(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-info-modal-info-modal-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"danger\">\n    \n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"salir()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title >Detalles</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-list *ngIf=\"tipo === 'imagenCarpeta'  && ver\"\n  class=\"ion-padding\">\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">Fecha</ion-label>\n      <ion-label>{{datosFotos[0].fecha | fecha}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Carpeta\n      </ion-label>\n      <ion-label>{{datosCarpeta[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\"> \n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Ruta\n      </ion-label>\n      <ion-label>Galeria/{{datosCarpeta[0].nombre}}/{{datosFotos[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\"\n      font-size=\"small\">Nombre\n      \n    </ion-label>\n      <ion-label>{{datosFotos[0].nombre}}</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list *ngIf=\"tipo === 'carpeta' && ver\">\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Nombre\n      </ion-label>\n      <ion-label>{{datosCarpeta[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Imagenes\n      </ion-label>\n      <ion-label>{{datosFotos.length}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Materia\n      </ion-label>\n      <ion-label *ngIf=\"datosCarpeta[0].id_materia > 0\">{{datosCarpeta[0].nombre}}</ion-label>\n      <ion-label *ngIf=\"datosCarpeta[0].id_materia == 0\">Carpeta independiente</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list *ngIf=\"tipo === 'materia' && ver\">\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Nombre\n      </ion-label>\n      <ion-label>{{datosMaterias[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item >\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Periodo academico\n      </ion-label>\n      <ion-label>{{datosPeriodo[0].nombre}}</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-title *ngIf=\"tipo === 'materia'\">Horario de clases</ion-title>\n\n  <ion-item *ngIf=\"datosEvento.length == 0 && tipo === 'materia'\">\n    <ion-label color=\"medium\"\n    position=\"fixed\">\n      Sin horario de clases\n    </ion-label>\n  </ion-item>\n\n  <ion-list *ngIf=\"tipo === 'materia' && ver && datosEvento.length > 0\">\n\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Dia\n      </ion-label>\n      <ion-label>{{datosEvento[0].dia | dia: datosEvento[0].dia}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Inicio\n      </ion-label>\n      <ion-label>{{datosEvento[0].inicio | hora}}</ion-label>\n    </ion-item>\n\n  <ion-item lines=\"none\">\n    <ion-label color=\"medium\"\n    position=\"fixed\">\n      Fin\n    </ion-label>\n    <ion-label>{{datosEvento[0].fin | hora}}</ion-label>\n  </ion-item>\n\n<ion-item >\n  <ion-label color=\"medium\"\n  position=\"fixed\">\n    Comentarios\n  </ion-label>\n  <ion-label>{{datosEvento[0].comentario || 'Sin comentarios'}}</ion-label>\n</ion-item>\n</ion-list>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/info-modal/info-modal-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/info-modal/info-modal-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: InfoModalPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfoModalPageRoutingModule", function() { return InfoModalPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _info_modal_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./info-modal.page */ "./src/app/pages/info-modal/info-modal.page.ts");




const routes = [
    {
        path: '',
        component: _info_modal_page__WEBPACK_IMPORTED_MODULE_3__["InfoModalPage"]
    }
];
let InfoModalPageRoutingModule = class InfoModalPageRoutingModule {
};
InfoModalPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], InfoModalPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/info-modal/info-modal.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/info-modal/info-modal.module.ts ***!
  \*******************************************************/
/*! exports provided: InfoModalPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfoModalPageModule", function() { return InfoModalPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _info_modal_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./info-modal-routing.module */ "./src/app/pages/info-modal/info-modal-routing.module.ts");
/* harmony import */ var _info_modal_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./info-modal.page */ "./src/app/pages/info-modal/info-modal.page.ts");
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/components.module */ "./src/app/components/components.module.ts");








let InfoModalPageModule = class InfoModalPageModule {
};
InfoModalPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _info_modal_routing_module__WEBPACK_IMPORTED_MODULE_5__["InfoModalPageRoutingModule"],
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]
        ],
        declarations: [_info_modal_page__WEBPACK_IMPORTED_MODULE_6__["InfoModalPage"]]
    })
], InfoModalPageModule);



/***/ }),

/***/ "./src/app/pages/info-modal/info-modal.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/pages/info-modal/info-modal.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luZm8tbW9kYWwvaW5mby1tb2RhbC5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/info-modal/info-modal.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/info-modal/info-modal.page.ts ***!
  \*****************************************************/
/*! exports provided: InfoModalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfoModalPage", function() { return InfoModalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/db.service */ "./src/app/services/db.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let InfoModalPage = class InfoModalPage {
    constructor(db, modalCtrl) {
        this.db = db;
        this.modalCtrl = modalCtrl;
        this.ver = false;
        this.datosFotos = [];
        this.datosCarpeta = [];
        this.datosMaterias = [];
        this.datosEvento = [];
        this.datosPeriodo = [];
    }
    ngOnInit() {
        console.log(this.id);
    }
    ionViewWillEnter() {
        this.db.getDatabaseState().subscribe(boo => {
            if (boo) {
                if (this.tipo === 'imagenCarpeta') {
                    this.cargarFotos();
                    this.cargarCarpeta();
                }
                if (this.tipo === 'carpeta') {
                    this.cargarCarpetaId();
                    this.cargarFotos();
                }
                if (this.tipo === 'materia') {
                    this.cargarMateriasId();
                }
            }
        });
    }
    salir() {
        this.modalCtrl.dismiss();
    }
    cargarFotos() {
        this.db.getFotos().subscribe(data => {
            for (let datos of data) {
                if (datos.id == this.id && this.tipo === 'imagenCarpeta') {
                    this.datosFotos.push(datos);
                    this.ver = true;
                }
                else if (datos.id_carpeta == this.id && this.tipo === 'carpeta') {
                    this.datosFotos.push(datos);
                }
            }
        });
    }
    cargarCarpeta() {
        this.db.getCarpeta().subscribe(data => {
            for (let datos of data) {
                if (datos.id == this.datosFotos[0].id_carpeta) {
                    this.datosCarpeta.push(datos);
                }
            }
            this.ver = true;
        });
    }
    cargarCarpetaId() {
        this.db.cargarCarpetaId(this.id).then(data => {
            this.datosCarpeta.push(data);
            console.log(data);
            this.ver = true;
        });
    }
    cargarMateriasId() {
        this.db.cargarMateriaId(this.id).then(data => {
            this.datosMaterias.push(data);
            this.ver = true;
            this.cargarEvento();
            this.cargarPeriodo();
        });
    }
    cargarEvento() {
        if (this.datosMaterias[0].id_evento > 0) {
            this.db.cargarEventoId(this.datosMaterias[0].id_evento).then(data => {
                if (data) {
                    this.datosEvento.push(data);
                }
            });
        }
    }
    cargarPeriodo() {
        this.db.cargarPeriodoId(this.datosMaterias[0].id_periodo).then(data => {
            this.datosPeriodo.push(data);
        });
    }
};
InfoModalPage.ctorParameters = () => [
    { type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], InfoModalPage.prototype, "tipo", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], InfoModalPage.prototype, "id", void 0);
InfoModalPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-info-modal',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./info-modal.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./info-modal.page.scss */ "./src/app/pages/info-modal/info-modal.page.scss")).default]
    })
], InfoModalPage);



/***/ })

}]);
//# sourceMappingURL=pages-info-modal-info-modal-module-es2015.js.map