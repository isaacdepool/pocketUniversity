(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-action-sheet-ios.entry.js",
		"common",
		0
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-action-sheet-md.entry.js",
		"common",
		1
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-alert-ios.entry.js",
		"common",
		2
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-alert-md.entry.js",
		"common",
		3
	],
	"./ion-app_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-app_8-ios.entry.js",
		"common",
		4
	],
	"./ion-app_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-app_8-md.entry.js",
		"common",
		5
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-avatar_3-ios.entry.js",
		"common",
		6
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-avatar_3-md.entry.js",
		"common",
		7
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-back-button-ios.entry.js",
		"common",
		8
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-back-button-md.entry.js",
		"common",
		9
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-backdrop-ios.entry.js",
		10
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-backdrop-md.entry.js",
		11
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-button_2-ios.entry.js",
		"common",
		12
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-button_2-md.entry.js",
		"common",
		13
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-card_5-ios.entry.js",
		"common",
		14
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-card_5-md.entry.js",
		"common",
		15
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-checkbox-ios.entry.js",
		"common",
		16
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-checkbox-md.entry.js",
		"common",
		17
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-chip-ios.entry.js",
		"common",
		18
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-chip-md.entry.js",
		"common",
		19
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js",
		20
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-datetime_3-ios.entry.js",
		"common",
		21
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-datetime_3-md.entry.js",
		"common",
		22
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-fab_3-ios.entry.js",
		"common",
		23
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-fab_3-md.entry.js",
		"common",
		24
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-img.entry.js",
		25
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-ios.entry.js",
		26
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-md.entry.js",
		27
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-input-ios.entry.js",
		"common",
		28
	],
	"./ion-input-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-input-md.entry.js",
		"common",
		29
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item-option_3-ios.entry.js",
		"common",
		30
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item-option_3-md.entry.js",
		"common",
		31
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item_8-ios.entry.js",
		"common",
		32
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item_8-md.entry.js",
		"common",
		33
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-loading-ios.entry.js",
		"common",
		34
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-loading-md.entry.js",
		"common",
		35
	],
	"./ion-menu_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-menu_3-ios.entry.js",
		"common",
		36
	],
	"./ion-menu_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-menu_3-md.entry.js",
		"common",
		37
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-modal-ios.entry.js",
		"common",
		38
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-modal-md.entry.js",
		"common",
		39
	],
	"./ion-nav_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-nav_2.entry.js",
		"common",
		40
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-popover-ios.entry.js",
		"common",
		41
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-popover-md.entry.js",
		"common",
		42
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-progress-bar-ios.entry.js",
		"common",
		43
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-progress-bar-md.entry.js",
		"common",
		44
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-radio_2-ios.entry.js",
		"common",
		45
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-radio_2-md.entry.js",
		"common",
		46
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-range-ios.entry.js",
		"common",
		47
	],
	"./ion-range-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-range-md.entry.js",
		"common",
		48
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-refresher_2-ios.entry.js",
		"common",
		49
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-refresher_2-md.entry.js",
		"common",
		50
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-reorder_2-ios.entry.js",
		"common",
		51
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-reorder_2-md.entry.js",
		"common",
		52
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js",
		53
	],
	"./ion-route_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js",
		"common",
		54
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-searchbar-ios.entry.js",
		"common",
		55
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-searchbar-md.entry.js",
		"common",
		56
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-segment_2-ios.entry.js",
		"common",
		57
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-segment_2-md.entry.js",
		"common",
		58
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-select_3-ios.entry.js",
		"common",
		59
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-select_3-md.entry.js",
		"common",
		60
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-slide_2-ios.entry.js",
		61
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-slide_2-md.entry.js",
		62
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js",
		"common",
		63
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-split-pane-ios.entry.js",
		64
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-split-pane-md.entry.js",
		65
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-ios.entry.js",
		"common",
		66
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-md.entry.js",
		"common",
		67
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js",
		"common",
		68
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-text.entry.js",
		"common",
		69
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-textarea-ios.entry.js",
		"common",
		70
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-textarea-md.entry.js",
		"common",
		71
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toast-ios.entry.js",
		"common",
		72
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toast-md.entry.js",
		"common",
		73
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toggle-ios.entry.js",
		"common",
		74
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toggle-md.entry.js",
		"common",
		75
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js",
		76
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn-bd": "./node_modules/moment/locale/bn-bd.js",
	"./bn-bd.js": "./node_modules/moment/locale/bn-bd.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-in": "./node_modules/moment/locale/en-in.js",
	"./en-in.js": "./node_modules/moment/locale/en-in.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./en-sg": "./node_modules/moment/locale/en-sg.js",
	"./en-sg.js": "./node_modules/moment/locale/en-sg.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-mx": "./node_modules/moment/locale/es-mx.js",
	"./es-mx.js": "./node_modules/moment/locale/es-mx.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fil": "./node_modules/moment/locale/fil.js",
	"./fil.js": "./node_modules/moment/locale/fil.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-deva": "./node_modules/moment/locale/gom-deva.js",
	"./gom-deva.js": "./node_modules/moment/locale/gom-deva.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./oc-lnc": "./node_modules/moment/locale/oc-lnc.js",
	"./oc-lnc.js": "./node_modules/moment/locale/oc-lnc.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tk": "./node_modules/moment/locale/tk.js",
	"./tk.js": "./node_modules/moment/locale/tk.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-mo": "./node_modules/moment/locale/zh-mo.js",
	"./zh-mo.js": "./node_modules/moment/locale/zh-mo.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n\n  <app-menu></app-menu>\n  <ion-router-outlet id=\"main\"></ion-router-outlet>\n</ion-app>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/fab/fab.component.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/fab/fab.component.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n  <ion-fab >\n\n    <ion-fab-button color=\"header\"\n    (click)=\"onClick()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n    \n    \n  </ion-fab>\n\n  \n\n\n  \n\n  \n\n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/header/header.component.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/header/header.component.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"header\">\n\n    <ion-buttons slot=\"start\">\n\n      <ion-menu-button \n      menu=\"desp\"></ion-menu-button>\n\n    </ion-buttons>\n\n    <ion-title> {{ titulo }} </ion-title>\n\n    <ion-buttons slot=\"end\">\n\n      <ion-button (click)=\"camara()\"> \n\n        <ion-icon slot=\"icon-only\" name=\"camera\"></ion-icon>\n\n    </ion-button>\n\n    </ion-buttons>\n    \n\n  </ion-toolbar>\n\n  \n</ion-header>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/menu/menu.component.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/menu/menu.component.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-menu side=\"start\" \n  menuId=\"desp\" \n  contentId=\"main\">\n    <ion-header>\n      <ion-toolbar color=\"primary\">\n        \n        <!-- Logo -->\n        <ion-img src=\"/assets/shapes.svg\"></ion-img>\n \n      </ion-toolbar>\n    </ion-header>\n\n    <ion-content\n     class=\"padding\">\n      <ion-list>\n\n        <ion-menu-toggle *ngFor=\"let c of components | async; let id = index\" >\n          \n          <ion-item lines=\"none\"\n          *ngIf=\"c.redirecTo != '/ayuda' && c.redirecTo != '/config'\"\n          [routerLink]=\"c.redirecTo\">\n          \n            <ion-icon slot=\"start\"\n            [name]=\"c.icon\"></ion-icon>\n\n            <ion-label>{{ c.name }}</ion-label>\n\n          </ion-item>\n          \n\n        </ion-menu-toggle>\n\n\n      </ion-list>\n\n      <ion-footer>\n\n        <ion-toolbar>\n\n\n          <ion-list>\n  \n            <ion-menu-toggle\n            *ngFor=\"let c of components | async; let id = index\" >\n            \n              <ion-item lines=\"none\"\n              *ngIf=\"c.redirecTo == '/ayuda' || c.redirecTo == '/config'\"\n              [routerLink]=\"c.redirecTo\">\n                <ion-icon slot=\"start\"\n                [name]=\"c.icon\"></ion-icon>\n                <ion-label>{{ c.name }}</ion-label>\n              </ion-item>\n              \n    \n            </ion-menu-toggle>\n  \n          </ion-list>\n\n        </ion-toolbar>\n        \n      </ion-footer>\n    </ion-content>\n  </ion-menu>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-archivos/popover-archivos.component.html":
/*!*******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-archivos/popover-archivos.component.html ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-list>\n  <ion-item *ngFor=\"let it of opt\"\n  color=\"dark\"\n  lines=\"none\"\n  (click)=\"onClick( it.nombre, it.url )\">\n\n    <!-- <ion-icon slot=\"start\" [name]=\"it.icon\"></ion-icon> -->\n    <ion-label\n    class=\"ion-text-capitalize\">{{ it.nombre }}</ion-label>\n  </ion-item> \n</ion-list>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-options/popover-options.component.html":
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-options/popover-options.component.html ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-list>\n  <ion-item *ngFor=\"let it of items; let i = index;\"\n  lines=\"none\"\n  (click)=\"onClick( it.nombre )\">\n\n    <ion-icon slot=\"start\" [name]=\"it.icon\"></ion-icon>\n    <ion-label class=\"ion-text-capitalize\">{{ it.nombre }}</ion-label>\n  </ion-item> \n</ion-list>\n ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover/popover.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover/popover.component.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-list>\n  <ion-item *ngFor=\"let it of items; let i = index;\"\n  lines = \"none\"\n  (click)=\"onClick( it.nombre )\"l>\n\n    <ion-icon slot=\"start\" [name]=\"it.icon\"></ion-icon>\n    <ion-label class=\"ion-text-capitalize\">{{ it.nombre }}</ion-label>\n  </ion-item> \n</ion-list>\n\n");

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");



const routes = [
    { path: '', redirectTo: 'inicio', pathMatch: 'full' },
    {
        path: 'inicio',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-inicio-inicio-module */ "pages-inicio-inicio-module").then(__webpack_require__.bind(null, /*! ./pages/inicio/inicio.module */ "./src/app/pages/inicio/inicio.module.ts")).then(m => m.InicioPageModule)
    },
    {
        path: 'events',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-events-events-module */ "pages-events-events-module").then(__webpack_require__.bind(null, /*! ./pages/events/events.module */ "./src/app/pages/events/events.module.ts")).then(m => m.EventsPageModule)
    },
    {
        path: 'materias',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-materias-materias-module */ "pages-materias-materias-module").then(__webpack_require__.bind(null, /*! ./pages/materias/materias.module */ "./src/app/pages/materias/materias.module.ts")).then(m => m.MateriasPageModule)
    },
    {
        path: 'horario-clases',
        loadChildren: () => Promise.all(/*! import() | pages-horario-clases-horario-clases-module */[__webpack_require__.e("common"), __webpack_require__.e("pages-horario-clases-horario-clases-module")]).then(__webpack_require__.bind(null, /*! ./pages/horario-clases/horario-clases.module */ "./src/app/pages/horario-clases/horario-clases.module.ts")).then(m => m.HorarioClasesPageModule)
    },
    {
        path: 'config',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-config-config-module */ "pages-config-config-module").then(__webpack_require__.bind(null, /*! ./pages/config/config.module */ "./src/app/pages/config/config.module.ts")).then(m => m.ConfigPageModule)
    },
    {
        path: 'ayuda',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-ayuda-ayuda-module */ "pages-ayuda-ayuda-module").then(__webpack_require__.bind(null, /*! ./pages/ayuda/ayuda.module */ "./src/app/pages/ayuda/ayuda.module.ts")).then(m => m.AyudaPageModule)
    },
    {
        path: 'cuaderno',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-cuaderno-cuaderno-module */ "pages-cuaderno-cuaderno-module").then(__webpack_require__.bind(null, /*! ./pages/cuaderno/cuaderno.module */ "./src/app/pages/cuaderno/cuaderno.module.ts")).then(m => m.CuadernoPageModule)
    },
    {
        path: 'galeria',
        loadChildren: () => Promise.all(/*! import() | pages-galeria-galeria-module */[__webpack_require__.e("default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module~pages-imagen-modal-imagen-mo~3b5b6ad8"), __webpack_require__.e("default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module"), __webpack_require__.e("pages-galeria-galeria-module")]).then(__webpack_require__.bind(null, /*! ./pages/galeria/galeria.module */ "./src/app/pages/galeria/galeria.module.ts")).then(m => m.GaleriaPageModule)
    },
    {
        path: 'agg-evento',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-agg-evento-agg-evento-module */ "pages-agg-evento-agg-evento-module").then(__webpack_require__.bind(null, /*! ./pages/agg-evento/agg-evento.module */ "./src/app/pages/agg-evento/agg-evento.module.ts")).then(m => m.AggEventoPageModule)
    },
    {
        path: 'agg-periodo',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-agg-periodo-agg-periodo-module */ "pages-agg-periodo-agg-periodo-module").then(__webpack_require__.bind(null, /*! ./pages/agg-periodo/agg-periodo.module */ "./src/app/pages/agg-periodo/agg-periodo.module.ts")).then(m => m.AggPeriodoPageModule)
    },
    {
        path: 'agg-materia',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-agg-materia-agg-materia-module */ "pages-agg-materia-agg-materia-module").then(__webpack_require__.bind(null, /*! ./pages/agg-materia/agg-materia.module */ "./src/app/pages/agg-materia/agg-materia.module.ts")).then(m => m.AggMateriaPageModule)
    },
    {
        path: 'cuaderno-id/:idC/:idM',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-cuaderno-id-cuaderno-id-module */ "pages-cuaderno-id-cuaderno-id-module").then(__webpack_require__.bind(null, /*! ./pages/cuaderno-id/cuaderno-id.module */ "./src/app/pages/cuaderno-id/cuaderno-id.module.ts")).then(m => m.CuadernoIdPageModule)
    },
    {
        path: 'materia-id/:id',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-materia-id-materia-id-module */ "pages-materia-id-materia-id-module").then(__webpack_require__.bind(null, /*! ./pages/materia-id/materia-id.module */ "./src/app/pages/materia-id/materia-id.module.ts")).then(m => m.MateriaIdPageModule)
    },
    {
        path: 'carpeta-id',
        loadChildren: () => Promise.all(/*! import() | pages-carpeta-id-carpeta-id-module */[__webpack_require__.e("default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module~pages-imagen-modal-imagen-mo~3b5b6ad8"), __webpack_require__.e("default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module"), __webpack_require__.e("pages-carpeta-id-carpeta-id-module")]).then(__webpack_require__.bind(null, /*! ./pages/carpeta-id/carpeta-id.module */ "./src/app/pages/carpeta-id/carpeta-id.module.ts")).then(m => m.CarpetaIdPageModule)
    },
    {
        path: 'cal-modal',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-cal-modal-cal-modal-module */ "common").then(__webpack_require__.bind(null, /*! ./pages/cal-modal/cal-modal.module */ "./src/app/pages/cal-modal/cal-modal.module.ts")).then(m => m.CalModalPageModule)
    },
    {
        path: 'info-modal',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-info-modal-info-modal-module */ "pages-info-modal-info-modal-module").then(__webpack_require__.bind(null, /*! ./pages/info-modal/info-modal.module */ "./src/app/pages/info-modal/info-modal.module.ts")).then(m => m.InfoModalPageModule)
    },
    {
        path: 'imagen-modal',
        loadChildren: () => Promise.all(/*! import() | pages-imagen-modal-imagen-modal-module */[__webpack_require__.e("default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module~pages-imagen-modal-imagen-mo~3b5b6ad8"), __webpack_require__.e("pages-imagen-modal-imagen-modal-module")]).then(__webpack_require__.bind(null, /*! ./pages/imagen-modal/imagen-modal.module */ "./src/app/pages/imagen-modal/imagen-modal.module.ts")).then(m => m.ImagenModalPageModule)
    },
    {
        path: 'tabs',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-tabs-tabs-module */ "pages-tabs-tabs-module").then(__webpack_require__.bind(null, /*! ./pages/tabs/tabs.module */ "./src/app/pages/tabs/tabs.module.ts")).then(m => m.TabsPageModule)
    },
    {
        path: 'tab1',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-tab1-tab1-module */ "tab1-tab1-module").then(__webpack_require__.bind(null, /*! ./pages/tab1/tab1.module */ "./src/app/pages/tab1/tab1.module.ts")).then(m => m.Tab1PageModule)
    },
    {
        path: 'tabs',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-tabs-tabs-module */ "pages-tabs-tabs-module").then(__webpack_require__.bind(null, /*! ./pages/tabs/tabs.module */ "./src/app/pages/tabs/tabs.module.ts")).then(m => m.TabsPageModule)
    },
    {
        path: 'tab2',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-tab2-tab2-module */ "tab2-tab2-module").then(__webpack_require__.bind(null, /*! ./pages/tab2/tab2.module */ "./src/app/pages/tab2/tab2.module.ts")).then(m => m.Tab2PageModule)
    },
    {
        path: 'tab3',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-tab3-tab3-module */ "tab3-tab3-module").then(__webpack_require__.bind(null, /*! ./pages/tab3/tab3.module */ "./src/app/pages/tab3/tab3.module.ts")).then(m => m.Tab3PageModule)
    },
    {
        path: 'login',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-login-login-module */ "pages-login-login-module").then(__webpack_require__.bind(null, /*! ./pages/login/login.module */ "./src/app/pages/login/login.module.ts")).then(m => m.LoginPageModule)
    },
    {
        path: 'welcome',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-welcome-welcome-module */ "pages-welcome-welcome-module").then(__webpack_require__.bind(null, /*! ./pages/welcome/welcome.module */ "./src/app/pages/welcome/welcome.module.ts")).then(m => m.WelcomePageModule)
    },
    {
        path: 'signup',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-signup-signup-module */ "pages-signup-signup-module").then(__webpack_require__.bind(null, /*! ./pages/signup/signup.module */ "./src/app/pages/signup/signup.module.ts")).then(m => m.SignupPageModule)
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");





let AppComponent = class AppComponent {
    constructor(platform, splashScreen, statusBar) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.initializeApp();
    }
    initializeApp() {
        this.platform.ready().then(() => {
            this.statusBar.styleBlackTranslucent();
            this.splashScreen.hide();
            this.checkDarkmode();
        });
    }
    checkDarkmode() {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
        if (prefersDark.matches) {
            document.body.classList.toggle('dark');
        }
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
    { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"] }
];
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")).default]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/components.module */ "./src/app/components/components.module.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _ionic_native_sqlite_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/sqlite/ngx */ "./node_modules/@ionic-native/sqlite/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_sqlite_porter_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/sqlite-porter/ngx */ "./node_modules/@ionic-native/sqlite-porter/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
/* harmony import */ var _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic-native/image-picker/ngx */ "./node_modules/@ionic-native/image-picker/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic-native/File/ngx */ "./node_modules/@ionic-native/File/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_media_capture_ngx__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic-native/media-capture/ngx */ "./node_modules/@ionic-native/media-capture/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_media_ngx__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ionic-native/media/ngx */ "./node_modules/@ionic-native/media/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_streaming_media_ngx__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic-native/streaming-media/ngx */ "./node_modules/@ionic-native/streaming-media/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic-native/photo-viewer/ngx */ "./node_modules/@ionic-native/photo-viewer/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_Camera_ngx__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ionic-native/Camera/ngx */ "./node_modules/@ionic-native/Camera/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @ionic-native/file-path/ngx */ "./node_modules/@ionic-native/file-path/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic-native/file-chooser/ngx */ "./node_modules/@ionic-native/file-chooser/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ionic-native/ionic-webview/ngx */ "./node_modules/@ionic-native/ionic-webview/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "./node_modules/@ionic-native/social-sharing/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var ionic2_calendar__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ionic2-calendar */ "./node_modules/ionic2-calendar/__ivy_ngcc__/fesm2015/ionic2-calendar.js");
/* harmony import */ var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @ionic-native/local-notifications/ngx */ "./node_modules/@ionic-native/local-notifications/__ivy_ngcc__/ngx/index.js");











//DB 



//Media 














let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"],],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"],
            _components_components_module__WEBPACK_IMPORTED_MODULE_9__["ComponentsModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_10__["HttpClientModule"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_13__["IonicStorageModule"]
        ],
        exports: [],
        providers: [
            _ionic_native_Camera_ngx__WEBPACK_IMPORTED_MODULE_20__["Camera"],
            _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_24__["WebView"],
            _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_27__["LocalNotifications"],
            _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_25__["SocialSharing"],
            ionic2_calendar__WEBPACK_IMPORTED_MODULE_26__["NgCalendarModule"],
            _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_22__["FileChooser"],
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_23__["FileOpener"],
            _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_21__["FilePath"],
            _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_14__["ImagePicker"],
            _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_15__["File"],
            _ionic_native_media_capture_ngx__WEBPACK_IMPORTED_MODULE_16__["MediaCapture"],
            _ionic_native_media_ngx__WEBPACK_IMPORTED_MODULE_17__["Media"],
            _ionic_native_streaming_media_ngx__WEBPACK_IMPORTED_MODULE_18__["StreamingMedia"],
            _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_19__["PhotoViewer"],
            _ionic_native_sqlite_ngx__WEBPACK_IMPORTED_MODULE_11__["SQLite"],
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"],
                useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] },
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
            _ionic_native_sqlite_porter_ngx__WEBPACK_IMPORTED_MODULE_12__["SQLitePorter"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] }
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/components/components.module.ts":
/*!*************************************************!*\
  !*** ./src/app/components/components.module.ts ***!
  \*************************************************/
/*! exports provided: ComponentsModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComponentsModule", function() { return ComponentsModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./header/header.component */ "./src/app/components/header/header.component.ts");
/* harmony import */ var _menu_menu_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./menu/menu.component */ "./src/app/components/menu/menu.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _fab_fab_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./fab/fab.component */ "./src/app/components/fab/fab.component.ts");
/* harmony import */ var _popover_popover_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./popover/popover.component */ "./src/app/components/popover/popover.component.ts");
/* harmony import */ var src_app_pipes_fecha_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/pipes/fecha.pipe */ "./src/app/pipes/fecha.pipe.ts");
/* harmony import */ var _pipes_dia_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../pipes/dia.pipe */ "./src/app/pipes/dia.pipe.ts");
/* harmony import */ var _pipes_hora_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../pipes/hora.pipe */ "./src/app/pipes/hora.pipe.ts");
/* harmony import */ var _popover_options_popover_options_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./popover-options/popover-options.component */ "./src/app/components/popover-options/popover-options.component.ts");
/* harmony import */ var _pipes_filtro_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../pipes/filtro.pipe */ "./src/app/pipes/filtro.pipe.ts");
/* harmony import */ var _popover_archivos_popover_archivos_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./popover-archivos/popover-archivos.component */ "./src/app/components/popover-archivos/popover-archivos.component.ts");















let ComponentsModule = class ComponentsModule {
};
ComponentsModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _header_header_component__WEBPACK_IMPORTED_MODULE_4__["HeaderComponent"],
            _menu_menu_component__WEBPACK_IMPORTED_MODULE_5__["MenuComponent"],
            _fab_fab_component__WEBPACK_IMPORTED_MODULE_7__["FabComponent"],
            _popover_popover_component__WEBPACK_IMPORTED_MODULE_8__["PopoverComponent"],
            _popover_options_popover_options_component__WEBPACK_IMPORTED_MODULE_12__["PopoverOptionsComponent"],
            _popover_archivos_popover_archivos_component__WEBPACK_IMPORTED_MODULE_14__["PopoverArchivosComponent"],
            src_app_pipes_fecha_pipe__WEBPACK_IMPORTED_MODULE_9__["FechaPipe"],
            _pipes_dia_pipe__WEBPACK_IMPORTED_MODULE_10__["DiaPipe"],
            _pipes_hora_pipe__WEBPACK_IMPORTED_MODULE_11__["HoraPipe"],
            _pipes_filtro_pipe__WEBPACK_IMPORTED_MODULE_13__["FiltroPipe"]
        ],
        exports: [
            _header_header_component__WEBPACK_IMPORTED_MODULE_4__["HeaderComponent"],
            _menu_menu_component__WEBPACK_IMPORTED_MODULE_5__["MenuComponent"],
            _fab_fab_component__WEBPACK_IMPORTED_MODULE_7__["FabComponent"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"],
            _popover_options_popover_options_component__WEBPACK_IMPORTED_MODULE_12__["PopoverOptionsComponent"],
            _popover_archivos_popover_archivos_component__WEBPACK_IMPORTED_MODULE_14__["PopoverArchivosComponent"],
            src_app_pipes_fecha_pipe__WEBPACK_IMPORTED_MODULE_9__["FechaPipe"],
            _pipes_dia_pipe__WEBPACK_IMPORTED_MODULE_10__["DiaPipe"],
            _pipes_hora_pipe__WEBPACK_IMPORTED_MODULE_11__["HoraPipe"],
            _pipes_filtro_pipe__WEBPACK_IMPORTED_MODULE_13__["FiltroPipe"]
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"]
        ]
    })
], ComponentsModule);



/***/ }),

/***/ "./src/app/components/fab/fab.component.scss":
/*!***************************************************!*\
  !*** ./src/app/components/fab/fab.component.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-fab-button[data-desc] {\n  position: relative;\n}\n\nion-fab-button[data-desc]::after {\n  position: absolute;\n  content: attr(data-desc);\n  z-index: 1;\n  right: 55px;\n  bottom: 4px;\n  background-color: var(--ion-color-primary);\n  padding: 9px;\n  border-radius: 15px;\n  color: white;\n  box-shadow: 0 3px 5px -1px rgba(0, 0, 0, 0.2), 0 6px 10px 0 rgba(0, 0, 0, 0.14), 0 1px 18px 0 rgba(0, 0, 0, 0.12);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9mYWIvQzpcXFVzZXJzXFxpc2FjXFxEZXNrdG9wXFxpb25pY1xccGFudGFWZXJzaW9uRWR1L3NyY1xcYXBwXFxjb21wb25lbnRzXFxmYWJcXGZhYi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvY29tcG9uZW50cy9mYWIvZmFiLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7QUNDSjs7QURFRTtFQUNFLGtCQUFBO0VBQ0Esd0JBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSwwQ0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxpSEFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9mYWIvZmFiLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWZhYi1idXR0b25bZGF0YS1kZXNjXSB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1mYWItYnV0dG9uW2RhdGEtZGVzY106OmFmdGVyIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGNvbnRlbnQ6IGF0dHIoZGF0YS1kZXNjKTtcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICByaWdodDogNTVweDtcclxuICAgIGJvdHRvbTogNHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgcGFkZGluZzogOXB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJveC1zaGFkb3c6IDAgM3B4IDVweCAtMXB4IHJnYmEoMCwwLDAsMC4yKSwgMCA2cHggMTBweCAwIHJnYmEoMCwwLDAsMC4xNCksIDAgMXB4IDE4cHggMCByZ2JhKDAsMCwwLDAuMTIpO1xyXG4gIH0iLCJpb24tZmFiLWJ1dHRvbltkYXRhLWRlc2NdIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG5pb24tZmFiLWJ1dHRvbltkYXRhLWRlc2NdOjphZnRlciB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgY29udGVudDogYXR0cihkYXRhLWRlc2MpO1xuICB6LWluZGV4OiAxO1xuICByaWdodDogNTVweDtcbiAgYm90dG9tOiA0cHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgcGFkZGluZzogOXB4O1xuICBib3JkZXItcmFkaXVzOiAxNXB4O1xuICBjb2xvcjogd2hpdGU7XG4gIGJveC1zaGFkb3c6IDAgM3B4IDVweCAtMXB4IHJnYmEoMCwgMCwgMCwgMC4yKSwgMCA2cHggMTBweCAwIHJnYmEoMCwgMCwgMCwgMC4xNCksIDAgMXB4IDE4cHggMCByZ2JhKDAsIDAsIDAsIDAuMTIpO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/components/fab/fab.component.ts":
/*!*************************************************!*\
  !*** ./src/app/components/fab/fab.component.ts ***!
  \*************************************************/
/*! exports provided: FabComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FabComponent", function() { return FabComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let FabComponent = class FabComponent {
    constructor(nav) {
        this.nav = nav;
        this.opts = '';
        this.idMateria = '0';
    }
    ngOnInit() {
        if (this.pageEvent) {
            this.opts = '/agg-evento';
        }
        if (this.pageInicio) {
            this.opts = 'Insertar opciones inicio';
        }
        if (this.pageHorario) {
            this.opts = '/agg-materia';
        }
        if (this.pageCuaderno) {
            this.opts = '/agg-materia';
        }
        if (this.pageMaterias) {
            this.opts = 'Insertar opciones materias';
        }
        if (this.pageGaleria) {
            this.opts = 'Insertar opciones Galeria';
        }
        if (this.pageCuadernoId) {
            this.opts = 'Insertar opciones cuaderno';
        }
        if (this.pageMateriaId) {
            this.opts = '/cuaderno-id/0/' + this.idMateria;
        }
        return;
    }
    onClick() {
        this.nav.navigateForward(this.opts);
    }
};
FabComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], FabComponent.prototype, "pageInicio", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], FabComponent.prototype, "pageEvent", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], FabComponent.prototype, "pageMaterias", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], FabComponent.prototype, "pageCuaderno", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], FabComponent.prototype, "pageHorario", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], FabComponent.prototype, "pageGaleria", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], FabComponent.prototype, "pageMateriaId", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], FabComponent.prototype, "pageCuadernoId", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], FabComponent.prototype, "idMateria", void 0);
FabComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-fab',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./fab.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/fab/fab.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./fab.component.scss */ "./src/app/components/fab/fab.component.scss")).default]
    })
], FabComponent);



/***/ }),

/***/ "./src/app/components/header/header.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/components/header/header.component.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/components/header/header.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/header/header.component.ts ***!
  \*******************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_services_galeria_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/galeria.service */ "./src/app/services/galeria.service.ts");




const Media_folder_name = 'Media';
const Local_location_name = "file:///storage/emulated/0/";
let HeaderComponent = class HeaderComponent {
    constructor(menuCtrl, galeriaSvc) {
        this.menuCtrl = menuCtrl;
        this.galeriaSvc = galeriaSvc;
        this.files = [];
        this.url = [];
    }
    ngOnInit() {
    }
    toggleMenu() {
        this.menuCtrl.toggle();
    }
    camara() {
        this.galeriaSvc.getCamera().subscribe(boo => {
            if (boo) {
                this.galeriaSvc.captureImage();
            }
        });
    }
};
HeaderComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"] },
    { type: src_app_services_galeria_service__WEBPACK_IMPORTED_MODULE_3__["GaleriaService"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], HeaderComponent.prototype, "titulo", void 0);
HeaderComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-header',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./header.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/header/header.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./header.component.scss */ "./src/app/components/header/header.component.scss")).default]
    })
], HeaderComponent);



/***/ }),

/***/ "./src/app/components/menu/menu.component.scss":
/*!*****************************************************!*\
  !*** ./src/app/components/menu/menu.component.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvbWVudS9tZW51LmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/components/menu/menu.component.ts":
/*!***************************************************!*\
  !*** ./src/app/components/menu/menu.component.ts ***!
  \***************************************************/
/*! exports provided: MenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuComponent", function() { return MenuComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/data.service */ "./src/app/services/data.service.ts");



let MenuComponent = class MenuComponent {
    constructor(dataService) {
        this.dataService = dataService;
    }
    ngOnInit() {
        this.components = this.dataService.getData();
    }
};
MenuComponent.ctorParameters = () => [
    { type: src_app_services_data_service__WEBPACK_IMPORTED_MODULE_2__["DataService"] }
];
MenuComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-menu',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./menu.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/menu/menu.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./menu.component.scss */ "./src/app/components/menu/menu.component.scss")).default]
    })
], MenuComponent);



/***/ }),

/***/ "./src/app/components/popover-archivos/popover-archivos.component.scss":
/*!*****************************************************************************!*\
  !*** ./src/app/components/popover-archivos/popover-archivos.component.scss ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvcG9wb3Zlci1hcmNoaXZvcy9wb3BvdmVyLWFyY2hpdm9zLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/components/popover-archivos/popover-archivos.component.ts":
/*!***************************************************************************!*\
  !*** ./src/app/components/popover-archivos/popover-archivos.component.ts ***!
  \***************************************************************************/
/*! exports provided: PopoverArchivosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopoverArchivosComponent", function() { return PopoverArchivosComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let PopoverArchivosComponent = class PopoverArchivosComponent {
    constructor(popoverCtrl) {
        this.popoverCtrl = popoverCtrl;
        this.opt = [{ nombre: 'Cargar Archivos' }];
        this.item2 = '';
        this.url2 = '';
    }
    ngOnInit() {
    }
    onClick(item, url) {
        if (item.length > 0) {
            this.item2 = item,
                this.url2 = url;
        }
        this.popoverCtrl.dismiss({
            item: item,
            url: url
        });
    }
};
PopoverArchivosComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], PopoverArchivosComponent.prototype, "opt", void 0);
PopoverArchivosComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-popover-archivos',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./popover-archivos.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-archivos/popover-archivos.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./popover-archivos.component.scss */ "./src/app/components/popover-archivos/popover-archivos.component.scss")).default]
    })
], PopoverArchivosComponent);



/***/ }),

/***/ "./src/app/components/popover-options/popover-options.component.scss":
/*!***************************************************************************!*\
  !*** ./src/app/components/popover-options/popover-options.component.scss ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvcG9wb3Zlci1vcHRpb25zL3BvcG92ZXItb3B0aW9ucy5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/components/popover-options/popover-options.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/components/popover-options/popover-options.component.ts ***!
  \*************************************************************************/
/*! exports provided: PopoverOptionsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopoverOptionsComponent", function() { return PopoverOptionsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let PopoverOptionsComponent = class PopoverOptionsComponent {
    constructor(popoverCtrl) {
        this.popoverCtrl = popoverCtrl;
        this.items = [
            {
                nombre: 'Crear carpeta',
                icon: 'folder-open'
            },
        ];
    }
    ngOnInit() { }
    onClick(item) {
        this.popoverCtrl.dismiss({
            item: item
        });
    }
};
PopoverOptionsComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"] }
];
PopoverOptionsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-popover-options',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./popover-options.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-options/popover-options.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./popover-options.component.scss */ "./src/app/components/popover-options/popover-options.component.scss")).default]
    })
], PopoverOptionsComponent);



/***/ }),

/***/ "./src/app/components/popover/popover.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/components/popover/popover.component.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvcG9wb3Zlci9wb3BvdmVyLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/components/popover/popover.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/components/popover/popover.component.ts ***!
  \*********************************************************/
/*! exports provided: PopoverComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopoverComponent", function() { return PopoverComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let PopoverComponent = class PopoverComponent {
    constructor(popoverCtrl) {
        this.popoverCtrl = popoverCtrl;
        this.opts = {};
        this.items = [
            {
                nombre: 'editar',
                icon: 'create'
            },
            {
                nombre: 'eliminar',
                icon: 'trash'
            },
        ];
    }
    ngOnInit() {
    }
    onClick(valor) {
        this.popoverCtrl.dismiss({
            item: valor
        });
    }
};
PopoverComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"] }
];
PopoverComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-popover',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./popover.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover/popover.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./popover.component.scss */ "./src/app/components/popover/popover.component.scss")).default]
    })
], PopoverComponent);



/***/ }),

/***/ "./src/app/pipes/dia.pipe.ts":
/*!***********************************!*\
  !*** ./src/app/pipes/dia.pipe.ts ***!
  \***********************************/
/*! exports provided: DiaPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DiaPipe", function() { return DiaPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);



let DiaPipe = class DiaPipe {
    transform(value, valid) {
        if ((valid === 'lunes') || (valid === 'martes') || (valid === 'miércoles') || (valid === 'jueves') || (valid === 'viernes') || (valid === 'sábado') || (valid === 'domingo')) {
            return valid;
        }
        else {
            value = new Date(value);
            let fecha = value.toISOString();
            let dia = fecha.toString();
            return moment__WEBPACK_IMPORTED_MODULE_2__(dia).format('DD MMMM YYYY');
        }
    }
};
DiaPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'dia'
    })
], DiaPipe);



/***/ }),

/***/ "./src/app/pipes/fecha.pipe.ts":
/*!*************************************!*\
  !*** ./src/app/pipes/fecha.pipe.ts ***!
  \*************************************/
/*! exports provided: FechaPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FechaPipe", function() { return FechaPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);



let FechaPipe = class FechaPipe {
    transform(value) {
        value = new Date(value);
        let fecha = value.toISOString();
        let dia = fecha.toString();
        return moment__WEBPACK_IMPORTED_MODULE_2__(dia).format('DD MMMM YYYY, hh:mm a');
    }
};
FechaPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'fecha'
    })
], FechaPipe);



/***/ }),

/***/ "./src/app/pipes/filtro.pipe.ts":
/*!**************************************!*\
  !*** ./src/app/pipes/filtro.pipe.ts ***!
  \**************************************/
/*! exports provided: FiltroPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FiltroPipe", function() { return FiltroPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let FiltroPipe = class FiltroPipe {
    transform(arreglo, texto, columna) {
        if (texto === '') {
            return arreglo;
        }
        texto = texto.toLowerCase();
        return arreglo.filter(item => {
            return item[columna].toLowerCase()
                .includes(texto);
        });
    }
};
FiltroPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'filtro'
    })
], FiltroPipe);



/***/ }),

/***/ "./src/app/pipes/hora.pipe.ts":
/*!************************************!*\
  !*** ./src/app/pipes/hora.pipe.ts ***!
  \************************************/
/*! exports provided: HoraPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HoraPipe", function() { return HoraPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);



let HoraPipe = class HoraPipe {
    transform(value) {
        value = new Date(value);
        let fecha = value.toISOString();
        let dia = fecha.toString();
        return moment__WEBPACK_IMPORTED_MODULE_2__(dia).format('hh:mm a');
    }
};
HoraPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'hora'
    })
], HoraPipe);



/***/ }),

/***/ "./src/app/services/data.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/data.service.ts ***!
  \******************************************/
/*! exports provided: DataService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataService", function() { return DataService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");



let DataService = class DataService {
    constructor(http) {
        this.http = http;
    }
    getData() {
        return this.http.get('/assets/data/menu.json');
    }
    getYoutube() {
        return this.http.get('https://www.googleapis.com/youtube/v3/search?part=snippet&q=clases%de%20ingles&type=video&key=AIzaSyA6DilEzJe0GK-Y_5la5uYQjiDt41-zM74&');
    }
};
DataService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
DataService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], DataService);



/***/ }),

/***/ "./src/app/services/db.service.ts":
/*!****************************************!*\
  !*** ./src/app/services/db.service.ts ***!
  \****************************************/
/*! exports provided: DatabaseService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DatabaseService", function() { return DatabaseService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_native_sqlite_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/sqlite/ngx */ "./node_modules/@ionic-native/sqlite/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_sqlite_porter_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/sqlite-porter/ngx */ "./node_modules/@ionic-native/sqlite-porter/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");







let DatabaseService = class DatabaseService {
    constructor(platform, sqlitePorter, sqlite, http) {
        this.platform = platform;
        this.sqlitePorter = sqlitePorter;
        this.sqlite = sqlite;
        this.http = http;
        this.dbReady = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"](false);
        this.usuario = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.materias = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.evento = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.periodo = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.cuaderno = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.fotos = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.carpeta = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.archivos = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.finanzas = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.id_materia = 0;
        this.id_evento = 0;
        this.id_cuaderno = 0;
        this.id_carpeta = 0;
        //Abrir BDD      
        this.platform.ready().then(() => {
            this.sqlite.create({
                name: 'ionic.db',
                location: 'default'
            })
                .then((db) => {
                this.database = db;
                this.seedDatabase();
            });
        });
    }
    seedDatabase() {
        this.http.get('/assets/data/base.sql', { responseType: 'text' })
            .subscribe(sql => {
            this.sqlitePorter.importSqlToDb(this.database, sql)
                .then(_ => {
                this.cargarUsuario();
                this.cargarMaterias();
                this.cargarEvento();
                this.cargarPeriodo();
                this.cargarCuaderno();
                this.cargarFotos();
                this.cargarCarpeta();
                this.cargarArchivo();
                this.cargarFinanzas();
                this.dbReady.next(true);
            })
                .catch(e => console.error(e));
        });
    }
    getDatabaseState() {
        return this.dbReady.asObservable();
    }
    getUser() {
        return this.usuario.asObservable();
    }
    getMaterias() {
        return this.materias.asObservable();
    }
    getEvento() {
        return this.evento.asObservable();
    }
    getPeriodo() {
        return this.periodo.asObservable();
    }
    getCuaderno() {
        return this.cuaderno.asObservable();
    }
    getFotos() {
        return this.fotos.asObservable();
    }
    getCarpeta() {
        return this.carpeta.asObservable();
    }
    getArchivo() {
        return this.archivos.asObservable();
    }
    getGasto() {
        return this.finanzas.asObservable();
    }
    // CRUD Usuario   
    cargarUsuario() {
        return this.database.executeSql('SELECT * FROM usuario', []).then(data => {
            let usuarios = [];
            if (data.rows.length > 0) {
                for (var i = 0; i < data.rows.length; i++) {
                    usuarios.push({
                        id: data.rows.item(i).id,
                        nombre: data.rows.item(i).nombre,
                        apellido: data.rows.item(i).apellido,
                        avatar: data.rows.item(i).avatar
                    });
                }
            }
            this.usuario.next(usuarios);
        });
    }
    agregarUsuario(name, apellido, avatar) {
        let data = [name, apellido, avatar];
        return this.database.executeSql('INSERT INTO usuario (nombre, apellido, avatar) VALUES (?, ?, ?)', data).then(data => {
            this.cargarUsuario();
        });
    }
    getUsuario(id) {
        return this.database.executeSql('SELECT * FROM usuario WHERE id = ?', [id]).then(data => {
            return {
                id: data.rows.item(0).id,
                nombre: data.rows.item(0).nombre,
                apellido: data.rows.item(0).apellido,
                avatar: data.rows.item(0).avatar
            };
        });
    }
    eliminarUsuario(id) {
        return this.database.executeSql('DELETE FROM usuario WHERE id = ?', [id])
            .then(_ => {
            this.cargarUsuario();
            this.cargarMaterias();
        });
    }
    updateUsuario(dev) {
        let data = [dev.nombre, dev.apellido, dev.avatar];
        return this.database.executeSql(`UPDATE usuario SET nombre = ?, apellido = ?, avatar = ? WHERE id = ${dev.id}`, data).then(data => {
            this.cargarUsuario();
        });
    }
    // CRUD Materias
    cargarMaterias() {
        let query = 'SELECT materias.nombre, materias.id, id_usuario, id_periodo, id_evento, usuario.nombre AS usuario FROM materias JOIN usuario ON usuario.id = materias.id_usuario';
        return this.database.executeSql(query, [])
            .then(data => {
            let materias = [];
            if (data.rows.length > 0) {
                for (var i = 0; i < data.rows.length; i++) {
                    materias.push({
                        nombre: data.rows.item(i).nombre,
                        id: data.rows.item(i).id,
                        id_usuario: data.rows.item(i).id_usuario,
                        id_periodo: data.rows.item(i).id_periodo,
                        id_evento: data.rows.item(i).id_evento,
                        usuario: data.rows.item(i).usuario,
                    });
                    this.id_materia = data.rows.item(i).id;
                }
            }
            this.materias.next(materias);
            return this.id_materia;
        });
    }
    cargarMateriaId(id) {
        return this.database.executeSql('SELECT * FROM materias WHERE id = ?', [id])
            .then(data => {
            return {
                id: data.rows.item(0).id,
                nombre: data.rows.item(0).nombre,
                id_usuario: data.rows.item(0).id_usuario,
                id_periodo: data.rows.item(0).id_periodo,
                id_evento: data.rows.item(0).id_evento,
            };
        });
    }
    cargarMateriaPeriodo(id) {
        return this.database.executeSql('SELECT * FROM materias WHERE id_periodo = ?', [id])
            .then(data => {
            let materias = [];
            if (data.rows.length > 0) {
                for (var i = 0; i < data.rows.length; i++) {
                    materias.push({
                        id: data.rows.item(i).id,
                        nombre: data.rows.item(i).nombre,
                        id_usuario: data.rows.item(i).id_usuario,
                        id_periodo: data.rows.item(i).id_periodo,
                        id_evento: data.rows.item(i).id_evento,
                    });
                }
            }
            return materias;
        });
    }
    cargarMateriaEvento(id) {
        return this.database.executeSql('SELECT * FROM materias WHERE id_evento = ?', [id])
            .then(data => {
            let materias = [];
            if (data.rows.length > 0) {
                for (var i = 0; i < data.rows.length; i++) {
                    materias.push({
                        id: data.rows.item(i).id,
                        nombre: data.rows.item(i).nombre,
                        id_usuario: data.rows.item(i).id_usuario,
                        id_periodo: data.rows.item(i).id_periodo,
                        id_evento: data.rows.item(i).id_evento,
                    });
                }
            }
            return materias;
        });
    }
    agregarMaterias(nombre, id_usuario, id_periodo, id_evento) {
        let data = [nombre, id_usuario, id_periodo, id_evento];
        return this.database.executeSql('INSERT INTO materias (nombre, id_usuario, id_periodo, id_evento) VALUES (?, ?, ?, ?)', data).
            then(_ => {
            this.cargarMaterias();
            return this.id_materia + 1;
        });
    }
    updateMaterias(id, nombre, id_periodo) {
        let data = [nombre, id_periodo];
        return this.database.executeSql(`UPDATE materias SET nombre = ?, id_periodo = ? WHERE id = ${id}`, data)
            .then(_ => {
            this.cargarMaterias();
        });
    }
    eliminarMateriasPeriodo(id) {
        return this.database.executeSql('DELETE FROM materias WHERE id_periodo = ?', [id])
            .then(_ => {
            this.cargarMaterias();
        });
    }
    eliminarMaterias(id) {
        return this.database.executeSql('DELETE FROM materias WHERE id = ?', [id])
            .then(_ => {
            this.cargarMaterias();
        });
    }
    //CRUD EVENTO 
    cargarEvento() {
        let query = 'SELECT evento.id, evento.nombre, evento.dia, evento.inicio, evento.fin, evento.tipo, evento.comentario, evento.id_usuario FROM evento JOIN usuario ON usuario.id = evento.id_usuario';
        return this.database.executeSql(query, [])
            .then(data => {
            let evento = [];
            if (data.rows.length > 0) {
                for (var i = 0; i < data.rows.length; i++) {
                    evento.push({
                        id: data.rows.item(i).id,
                        nombre: data.rows.item(i).nombre,
                        dia: data.rows.item(i).dia,
                        inicio: data.rows.item(i).inicio,
                        fin: data.rows.item(i).fin,
                        tipo: data.rows.item(i).tipo,
                        comentario: data.rows.item(i).comentario,
                        id_usuario: data.rows.item(i).id_usuario,
                    });
                    this.id_evento = data.rows.item(i).id;
                }
            }
            this.evento.next(evento);
            return this.id_evento;
        });
    }
    agregarEvento(nombre, dia, inicio, fin, tipo, comentario, id_usuario) {
        let data = [nombre, dia, inicio, fin, tipo, comentario, id_usuario];
        return this.database.executeSql('INSERT INTO evento (nombre, dia, inicio, fin, tipo, comentario, id_usuario) VALUES (?,?,?,?,?,?,?)', data)
            .then(data => {
            this.cargarEvento();
            return this.id_evento + 1;
        });
    }
    cargarEventoId(id) {
        return this.database.executeSql('SELECT * FROM evento WHERE id = ?', [id])
            .then(data => {
            return {
                id: data.rows.item(0).id,
                nombre: data.rows.item(0).nombre,
                dia: data.rows.item(0).dia,
                inicio: data.rows.item(0).inicio,
                fin: data.rows.item(0).fin,
                tipo: data.rows.item(0).tipo,
                comentario: data.rows.item(0).comentario,
                id_usuario: data.rows.item(0).id_usuario
            };
        });
    }
    eliminarEvento(id) {
        return this.database.executeSql('DELETE FROM evento WHERE id = ?', [id])
            .then(_ => {
            this.cargarEvento();
        });
    }
    updateEvento(id, nombre, dia, inicio, fin, tipo, comentario) {
        let data = [nombre, dia, inicio, fin, tipo, comentario];
        return this.database.executeSql(`UPDATE evento SET nombre = ?, dia = ?, inicio = ?, fin = ?, tipo = ?, comentario = ? WHERE id = ${id}`, data)
            .then(data => {
            this.cargarEvento();
        });
    }
    // CRUD Periodo
    cargarPeriodo() {
        let query = 'SELECT periodo.id, periodo.nombre, periodo.id_usuario, usuario.nombre AS usuario FROM periodo JOIN usuario ON usuario.id = periodo.id_usuario';
        return this.database.executeSql(query, [])
            .then(data => {
            let periodo = [];
            if (data.rows.length > 0) {
                for (var i = 0; i < data.rows.length; i++) {
                    periodo.push({
                        id: data.rows.item(i).id,
                        nombre: data.rows.item(i).nombre,
                        id_usuario: data.rows.item(i).id_usuario,
                        usuario: data.rows.item(i).usuario,
                    });
                }
            }
            this.periodo.next(periodo);
        });
    }
    cargarPeriodoId(id) {
        return this.database.executeSql('SELECT * FROM periodo WHERE id = ?', [id])
            .then(data => {
            return {
                id: data.rows.item(0).id,
                nombre: data.rows.item(0).nombre,
                id_usuario: data.rows.item(0).id_usuario,
            };
        });
    }
    agregarPeriodo(nombre, id_usuario) {
        let data = [nombre, id_usuario];
        return this.database.executeSql('INSERT INTO periodo (nombre, id_usuario) VALUES (?,?)', data)
            .then(_ => {
            this.cargarPeriodo();
        });
    }
    updatePeriodo(id, nombre) {
        let data = [nombre];
        return this.database.executeSql(`UPDATE periodo SET nombre = ? WHERE id = ${id}`, data).
            then(_ => {
            this.cargarPeriodo();
        });
    }
    eliminarPeriodo(id) {
        return this.database.executeSql('DELETE FROM periodo WHERE id = ?', [id])
            .then(_ => {
            this.cargarPeriodo();
        });
    }
    // CRUD Cuaderno
    cargarCuaderno() {
        let query = 'SELECT * FROM cuaderno';
        return this.database.executeSql(query, [])
            .then(data => {
            let cuaderno = [];
            if (data.rows.length > 0) {
                for (var i = 0; i < data.rows.length; i++) {
                    cuaderno.push({
                        id: data.rows.item(i).id,
                        titulo: data.rows.item(i).titulo,
                        fecha_crea: data.rows.item(i).fecha_crea,
                        fecha_mod: data.rows.item(i).fecha_mod,
                        contenido: data.rows.item(i).contenido,
                        id_usuario: data.rows.item(i).id_usuario,
                        id_materia: data.rows.item(i).id_materia
                    });
                    this.id_cuaderno = data.rows.item(i).id;
                }
            }
            this.cuaderno.next(cuaderno);
        });
    }
    cargarCuadernoId(id) {
        return this.database.executeSql('SELECT * FROM cuaderno WHERE id = ?', [id])
            .then(data => {
            return {
                id: data.rows.item(0).id,
                titulo: data.rows.item(0).titulo,
                fecha_crea: data.rows.item(0).fecha_crea,
                fecha_mod: data.rows.item(0).fecha_mod,
                contenido: data.rows.item(0).contenido,
                id_usuario: data.rows.item(0).id_usuario,
                id_materia: data.rows.item(0).id_materia,
            };
        });
    }
    agregarCuaderno(titulo, fecha_crea, fecha_mod, contenido, id_materia) {
        let data = [titulo, fecha_crea, fecha_mod, contenido, id_materia];
        return this.database.executeSql('INSERT INTO cuaderno (titulo, fecha_crea, fecha_mod, contenido, id_materia) values (?,?,?,?,?)', data)
            .then(_ => {
            this.cargarCuaderno();
            return this.id_cuaderno + 1;
        });
    }
    updateCuaderno(id, titulo, fecha_crea, fecha_mod, contenido, id_materia) {
        let data = [titulo, fecha_crea, fecha_mod, contenido, id_materia];
        return this.database.executeSql(`UPDATE cuaderno SET titulo = ?, fecha_crea = ?, fecha_mod = ?, contenido = ?, id_materia = ? WHERE id = ${id}`, data)
            .then(_ => {
            this.cargarCuaderno();
        });
    }
    eliminarCuaderno(id) {
        return this.database.executeSql('DELETE FROM cuaderno WHERE id = ?', [id])
            .then(_ => {
            this.cargarCuaderno();
        });
    }
    eliminarCuadernoPeriodo(id) {
        return this.database.executeSql('DELETE FROM cuaderno WHERE id_materia = ?', [id])
            .then(_ => {
            this.cargarCuaderno();
        });
    }
    // CRUD Fotos
    cargarFotos() {
        let query = 'SELECT * FROM fotos';
        return this.database.executeSql(query, [])
            .then(data => {
            let fotos = [];
            if (data.rows.length > 0) {
                for (var i = 0; i < data.rows.length; i++) {
                    fotos.push({
                        id: data.rows.item(i).id,
                        nombre: data.rows.item(i).nombre,
                        url: data.rows.item(i).url,
                        fecha: data.rows.item(i).fecha,
                        favorito: data.rows.item(i).favorito,
                        id_carpeta: data.rows.item(i).id_carpeta,
                        id_usuario: data.rows.item(i).id_usuario,
                    });
                }
            }
            this.fotos.next(fotos);
        });
    }
    agregarFotos(nombre, url, fecha, id_carpeta, id_usuario) {
        let data = [nombre, url, fecha, 0, id_carpeta, id_usuario];
        return this.database.executeSql('INSERT INTO fotos (nombre, url, fecha, favorito, id_carpeta, id_usuario) values (?,?,?,?,?,?)', data)
            .then(_ => {
            this.cargarFotos();
        });
    }
    eliminarFotos(id) {
        return this.database.executeSql('DELETE FROM fotos WHERE id = ?', [id])
            .then(_ => {
            this.cargarFotos();
        });
    }
    updateFotosFav(id, fav) {
        let data = [fav];
        return this.database.executeSql(`UPDATE fotos SET favorito = ? WHERE id = ${id}`, data)
            .then(data => {
            this.cargarFotos();
        });
    }
    eliminarFotosCarpeta(id) {
        return this.database.executeSql('DELETE FROM fotos WHERE id_carpeta = ?', [id])
            .then(_ => {
            this.cargarFotos();
        });
    }
    // CRUD Carpeta 
    cargarCarpeta() {
        let query = 'SELECT * FROM carpeta';
        return this.database.executeSql(query, [])
            .then(data => {
            let carpetas = [];
            if (data.rows.length > 0) {
                for (var i = 0; i < data.rows.length; i++) {
                    carpetas.push({
                        id: data.rows.item(i).id,
                        nombre: data.rows.item(i).nombre,
                        id_usuario: data.rows.item(i).id_usuario,
                        id_materia: data.rows.item(i).id_materia,
                    });
                    this.id_carpeta = data.rows.item(i).id;
                }
            }
            this.carpeta.next(carpetas);
        });
    }
    cargarCarpetaId(id) {
        return this.database.executeSql('SELECT * FROM carpeta WHERE id = ?', [id])
            .then(data => {
            return {
                id: data.rows.item(0).id,
                nombre: data.rows.item(0).nombre,
                id_usuario: data.rows.item(0).id_usuario,
                id_materia: data.rows.item(0).id_materia,
            };
        });
    }
    agregarCarpeta(nombre, id_usuario, id_materia) {
        let data = [nombre, id_usuario, id_materia];
        return this.database.executeSql('INSERT INTO carpeta (nombre, id_usuario, id_materia) VALUES (?,?,?)', data)
            .then(_ => {
            this.cargarCarpeta();
            return this.id_carpeta + 1;
        });
    }
    agregarCarpetaPreder() {
        let id = 1;
        let nombre = 'Otros';
        let data = [id, nombre];
        return this.database.executeSql(`INSERT INTO carpeta (id, nombre) VALUES (?,?)`, data)
            .then(_ => {
            this.cargarCarpeta();
        });
    }
    eliminarCarpeta(id) {
        return this.database.executeSql('DELETE FROM carpeta WHERE id = ?', [id])
            .then(_ => {
            this.cargarCarpeta();
        });
    }
    updateCarpeta(id, nombre) {
        let data = [nombre];
        return this.database.executeSql(`UPDATE carpeta SET nombre = ? WHERE id_materia = ${id}`, data)
            .then(_ => {
            this.cargarCarpeta();
        });
    }
    updateCarpetaLibre(id, nombre) {
        let data = [nombre];
        return this.database.executeSql(`UPDATE carpeta SET nombre = ? WHERE id = ${id}`, data)
            .then(_ => {
            this.cargarCarpeta();
        });
    }
    // CRUD Archivos 
    cargarArchivo() {
        let query = 'SELECT * FROM archivos';
        return this.database.executeSql(query, [])
            .then(data => {
            let archivos = [];
            if (data.rows.length > 0) {
                for (var i = 0; i < data.rows.length; i++) {
                    archivos.push({
                        id: data.rows.item(i).id,
                        nombre: data.rows.item(i).nombre,
                        url: data.rows.item(i).url,
                        id_usuario: data.rows.item(i).id_usuario,
                        id_cuaderno: data.rows.item(i).id_cuaderno,
                    });
                }
            }
            this.archivos.next(archivos);
        });
    }
    agregarArchivos(url, nombre, id_usuario, id_cuaderno) {
        let data = [url, nombre, id_usuario, id_cuaderno];
        return this.database.executeSql('INSERT INTO archivos (url, nombre, id_usuario, id_cuaderno) VALUES (?,?,?,?)', data)
            .then(_ => {
            this.cargarArchivo();
        });
    }
    cargarArchivosCuaderno(id) {
        return this.database.executeSql('SELECT * FROM archivos WHERE id_cuaderno = ?', [id])
            .then(data => {
            let archivos = [];
            if (data.rows.length > 0) {
                for (var i = 0; i < data.rows.length; i++) {
                    archivos.push({
                        nombre: data.rows.item(i).nombre,
                        url: data.rows.item(i).url,
                    });
                }
            }
            return archivos;
        });
    }
    eliminarArchivoCuaderno(id) {
        return this.database.executeSql('DELETE FROM archivos WHERE id_cuaderno = ?', [id])
            .then(_ => {
            this.cargarArchivo();
        });
    }
    // CRUD Finanzas
    cargarFinanzas() {
        let query = 'SELECT * FROM finanzas';
        return this.database.executeSql(query, [])
            .then(data => {
            let finanzas = [];
            if (data.rows.length > 0) {
                for (var i = 0; i < data.rows.length; i++) {
                    finanzas.push({
                        id: data.rows.item(i).id,
                        gasto: data.rows.item(i).gasto,
                        tipo_gasto: data.rows.item(i).tipo_gasto,
                        descripcion: data.rows.item(i).descripcion,
                        fecha: data.rows.item(i).fecha,
                        icono: data.rows.item(i).icono,
                        id_usuario: data.rows.item(i).id_usuario,
                    });
                }
            }
            this.finanzas.next(finanzas);
        });
    }
    cargarFinanzasId(id) {
        // return this.database.executeSql('SELECT * FROM finanzas WHERE id = ?', [id])
        return this.database.executeSql('SELECT * FROM finanzas WHERE id = ?'[id])
            .then(data => {
            return {
                id: data.rows.item(0).id,
                gasto: data.rows.item(0).gasto,
                tipo_gasto: data.rows.item(0).tipo_gasto,
                descripcion: data.rows.item(0).descripcion,
                fecha: data.rows.item(0).fecha,
                icono: data.rows.item(0).icono,
                id_usuario: data.rows.item(0).id_usuario,
            };
        });
    }
    agregarGasto(gasto, tipo_gasto, descripcion, fecha, icono, id_usuario) {
        let data = [gasto, tipo_gasto, descripcion, fecha, icono, id_usuario];
        return this.database.executeSql('INSERT INTO finanzas (gasto, tipo_gasto, descripcion, fecha,icono ,id_usuario) VALUES (?,?,?,?,?,?)', data)
            .then(_ => {
            this.cargarFinanzas();
        });
    }
    eliminarGasto(id) {
        return this.database.executeSql('DELETE FROM finanzas WHERE id = ?', [id])
            .then(_ => {
            this.cargarFinanzas();
        });
    }
};
DatabaseService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] },
    { type: _ionic_native_sqlite_porter_ngx__WEBPACK_IMPORTED_MODULE_5__["SQLitePorter"] },
    { type: _ionic_native_sqlite_ngx__WEBPACK_IMPORTED_MODULE_2__["SQLite"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"] }
];
DatabaseService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], DatabaseService);



/***/ }),

/***/ "./src/app/services/galeria.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/galeria.service.ts ***!
  \*********************************************/
/*! exports provided: GaleriaService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GaleriaService", function() { return GaleriaService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_native_media_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/media/ngx */ "./node_modules/@ionic-native/media/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_media_capture_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/media-capture/ngx */ "./node_modules/@ionic-native/media-capture/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/File/ngx */ "./node_modules/@ionic-native/File/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _db_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./db.service */ "./src/app/services/db.service.ts");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);









const Media_folder_name = 'Myapp';
const Local_location_name = "file:///storage/emulated/0/";
const Media_folder_name_Galeria = 'Galeria';
const Local_location_name_Galeria = "file:///storage/emulated/0/Myapp/";
let GaleriaService = class GaleriaService {
    constructor(file, media, mediaCapture, plt, db, alert) {
        this.file = file;
        this.media = media;
        this.mediaCapture = mediaCapture;
        this.plt = plt;
        this.db = db;
        this.alert = alert;
        this.fileReady = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"](false);
        this.fecha = new Date();
        this.files = [];
        this.url_img = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"]([]);
        this.materias = [];
        this.eventos = [];
        this.carpeta = [];
        this.foto = {
            nombre: '',
            url: '',
            fecha: this.fecha,
            id_usuario: 1,
            id_carpeta: 0
        };
        this.Materia = {
            id_materia: 0,
            dia: '',
            inicio: '',
            fin: ''
        };
        this.plt.ready().then(() => {
            // Crear carpeta 
            // Raiz 
            let path = this.file.dataDirectory;
            this.file.checkDir(path, Media_folder_name_Galeria)
                .then(() => {
                this.cargarArchivos();
            }, err => {
                this.file.createDir(path, Media_folder_name_Galeria, false);
            });
            // LOCAL 
            // MyApp
            let path2 = Local_location_name;
            this.file.checkDir(path2, Media_folder_name)
                .then(() => {
                this.cargarArchivos();
            }, err => {
                this.file.createDir(path2, Media_folder_name, false);
            });
            // Galeria
            let path3 = Local_location_name_Galeria;
            this.file.checkDir(path3, Media_folder_name_Galeria)
                .then(() => {
            }, err => {
                this.file.createDir(path3, Media_folder_name_Galeria, false);
            });
            this.fileReady.next(true);
        });
    }
    getCamera() {
        return this.fileReady.asObservable();
    }
    guardarFoto(id) {
        this.foto.id_carpeta = id;
        this.db.agregarFotos(this.foto.nombre, this.foto.url, this.foto.fecha, this.foto.id_carpeta, this.foto.id_usuario);
    }
    cargarArchivos() {
        this.file.listDir(this.file.dataDirectory, Media_folder_name_Galeria)
            .then((data) => {
            if (data.length > 0) {
                this.files = data;
            }
        }, err => console.log('error al cargar archivos', err));
    }
    captureImage() {
        this.mediaCapture.captureImage({ limit: 1 })
            .then((data) => {
            this.cargarMateria(data[0].fullPath, data);
        }, (err) => console.log(err));
    }
    copyFileToLocalDir(fullPath, data, id) {
        let myPath = fullPath;
        if (fullPath.indexOf('file://') < 0) {
            myPath = 'file://' + fullPath;
        }
        const ext = myPath.split('.').pop();
        const d = Date.now();
        const newName = `${d}.${ext}`;
        const name = myPath.substr(myPath.lastIndexOf('/') + 1);
        const copyFrom = myPath.substr(0, myPath.lastIndexOf('/') + 1);
        const copyToLocal = Local_location_name_Galeria + Media_folder_name_Galeria;
        const copyToNative = this.file.dataDirectory + Media_folder_name_Galeria;
        this.file.copyFile(copyFrom, name, copyToLocal, newName)
            .then(success => {
            console.log(success);
            this.cargarArchivos();
        }, err => {
            console.log(err);
        });
        this.file.copyFile(copyFrom, name, copyToNative, newName)
            .then(success => {
            this.cargarArchivos();
            this.full = success;
            this.foto.nombre = success.name;
            this.foto.url = success.nativeURL;
            this.guardarFoto(id);
            this.deleteFileLocal(data);
        }, err => {
            console.log(err);
        });
    }
    openFile(f) {
        if (f.name.indexOf('.wav') > -1) {
            // We need to remove file:/// from the path for the audio plugin to work
            const path = f.nativeURL.replace(/^file:\/\//, '');
            const audioFile = this.media.create(path);
            audioFile.play();
            // }else if (f.name.indexOf('.MOV') > -1  || f.name.indexOf('.mp4') > -1){
            // // E.g: Use the Streaming Media plugin to play a video  
            //   this.streamingMedia.playVideo(f.nativeURL);
            // } else if(f.name.indexOf('jpg') > -1){
            //     // E.g: Use the Photoviewer to present an Image
            //     this.photoViewer.show(f.nativeURL, 'MY awesome image');
        }
    }
    deleteFile(f) {
        const path = f.nativeURL.substr(0, f.nativeURL.lastIndexOf('/') + 1);
        this.file.removeFile(path, f.name).then(() => {
            this.cargarArchivos();
        }, err => console.log('error remove: ', err));
    }
    deleteFileGaleria(nombre) {
        const n = Local_location_name_Galeria + Media_folder_name_Galeria + '/';
        const path = n.substr(0, n.lastIndexOf('/') + 1);
        console.log(path, nombre);
        this.file.removeFile(path, nombre).then(() => {
            this.cargarArchivos();
        }, err => console.log('error remove: ', err));
    }
    deleteFileRoot(f, nombre) {
        const path = f.substr(0, f.lastIndexOf('/') + 1);
        this.file.removeFile(path, nombre).then(() => {
            console.log(path, nombre);
            this.cargarArchivos();
        }, err => console.log('error remove: ', err));
    }
    deleteFileLocal(f) {
        const path = f[0].fullPath.substr(0, f[0].fullPath.lastIndexOf('/') + 1);
        this.file.removeFile(path, f[0].name).then(() => {
            this.cargarArchivos();
        }, err => console.log('error remove: ', err));
    }
    b64(fullPath) {
        let myPath = fullPath;
        if (fullPath.indexOf('file://') < 0) {
            myPath = 'file://' + fullPath;
        }
        var imagePath = myPath.substr(0, myPath.lastIndexOf('/') + 1);
        var imageName = myPath.substr(myPath.lastIndexOf('/') + 1);
        return this.file.readAsDataURL(imagePath, imageName);
    }
    cargarMateria(fullPath, data) {
        this.db.getMaterias().subscribe((dat) => {
            this.materias = dat;
            this.cargarDB(fullPath, data);
        }).unsubscribe();
    }
    cargarDB(fullPath, data) {
        this.db.getEvento().subscribe(dat => {
            this.eventos = dat;
            this.db.getCarpeta().subscribe(dat => {
                this.carpeta = dat;
                this.validarFecha(fullPath, data);
            }).unsubscribe();
        }).unsubscribe();
    }
    validarFecha(fullPath, data) {
        let hora = moment__WEBPACK_IMPORTED_MODULE_8__(this.fecha).format("hh:mm a");
        let dia = moment__WEBPACK_IMPORTED_MODULE_8__(this.fecha).format("dddd");
        if (this.eventos.length > 0) {
            for (let ev of this.eventos) {
                for (let mate of this.materias) {
                    if ((ev.dia === dia)) {
                        if (mate.id_evento === ev.id) {
                            if (moment__WEBPACK_IMPORTED_MODULE_8__(ev.inicio).format("hh:mm a") <= hora && moment__WEBPACK_IMPORTED_MODULE_8__(ev.fin).format("hh:mm a") >= hora) {
                                return this.opts(mate.id, mate.nombre, fullPath, data);
                            }
                        }
                    }
                }
            }
            this.opts(0, "Otros", fullPath, data);
        }
        else
            return this.opts(0, "Otros", fullPath, data);
    }
    opts(id, carpeta, fullPath, data) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let mensaje = '';
            let input = { data: [] };
            for (let car of this.carpeta) {
                input.data.push({ name: car.nombre, type: 'radio', value: car.id, label: car.nombre, checked: carpeta == car.nombre });
            }
            if (carpeta !== 'Otros') {
                mensaje = 'Estas en clases \'' + carpeta + '\'';
            }
            const alert = yield this.alert.create({
                cssClass: 'my-custom-class',
                header: 'Donde quieres guardar la imagen?',
                message: mensaje,
                inputs: input.data,
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                        }
                    }, {
                        text: 'Ok',
                        handler: (dat) => {
                            if (dat < 0) {
                                this.db.agregarCarpeta(carpeta, 1, id).then(data => {
                                });
                                this.copyFileToLocalDir(fullPath, data, 1);
                            }
                            if (this.carpeta.length == 0) {
                                this.db.agregarCarpetaPreder().then(_ => {
                                    this.copyFileToLocalDir(fullPath, data, 1);
                                });
                            }
                            else {
                                this.copyFileToLocalDir(fullPath, data, dat);
                            }
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
GaleriaService.ctorParameters = () => [
    { type: _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_5__["File"] },
    { type: _ionic_native_media_ngx__WEBPACK_IMPORTED_MODULE_2__["Media"] },
    { type: _ionic_native_media_capture_ngx__WEBPACK_IMPORTED_MODULE_3__["MediaCapture"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] },
    { type: _db_service__WEBPACK_IMPORTED_MODULE_7__["DatabaseService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] }
];
GaleriaService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], GaleriaService);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/__ivy_ngcc__/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\isac\Desktop\ionic\pantaVersionEdu\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map