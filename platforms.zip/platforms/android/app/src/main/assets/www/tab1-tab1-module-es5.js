function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab1-tab1-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab1/tab1.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab1/tab1.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesTab1Tab1PageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<app-header titulo=\"Finanzas\"></app-header>\n\n\n<ion-content>\n    <ion-list>\n        <ion-item class=\"ion-padding\">\n            <h1>Historial de gastos</h1>\n        </ion-item>\n    </ion-list>\n            <ion-list>\n                <ion-item lines=\"none\">\n                    <ion-label slot=\"\" class=\"wei\">Mes</ion-label>\n                        <ion-datetime slot=\"end\"\n                        required\n                        class=\"ion-text-capitalize\"\n                        name=\"dia\" \n                        (ionChange)=\"cargarMes( $event )\" \n                        [monthNames]=\"monthNames\"\n                        displayFormat=\"MMMM YYYY\" \n                        cancelText=\"Cancelar\" \n                        doneText=\"Aceptar\" \n                        max=\"2050\" \n                        min=\"2020\" \n                        [(ngModel)]=\"myDate\">\n                    </ion-datetime>\n                \n                    </ion-item>\n\n                    <ion-item>\n                        <ion-label class=\"wei\">Total gastado</ion-label>\n                        <h2 slot=\"end\" class=\"wei\">${{condecimales}}</h2>\n                    </ion-item>\n            </ion-list>\n\n            <ion-list>\n                \n            </ion-list>\n\n    <ion-list>\n        <ion-item-sliding *ngFor=\"let gasto of dataGasto\">\n            <ion-item>\n                <ion-icon class=\"dere\" [name]=\"gasto.icono\">\n                </ion-icon>\n                <ion-label class=\"mar wei\">\n                    {{gasto.tipo_gasto}}\n                    <h6 >{{gasto.fecha | dia}}</h6>\n                    <h6>{{gasto.descripcion}}</h6>\n                </ion-label>\n\n                <ion-badge class=\"wei\" slot=\"end\" color=\"danger\">${{gasto.gasto}}</ion-badge>\n            </ion-item>\n\n            <ion-item-options side=\"end\">\n                <ion-item-option color=\"danger\" (click)=\"borrar(gasto.id)\">\n                    <ion-icon slot=\"icon-only\" name=\"trash\"></ion-icon>\n                </ion-item-option>\n\n            </ion-item-options>\n        </ion-item-sliding>\n\n    </ion-list>\n\n    <ion-list *ngIf=\"dataGasto.length === 0\">\n        <ion-item lines=\"none\">\n            <ion-label class=\"ion-text-center\"\n            color=\"primary\">Sin Gastos</ion-label>\n        </ion-item>\n    </ion-list>\n\n\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/tab1/tab1-routing.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/pages/tab1/tab1-routing.module.ts ***!
    \***************************************************/

  /*! exports provided: Tab1PageRoutingModule */

  /***/
  function srcAppPagesTab1Tab1RoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Tab1PageRoutingModule", function () {
      return Tab1PageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _tab1_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./tab1.page */
    "./src/app/pages/tab1/tab1.page.ts");

    var routes = [{
      path: '',
      component: _tab1_page__WEBPACK_IMPORTED_MODULE_3__["Tab1Page"]
    }];

    var Tab1PageRoutingModule = function Tab1PageRoutingModule() {
      _classCallCheck(this, Tab1PageRoutingModule);
    };

    Tab1PageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], Tab1PageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/tab1/tab1.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/pages/tab1/tab1.module.ts ***!
    \*******************************************/

  /*! exports provided: Tab1PageModule */

  /***/
  function srcAppPagesTab1Tab1ModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Tab1PageModule", function () {
      return Tab1PageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/components/components.module */
    "./src/app/components/components.module.ts");
    /* harmony import */


    var _tab1_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./tab1-routing.module */
    "./src/app/pages/tab1/tab1-routing.module.ts");
    /* harmony import */


    var _tab1_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./tab1.page */
    "./src/app/pages/tab1/tab1.page.ts");

    var Tab1PageModule = function Tab1PageModule() {
      _classCallCheck(this, Tab1PageModule);
    };

    Tab1PageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_5__["ComponentsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _tab1_routing_module__WEBPACK_IMPORTED_MODULE_6__["Tab1PageRoutingModule"]],
      declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_7__["Tab1Page"]]
    })], Tab1PageModule);
    /***/
  },

  /***/
  "./src/app/pages/tab1/tab1.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/pages/tab1/tab1.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesTab1Tab1PageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".dere {\n  position: relative;\n  left: 6%;\n}\n\n.mar {\n  position: relative;\n  left: 14%;\n}\n\nh3,\nh3,\nh6,\nh1 {\n  margin: 5px;\n}\n\n.fo {\n  font-size: 30px;\n}\n\nh5 {\n  margin-top: 6px;\n}\n\n.wei {\n  font-weight: 600;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdGFiMS9DOlxcVXNlcnNcXGlzYWNcXERlc2t0b3BcXGlvbmljXFxwYW50YVZlcnNpb25FZHUvc3JjXFxhcHBcXHBhZ2VzXFx0YWIxXFx0YWIxLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvdGFiMS90YWIxLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtBQ0NKOztBREVBO0VBQ0ksa0JBQUE7RUFDQSxTQUFBO0FDQ0o7O0FERUE7Ozs7RUFJSSxXQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0FDQ0o7O0FERUE7RUFDSSxnQkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvdGFiMS90YWIxLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5kZXJlIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGxlZnQ6IDYlO1xyXG59XHJcblxyXG4ubWFyIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGxlZnQ6IDE0JTtcclxufVxyXG5cclxuaDMsXHJcbmgzLFxyXG5oNixcclxuaDEge1xyXG4gICAgbWFyZ2luOiA1cHg7XHJcbn1cclxuXHJcbi5mbyB7XHJcbiAgICBmb250LXNpemU6IDMwcHg7XHJcbn1cclxuXHJcbmg1IHtcclxuICAgIG1hcmdpbi10b3A6IDZweDtcclxufVxyXG5cclxuLndlaSB7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG59IiwiLmRlcmUge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGxlZnQ6IDYlO1xufVxuXG4ubWFyIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBsZWZ0OiAxNCU7XG59XG5cbmgzLFxuaDMsXG5oNixcbmgxIHtcbiAgbWFyZ2luOiA1cHg7XG59XG5cbi5mbyB7XG4gIGZvbnQtc2l6ZTogMzBweDtcbn1cblxuaDUge1xuICBtYXJnaW4tdG9wOiA2cHg7XG59XG5cbi53ZWkge1xuICBmb250LXdlaWdodDogNjAwO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/tab1/tab1.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/pages/tab1/tab1.page.ts ***!
    \*****************************************/

  /*! exports provided: Tab1Page */

  /***/
  function srcAppPagesTab1Tab1PageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Tab1Page", function () {
      return Tab1Page;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/db.service */
    "./src/app/services/db.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/services/alertas.service */
    "./src/app/services/alertas.service.ts");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);

    var Tab1Page = /*#__PURE__*/function () {
      function Tab1Page(db, alertCtrl, alertSvc) {
        _classCallCheck(this, Tab1Page);

        this.db = db;
        this.alertCtrl = alertCtrl;
        this.alertSvc = alertSvc;
        this.myDate = new Date().toISOString();
        this.gasto = 0;
        this.totalgasto = 0;
        this.condecimales = 0;
        this.dataGasto = [];
        this.gastoactual = [];
        this.fechagasto = [];
        this.mes = '';
        this.fe = '';
        this.monthNames = moment__WEBPACK_IMPORTED_MODULE_5__["months"]();
        moment__WEBPACK_IMPORTED_MODULE_5__["locale"]('es');
        this.monthNames = moment__WEBPACK_IMPORTED_MODULE_5__["months"]();
      }

      _createClass(Tab1Page, [{
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.cargarGas(moment__WEBPACK_IMPORTED_MODULE_5__().format("MMMM-YYYY"));
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "borrar",
        value: function borrar(id) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.alertCtrl.create({
                      cssClass: 'alert-css',
                      header: '¿Quieres eliminar este gasto?',
                      backdropDismiss: false,
                      buttons: [{
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler(blah) {}
                      }, {
                        text: 'Eliminar Gasto',
                        handler: function handler(blah) {
                          _this.db.eliminarGasto(id);

                          _this.alertSvc.presentToast("Gasto eliminado con exito");
                        }
                      }]
                    });

                  case 2:
                    alert = _context.sent;
                    _context.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "cargarMes",
        value: function cargarMes(event) {
          var dia = moment__WEBPACK_IMPORTED_MODULE_5__(event.detail.value).format("MMMM-YYYY");
          this.cargarGas(dia);
        }
      }, {
        key: "cargarGas",
        value: function cargarGas(dia) {
          var _this2 = this;

          this.db.getDatabaseState().subscribe(function (boo) {
            if (boo) {
              _this2.db.getGasto().subscribe(function (data) {
                _this2.limpiarGastos();

                for (var i = 0; i < data.length; i++) {
                  var dataform = moment__WEBPACK_IMPORTED_MODULE_5__(data[i].fecha).format("MMMM-YYYY");

                  if (dataform === dia) {
                    _this2.dataGasto.push({
                      descripcion: data[i].descripcion,
                      id: data[i].id,
                      id_usuario: data[i].id_usuario,
                      fecha: data[i].fecha,
                      gasto: data[i].gasto,
                      icono: data[i].icono,
                      tipo_gasto: data[i].tipo_gasto
                    });

                    _this2.gasto = parseFloat(data[i].gasto);
                    _this2.totalgasto = _this2.gasto + _this2.totalgasto;
                    _this2.condecimales = parseFloat(_this2.totalgasto.toFixed(2));
                  }
                }
              });
            }
          });
        }
      }, {
        key: "limpiarGastos",
        value: function limpiarGastos() {
          this.gasto = 0;
          this.condecimales = 0;
          this.totalgasto = 0;
          this.dataGasto = [];
        }
      }]);

      return Tab1Page;
    }();

    Tab1Page.ctorParameters = function () {
      return [{
        type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }, {
        type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_4__["AlertasService"]
      }];
    };

    Tab1Page = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-tab1',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./tab1.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab1/tab1.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./tab1.page.scss */
      "./src/app/pages/tab1/tab1.page.scss"))["default"]]
    })], Tab1Page);
    /***/
  },

  /***/
  "./src/app/services/alertas.service.ts":
  /*!*********************************************!*\
    !*** ./src/app/services/alertas.service.ts ***!
    \*********************************************/

  /*! exports provided: AlertasService */

  /***/
  function srcAppServicesAlertasServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AlertasService", function () {
      return AlertasService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./db.service */
    "./src/app/services/db.service.ts");

    var AlertasService = /*#__PURE__*/function () {
      function AlertasService(alertCtrl, dataSvc, db, toastCtrl) {
        _classCallCheck(this, AlertasService);

        this.alertCtrl = alertCtrl;
        this.dataSvc = dataSvc;
        this.db = db;
        this.toastCtrl = toastCtrl;
      }

      _createClass(AlertasService, [{
        key: "presentToast",
        value: function presentToast(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var toast;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.toastCtrl.create({
                      cssClass: "alert",
                      message: message,
                      duration: 2000
                    });

                  case 2:
                    toast = _context2.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }]);

      return AlertasService;
    }();

    AlertasService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
      }, {
        type: _db_service__WEBPACK_IMPORTED_MODULE_4__["DatabaseService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    AlertasService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], AlertasService);
    /***/
  }
}]);
//# sourceMappingURL=tab1-tab1-module-es5.js.map