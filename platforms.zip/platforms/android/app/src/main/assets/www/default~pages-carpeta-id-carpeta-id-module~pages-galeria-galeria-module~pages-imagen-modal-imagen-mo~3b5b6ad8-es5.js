function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module~pages-imagen-modal-imagen-mo~3b5b6ad8"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/imagen-modal/imagen-modal.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/imagen-modal/imagen-modal.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesImagenModalImagenModalPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n\n</ion-header>\n\n<ion-content>\n\n<ion-slides \n  class=\"slides\"\n  scrollbar=\"true\"\n  [options]=\"slideOpts\"\n  (ionSlidesDidLoad)=\"cambio()\"\n  (ionSlideDidChange)=\"cambio()\"\n  #slider>\n\n    <ng-container *ngFor=\"let fotos of dataFotos; let i = index\" >\n\n      <ion-slide \n      (click)=\" verOpts(fotos.id, i)\" >\n        <ion-img [src]=\"imgUrl[i]\"></ion-img>\n      </ion-slide>\n    </ng-container>\n\n  </ion-slides>\n\n\n  <ion-item [hidden]=\"opts\"\n  class=\"opts2\"\n  slot=\"fixed\"\n  color=\"dark\">\n\n  <div slot=\"start\">\n\n    <ion-button (click)=\"salir()\"\n    fill=\"clear\"\n    shape=\"round\"\n    size=\"medium\"\n    color=\"light\">\n      <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n    </ion-button>\n  \n  </div>\n\n  <div slot=\"end\">\n    \n    <ion-button (click)=\"info()\" \n    fill=\"clear\"\n    shape=\"round\"\n    size=\"medium\"\n    color=\"light\">\n      <ion-icon slot=\"icon-only\" name=\"alert-circle-outline\"></ion-icon>\n    </ion-button>\n\n  </div>\n\n  </ion-item>\n\n  \n  <ion-item [hidden]=\"opts\"\n  class=\"opts\"\n  slot=\"fixed\"\n  color=\"dark\">\n\n  <div slot=\"start\">\n\n    <ion-button (click)=\"favorite()\"\n    fill=\"clear\"\n    shape=\"round\"\n    size=\"medium\"\n    color=\"light\">\n      <ion-icon *ngIf=\"isFavorite[indexSlider] == 0\" slot=\"icon-only\" name=\"heart-Outline\"></ion-icon>\n      <ion-icon color=\"danger\" \n      *ngIf=\"isFavorite[indexSlider] == 1\" slot=\"icon-only\" name=\"heart\"></ion-icon>\n    </ion-button>\n  \n  </div>\n\n  \n  <ion-button (click)=\"compartir()\" \n  class=\"center\"\n  fill=\"clear\"\n  shape=\"round\"\n  size=\"medium\"\n  color=\"light\">\n    <ion-icon slot=\"icon-only\" name=\"share-Outline\"></ion-icon>\n  </ion-button>\n\n  <div slot=\"end\">\n    \n    <ion-button (click)=\"eliminarFoto()\" \n    fill=\"clear\"\n    shape=\"round\"\n    size=\"medium\"\n    color=\"light\">\n      <ion-icon slot=\"icon-only\" name=\"trash-Outline\"></ion-icon>\n    </ion-button>\n\n  </div>\n\n  </ion-item>\n\n\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesInfoModalInfoModalPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"danger\">\n    \n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"salir()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title >Detalles</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-list *ngIf=\"tipo === 'imagenCarpeta'  && ver\"\n  class=\"ion-padding\">\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">Fecha</ion-label>\n      <ion-label>{{datosFotos[0].fecha | fecha}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Carpeta\n      </ion-label>\n      <ion-label>{{datosCarpeta[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\"> \n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Ruta\n      </ion-label>\n      <ion-label>Galeria/{{datosCarpeta[0].nombre}}/{{datosFotos[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\"\n      font-size=\"small\">Nombre\n      \n    </ion-label>\n      <ion-label>{{datosFotos[0].nombre}}</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list *ngIf=\"tipo === 'carpeta' && ver\">\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Nombre\n      </ion-label>\n      <ion-label>{{datosCarpeta[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Imagenes\n      </ion-label>\n      <ion-label>{{datosFotos.length}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Materia\n      </ion-label>\n      <ion-label *ngIf=\"datosCarpeta[0].id_materia > 0\">{{datosCarpeta[0].nombre}}</ion-label>\n      <ion-label *ngIf=\"datosCarpeta[0].id_materia == 0\">Carpeta independiente</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list *ngIf=\"tipo === 'materia' && ver\">\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Nombre\n      </ion-label>\n      <ion-label>{{datosMaterias[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item >\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Periodo academico\n      </ion-label>\n      <ion-label>{{datosPeriodo[0].nombre}}</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-title *ngIf=\"tipo === 'materia'\">Horario de clases</ion-title>\n\n  <ion-item *ngIf=\"datosEvento.length == 0 && tipo === 'materia'\">\n    <ion-label color=\"medium\"\n    position=\"fixed\">\n      Sin horario de clases\n    </ion-label>\n  </ion-item>\n\n  <ion-list *ngIf=\"tipo === 'materia' && ver && datosEvento.length > 0\">\n\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Dia\n      </ion-label>\n      <ion-label>{{datosEvento[0].dia | dia: datosEvento[0].dia}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Inicio\n      </ion-label>\n      <ion-label>{{datosEvento[0].inicio | hora}}</ion-label>\n    </ion-item>\n\n  <ion-item lines=\"none\">\n    <ion-label color=\"medium\"\n    position=\"fixed\">\n      Fin\n    </ion-label>\n    <ion-label>{{datosEvento[0].fin | hora}}</ion-label>\n  </ion-item>\n\n<ion-item >\n  <ion-label color=\"medium\"\n  position=\"fixed\">\n    Comentarios\n  </ion-label>\n  <ion-label>{{datosEvento[0].comentario || 'Sin comentarios'}}</ion-label>\n</ion-item>\n</ion-list>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/imagen-modal/imagen-modal.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/pages/imagen-modal/imagen-modal.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesImagenModalImagenModalPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".opts {\n  z-index: 1;\n  bottom: 0;\n  width: 100%;\n  opacity: 90%;\n}\n\n.opts2 {\n  z-index: 1;\n  top: 0;\n  width: 100%;\n  opacity: 90%;\n}\n\n.center {\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaW1hZ2VuLW1vZGFsL0M6XFxVc2Vyc1xcaXNhY1xcRGVza3RvcFxcaW9uaWNcXHBhbnRhVmVyc2lvbkVkdS9zcmNcXGFwcFxccGFnZXNcXGltYWdlbi1tb2RhbFxcaW1hZ2VuLW1vZGFsLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvaW1hZ2VuLW1vZGFsL2ltYWdlbi1tb2RhbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxVQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDQUo7O0FER0E7RUFDSSxVQUFBO0VBQ0EsTUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDQUo7O0FER0E7RUFFSSxZQUFBO0FDREoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9pbWFnZW4tbW9kYWwvaW1hZ2VuLW1vZGFsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4ub3B0c3tcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG9wYWNpdHk6IDkwJTtcclxufVxyXG5cclxuLm9wdHMye1xyXG4gICAgei1pbmRleDogMTtcclxuICAgIHRvcDogMDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgb3BhY2l0eTogOTAlO1xyXG59XHJcblxyXG4uY2VudGVye1xyXG5cclxuICAgIG1hcmdpbjogYXV0bztcclxufSIsIi5vcHRzIHtcbiAgei1pbmRleDogMTtcbiAgYm90dG9tOiAwO1xuICB3aWR0aDogMTAwJTtcbiAgb3BhY2l0eTogOTAlO1xufVxuXG4ub3B0czIge1xuICB6LWluZGV4OiAxO1xuICB0b3A6IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBvcGFjaXR5OiA5MCU7XG59XG5cbi5jZW50ZXIge1xuICBtYXJnaW46IGF1dG87XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pages/imagen-modal/imagen-modal.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/imagen-modal/imagen-modal.page.ts ***!
    \*********************************************************/

  /*! exports provided: ImagenModalPage */

  /***/
  function srcAppPagesImagenModalImagenModalPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ImagenModalPage", function () {
      return ImagenModalPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/db.service */
    "./src/app/services/db.service.ts");
    /* harmony import */


    var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/services/alertas.service */
    "./src/app/services/alertas.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic-native/social-sharing/ngx */
    "./node_modules/@ionic-native/social-sharing/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _info_modal_info_modal_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../info-modal/info-modal.page */
    "./src/app/pages/info-modal/info-modal.page.ts");
    /* harmony import */


    var src_app_services_galeria_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/services/galeria.service */
    "./src/app/services/galeria.service.ts");

    var ImagenModalPage = /*#__PURE__*/function () {
      function ImagenModalPage(db, alertSvc, alertCtrl, socialSharing, modalCtrl, galeriaSvc) {
        _classCallCheck(this, ImagenModalPage);

        this.db = db;
        this.alertSvc = alertSvc;
        this.alertCtrl = alertCtrl;
        this.socialSharing = socialSharing;
        this.modalCtrl = modalCtrl;
        this.galeriaSvc = galeriaSvc;
        this.isFavorite = [];
        this.opts = true;
        this.isAlbuma = true;
        this.ver = false;
        this.slideOpts = {
          initialSlide: 0,
          speed: 400
        };
      }

      _createClass(ImagenModalPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.slideOpts.initialSlide = this.index;
          this.indexO = this.index;
          this.fotoIdSelect = this.id;
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {}
      }, {
        key: "ionViewWillLeave",
        value: function ionViewWillLeave() {// for( let [i, idx] of this.isFavorite.entries() )
          // this.db.updateFotosFav(this.dataFotos[i].id, idx)
          // .then( _ =>{
          //   // this.clear();
          // })
        }
      }, {
        key: "verOpts",
        value: function verOpts(id, index) {
          var _this = this;

          this.fotoIdSelect = id;
          this.indexO = index;

          if (this.opts == false) {
            this.opts = false;
            setTimeout(function () {
              _this.opts = true;
            }, 4000);
          } else {
            this.opts = false;
            setTimeout(function () {
              _this.opts = true;
            }, 4000);
          }
        }
      }, {
        key: "eliminarFoto",
        value: function eliminarFoto() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this2 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.alertCtrl.create({
                      cssClass: 'alert-css',
                      header: '¿Quieres eliminar esta imagen?',
                      backdropDismiss: false,
                      buttons: [{
                        text: 'Cancelar',
                        role: 'cancel',
                        handler: function handler() {}
                      }, {
                        text: 'Eliminar',
                        role: 'ok',
                        handler: function handler() {
                          var _iterator = _createForOfIteratorHelper(_this2.dataFotos),
                              _step;

                          try {
                            for (_iterator.s(); !(_step = _iterator.n()).done;) {
                              var fotos = _step.value;

                              if (fotos.id == _this2.fotoIdSelect) {
                                _this2.galeriaSvc.deleteFileGaleria(fotos.nombre);

                                _this2.galeriaSvc.deleteFileRoot(fotos.url, fotos.nombre);
                              }
                            }
                          } catch (err) {
                            _iterator.e(err);
                          } finally {
                            _iterator.f();
                          }

                          _this2.db.eliminarFotos(_this2.fotoIdSelect).then(function (_) {
                            _this2.ver = !_this2.ver;

                            _this2.modalCtrl.dismiss();

                            _this2.isAlbuma = !_this2.isAlbuma;

                            _this2.alertSvc.presentToast("Imagen eliminada con exito");

                            _this2.opts = true;
                          });
                        }
                      }]
                    });

                  case 2:
                    alert = _context.sent;
                    _context.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "favorite",
        value: function favorite() {
          if (this.isFavorite[this.indexSlider] == 0) {
            this.isFavorite[this.indexSlider] = 1;
          } else this.isFavorite[this.indexSlider] = 0;

          this.dataFotos[this.indexSlider].favorito = this.isFavorite[this.indexSlider];

          var _iterator2 = _createForOfIteratorHelper(this.isFavorite.entries()),
              _step2;

          try {
            for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
              var _step2$value = _slicedToArray(_step2.value, 2),
                  i = _step2$value[0],
                  idx = _step2$value[1];

              this.db.updateFotosFav(this.dataFotos[i].id, idx).then(function (_) {// this.clear();
              });
            }
          } catch (err) {
            _iterator2.e(err);
          } finally {
            _iterator2.f();
          }
        }
      }, {
        key: "cambio",
        value: function cambio() {
          var _this3 = this;

          this.slider.getActiveIndex().then(function (data) {
            _this3.indexSlider = data;
            _this3.fotoIdSelect = _this3.dataFotos[_this3.indexSlider].id;
          });
        }
      }, {
        key: "compartir",
        value: function compartir() {
          this.socialSharing.share('hola', 'como estas', this.dataFotos[this.indexO].url)["catch"](function (err) {
            return console.log(err);
          });
        }
      }, {
        key: "info",
        value: function info() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var modal;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.modalCtrl.create({
                      component: _info_modal_info_modal_page__WEBPACK_IMPORTED_MODULE_6__["InfoModalPage"],
                      componentProps: {
                        tipo: 'imagenCarpeta',
                        id: this.fotoIdSelect,
                        editarMateria: false
                      }
                    });

                  case 2:
                    modal = _context2.sent;
                    _context2.next = 5;
                    return modal.present();

                  case 5:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "clear",
        value: function clear() {
          this.id = '';
          this.index = '';
          this.imgUrl = '';
          this.dataFotos = [];
          this.isFavorite = [];
          this.opts = true;
          this.isAlbuma = true;
          this.ver = false;
          this.fotoIdSelect = 0;
          this.indexO = 0;
          this.indexSlider = 0;
          this.slideOpts = {
            initialSlide: 0,
            speed: 400
          };
        }
      }, {
        key: "salir",
        value: function salir() {
          this.modalCtrl.dismiss();
        }
      }]);

      return ImagenModalPage;
    }();

    ImagenModalPage.ctorParameters = function () {
      return [{
        type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"]
      }, {
        type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__["AlertasService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
      }, {
        type: _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_5__["SocialSharing"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
      }, {
        type: src_app_services_galeria_service__WEBPACK_IMPORTED_MODULE_7__["GaleriaService"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], ImagenModalPage.prototype, "id", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], ImagenModalPage.prototype, "index", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], ImagenModalPage.prototype, "imgUrl", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], ImagenModalPage.prototype, "dataFotos", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], ImagenModalPage.prototype, "isFavorite", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('slider')], ImagenModalPage.prototype, "slider", void 0);
    ImagenModalPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-imagen-modal',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./imagen-modal.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/imagen-modal/imagen-modal.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./imagen-modal.page.scss */
      "./src/app/pages/imagen-modal/imagen-modal.page.scss"))["default"]]
    })], ImagenModalPage);
    /***/
  },

  /***/
  "./src/app/pages/info-modal/info-modal.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/pages/info-modal/info-modal.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesInfoModalInfoModalPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luZm8tbW9kYWwvaW5mby1tb2RhbC5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/pages/info-modal/info-modal.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/info-modal/info-modal.page.ts ***!
    \*****************************************************/

  /*! exports provided: InfoModalPage */

  /***/
  function srcAppPagesInfoModalInfoModalPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "InfoModalPage", function () {
      return InfoModalPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/db.service */
    "./src/app/services/db.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var InfoModalPage = /*#__PURE__*/function () {
      function InfoModalPage(db, modalCtrl) {
        _classCallCheck(this, InfoModalPage);

        this.db = db;
        this.modalCtrl = modalCtrl;
        this.ver = false;
        this.datosFotos = [];
        this.datosCarpeta = [];
        this.datosMaterias = [];
        this.datosEvento = [];
        this.datosPeriodo = [];
      }

      _createClass(InfoModalPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          console.log(this.id);
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          var _this4 = this;

          this.db.getDatabaseState().subscribe(function (boo) {
            if (boo) {
              if (_this4.tipo === 'imagenCarpeta') {
                _this4.cargarFotos();

                _this4.cargarCarpeta();
              }

              if (_this4.tipo === 'carpeta') {
                _this4.cargarCarpetaId();

                _this4.cargarFotos();
              }

              if (_this4.tipo === 'materia') {
                _this4.cargarMateriasId();
              }
            }
          });
        }
      }, {
        key: "salir",
        value: function salir() {
          this.modalCtrl.dismiss();
        }
      }, {
        key: "cargarFotos",
        value: function cargarFotos() {
          var _this5 = this;

          this.db.getFotos().subscribe(function (data) {
            var _iterator3 = _createForOfIteratorHelper(data),
                _step3;

            try {
              for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                var datos = _step3.value;

                if (datos.id == _this5.id && _this5.tipo === 'imagenCarpeta') {
                  _this5.datosFotos.push(datos);

                  _this5.ver = true;
                } else if (datos.id_carpeta == _this5.id && _this5.tipo === 'carpeta') {
                  _this5.datosFotos.push(datos);
                }
              }
            } catch (err) {
              _iterator3.e(err);
            } finally {
              _iterator3.f();
            }
          });
        }
      }, {
        key: "cargarCarpeta",
        value: function cargarCarpeta() {
          var _this6 = this;

          this.db.getCarpeta().subscribe(function (data) {
            var _iterator4 = _createForOfIteratorHelper(data),
                _step4;

            try {
              for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
                var datos = _step4.value;

                if (datos.id == _this6.datosFotos[0].id_carpeta) {
                  _this6.datosCarpeta.push(datos);
                }
              }
            } catch (err) {
              _iterator4.e(err);
            } finally {
              _iterator4.f();
            }

            _this6.ver = true;
          });
        }
      }, {
        key: "cargarCarpetaId",
        value: function cargarCarpetaId() {
          var _this7 = this;

          this.db.cargarCarpetaId(this.id).then(function (data) {
            _this7.datosCarpeta.push(data);

            console.log(data);
            _this7.ver = true;
          });
        }
      }, {
        key: "cargarMateriasId",
        value: function cargarMateriasId() {
          var _this8 = this;

          this.db.cargarMateriaId(this.id).then(function (data) {
            _this8.datosMaterias.push(data);

            _this8.ver = true;

            _this8.cargarEvento();

            _this8.cargarPeriodo();
          });
        }
      }, {
        key: "cargarEvento",
        value: function cargarEvento() {
          var _this9 = this;

          if (this.datosMaterias[0].id_evento > 0) {
            this.db.cargarEventoId(this.datosMaterias[0].id_evento).then(function (data) {
              if (data) {
                _this9.datosEvento.push(data);
              }
            });
          }
        }
      }, {
        key: "cargarPeriodo",
        value: function cargarPeriodo() {
          var _this10 = this;

          this.db.cargarPeriodoId(this.datosMaterias[0].id_periodo).then(function (data) {
            _this10.datosPeriodo.push(data);
          });
        }
      }]);

      return InfoModalPage;
    }();

    InfoModalPage.ctorParameters = function () {
      return [{
        type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], InfoModalPage.prototype, "tipo", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], InfoModalPage.prototype, "id", void 0);
    InfoModalPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-info-modal',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./info-modal.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./info-modal.page.scss */
      "./src/app/pages/info-modal/info-modal.page.scss"))["default"]]
    })], InfoModalPage);
    /***/
  },

  /***/
  "./src/app/services/alertas.service.ts":
  /*!*********************************************!*\
    !*** ./src/app/services/alertas.service.ts ***!
    \*********************************************/

  /*! exports provided: AlertasService */

  /***/
  function srcAppServicesAlertasServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AlertasService", function () {
      return AlertasService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./db.service */
    "./src/app/services/db.service.ts");

    var AlertasService = /*#__PURE__*/function () {
      function AlertasService(alertCtrl, dataSvc, db, toastCtrl) {
        _classCallCheck(this, AlertasService);

        this.alertCtrl = alertCtrl;
        this.dataSvc = dataSvc;
        this.db = db;
        this.toastCtrl = toastCtrl;
      }

      _createClass(AlertasService, [{
        key: "presentToast",
        value: function presentToast(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var toast;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.toastCtrl.create({
                      cssClass: "alert",
                      message: message,
                      duration: 2000
                    });

                  case 2:
                    toast = _context3.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }]);

      return AlertasService;
    }();

    AlertasService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
      }, {
        type: _db_service__WEBPACK_IMPORTED_MODULE_4__["DatabaseService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    AlertasService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], AlertasService);
    /***/
  }
}]);
//# sourceMappingURL=default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module~pages-imagen-modal-imagen-mo~3b5b6ad8-es5.js.map