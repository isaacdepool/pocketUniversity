(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/carpeta-id/carpeta-id.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/carpeta-id/carpeta-id.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n\n  <ion-toolbar color=\"danger\">\n    \n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"salir()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-buttons slot=\"end\">\n\n      <ion-button *ngIf=\"!fav\" (click)=\"opts( $event )\">\n        <ion-icon slot=\"icon-only\" name=\"ellipsis-vertical-outline\"></ion-icon>\n      </ion-button>\n\n    </ion-buttons>\n\n    <ion-title *ngIf=\"!ver\"></ion-title>\n\n    <div *ngIf=\"!fav && ver && dataFotos.length > 1\" >\n\n      <ion-title class=\"ion-text-capitalize\">{{dataCarpeta.nombre}}</ion-title>\n      <ion-title size=\"small\"\n      color=\"dark\">{{dataFotos.length}} Imagenes</ion-title>\n      \n    </div>\n\n    <div *ngIf=\"!fav && ver && dataFotos.length == 0\" >\n\n      <ion-title >{{dataCarpeta.nombre}}</ion-title>\n      <ion-title size=\"small\"\n      color=\"dark\">Sin Imagenes</ion-title>\n      \n    </div>\n\n    <div *ngIf=\"!fav && ver && dataFotos.length == 1\" >\n\n      <ion-title >{{dataCarpeta.nombre}}</ion-title>\n      <ion-title size=\"small\"\n      color=\"dark\">{{dataFotos.length}} Imagen</ion-title>\n      \n    </div>\n    \n    <ion-title *ngIf=\"fav\" class=\"ion-text-capitalize\">Favoritos</ion-title>\n    <div *ngIf=\"fav && ver && dataFotos.length > 1\" >\n\n      <ion-title size=\"small\"\n      color=\"dark\">{{dataFotos.length}} Imagenes</ion-title>\n      \n    </div>\n\n    <div *ngIf=\"fav && ver && dataFotos.length == 0\" >\n\n      <ion-title size=\"small\"\n      color=\"dark\">Sin Imagenes</ion-title>\n      \n    </div>\n\n    <div *ngIf=\"fav && ver && dataFotos.length == 1\" >\n      \n      <ion-title size=\"small\"\n      color=\"dark\">{{dataFotos.length}} Imagen</ion-title>\n      \n    </div>\n\n    \n\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n\n<ng-container>\n \n    <ion-row >\n\n      <ng-container *ngFor=\"let fotos of dataFotos; let i = index\">\n        \n        <ion-col size=\"6\" class=\"padding\" >\n            \n            <ion-card *ngIf=\"ver\"\n            class=\"card-size\" >\n              <ion-img class=\"img-size\" (click)=\"img($event, fotos.id, i)\" [src]=\"imgUrl[i]\"></ion-img>\n            </ion-card>\n            \n            <ion-skeleton-text *ngIf=\"!ver\"\n            color=\"medium\"\n            class=\"card-size\"\n            animated \n            style=\"width: 100%\"></ion-skeleton-text>\n  \n        </ion-col>\n\n      </ng-container>\n        </ion-row>\n\n</ng-container>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/carpeta-id/carpeta-id.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/pages/carpeta-id/carpeta-id.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".card-size {\n  height: 95%;\n  width: 95%;\n}\n\n.padding {\n  height: 200px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY2FycGV0YS1pZC9DOlxcVXNlcnNcXGlzYWNcXERlc2t0b3BcXGlvbmljXFxwYW50YVZlcnNpb25FZHUvc3JjXFxhcHBcXHBhZ2VzXFxjYXJwZXRhLWlkXFxjYXJwZXRhLWlkLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvY2FycGV0YS1pZC9jYXJwZXRhLWlkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxVQUFBO0FDQ0o7O0FERUE7RUFDSSxhQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9jYXJwZXRhLWlkL2NhcnBldGEtaWQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNhcmQtc2l6ZXtcclxuICAgIGhlaWdodDogOTUlO1xyXG4gICAgd2lkdGg6IDk1JTtcclxufVxyXG5cclxuLnBhZGRpbmd7XHJcbiAgICBoZWlnaHQ6IDIwMHB4O1xyXG59XHJcbiIsIi5jYXJkLXNpemUge1xuICBoZWlnaHQ6IDk1JTtcbiAgd2lkdGg6IDk1JTtcbn1cblxuLnBhZGRpbmcge1xuICBoZWlnaHQ6IDIwMHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/carpeta-id/carpeta-id.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/carpeta-id/carpeta-id.page.ts ***!
  \*****************************************************/
/*! exports provided: CarpetaIdPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CarpetaIdPage", function() { return CarpetaIdPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/db.service */ "./src/app/services/db.service.ts");
/* harmony import */ var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/ionic-webview/ngx */ "./node_modules/@ionic-native/ionic-webview/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _imagen_modal_imagen_modal_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../imagen-modal/imagen-modal.page */ "./src/app/pages/imagen-modal/imagen-modal.page.ts");
/* harmony import */ var src_app_components_popover_popover_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/popover/popover.component */ "./src/app/components/popover/popover.component.ts");
/* harmony import */ var _info_modal_info_modal_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../info-modal/info-modal.page */ "./src/app/pages/info-modal/info-modal.page.ts");
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/alertas.service */ "./src/app/services/alertas.service.ts");
/* harmony import */ var src_app_services_galeria_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/galeria.service */ "./src/app/services/galeria.service.ts");










let CarpetaIdPage = class CarpetaIdPage {
    constructor(modalCtrl, db, webView, popoverCtrl, alertCtrl, alertSvc, galeriaSvc, navCtrl) {
        this.modalCtrl = modalCtrl;
        this.db = db;
        this.webView = webView;
        this.popoverCtrl = popoverCtrl;
        this.alertCtrl = alertCtrl;
        this.alertSvc = alertSvc;
        this.galeriaSvc = galeriaSvc;
        this.navCtrl = navCtrl;
        this.fav = false;
        this.dataFotos = [];
        this.imgUrl = [];
        this.isFavorite = [];
        this.ver = false;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        if (this.fav) {
            this.cargarFavoritos();
        }
        else
            this.cargar();
    }
    cargar() {
        this.db.getDatabaseState().subscribe(boo => {
            if (boo) {
                this.db.cargarCarpetaId(this.carpetaId).then(data => {
                    this.dataCarpeta = data;
                    if (data.id_materia > 0) {
                        this.db.cargarMateriaId(data.id_materia).then(data => {
                            this.dataMateria = data;
                        });
                    }
                });
                this.db.getFotos().subscribe(data => {
                    let i = 0;
                    this.dataFotos = [];
                    this.imgUrl = [];
                    for (let fotos of data) {
                        if (fotos.id_carpeta == this.carpetaId) {
                            this.dataFotos.push(fotos);
                            this.isFavorite[i] = fotos.favorito;
                            this.imgUrl[i] = this.webView.convertFileSrc(fotos.url);
                            i++;
                        }
                    }
                });
            }
            return setTimeout(() => {
                this.ver = true;
            }, 200);
        });
    }
    cargarFavoritos() {
        this.db.getFotos().subscribe(data => {
            let i = 0;
            this.dataFotos = [];
            this.imgUrl = [];
            for (let fotos of data) {
                if (fotos.favorito == 1) {
                    console.log(data);
                    this.dataFotos.push(fotos);
                    this.isFavorite[i] = fotos.favorito;
                    this.imgUrl[i] = this.webView.convertFileSrc(fotos.url);
                    i++;
                }
            }
            return setTimeout(() => {
                this.ver = true;
            }, 200);
        });
    }
    img(event, id, index) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _imagen_modal_imagen_modal_page__WEBPACK_IMPORTED_MODULE_5__["ImagenModalPage"],
                componentProps: {
                    id: id,
                    index: index,
                    dataFotos: this.dataFotos,
                    imgUrl: this.imgUrl,
                    isFavorite: this.isFavorite
                }
            });
            yield modal.present();
        });
    }
    opts() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let itemsC = {
                nombre: 'info',
                icon: 'alert-circle'
            };
            let boo = true;
            const popover = yield this.popoverCtrl.create({
                component: src_app_components_popover_popover_component__WEBPACK_IMPORTED_MODULE_6__["PopoverComponent"],
                cssClass: 'css_popover',
                event: event,
                mode: 'ios',
                componentProps: {
                    itemsC: itemsC,
                    boo: boo,
                }
            });
            yield popover.present();
            const { data } = yield popover.onDidDismiss();
            if (data) {
                if (data.item === 'info') {
                    this.info();
                }
                if (data.item === 'editar') {
                    this.editar();
                }
                if (data.item === 'eliminar') {
                    this.eliminar();
                }
            }
        });
    }
    info() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _info_modal_info_modal_page__WEBPACK_IMPORTED_MODULE_7__["InfoModalPage"],
                componentProps: {
                    tipo: 'carpeta',
                    id: this.carpetaId
                }
            });
            yield modal.present();
        });
    }
    salir() {
        this.modalCtrl.dismiss();
    }
    editar() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.dataCarpeta.id_materia != 0) {
                this.restringido();
            }
            else {
                const alert = yield this.alertCtrl.create({
                    header: 'Editar carpeta',
                    backdropDismiss: false,
                    cssClass: 'alert-css',
                    inputs: [
                        {
                            name: 'nombre',
                            type: 'text',
                            value: this.dataCarpeta.nombre
                        },
                    ],
                    buttons: [
                        {
                            text: 'Cancelar',
                            role: 'cancel',
                            handler: (blah) => {
                            }
                        },
                        {
                            text: 'Guardar',
                            handler: (data) => {
                                data.nombre = data.nombre.trim();
                                if (data.nombre.length > 0) {
                                    this.db.updateCarpetaLibre(this.carpetaId, data.nombre)
                                        .then(_ => {
                                        this.ionViewWillEnter();
                                        this.alertSvc.presentToast("Datos actualizados correctamente");
                                    });
                                }
                                else
                                    this.alertSvc.presentToast("Debes ingresar un titulo");
                            }
                        }
                    ]
                });
                yield alert.present();
            }
        });
    }
    restringido() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'Editar carpeta',
                message: 'Esta caperta pertece a una materia, si quieres editarla tienes que hacerlo desde \'Editar materia\'',
                backdropDismiss: false,
                cssClass: 'alert-css',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel'
                    },
                    {
                        text: 'Editar materia',
                        handler: () => {
                            this.modalCtrl.dismiss({
                                idMateria: this.dataMateria.id,
                                editarMateria: true
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    eliminar() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: '¿Quieres eliminar esta carpeta?',
                message: 'Se eliminaran todas las imagenes',
                backdropDismiss: false,
                cssClass: 'alert-css',
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel'
                    },
                    {
                        text: 'Eliminar',
                        handler: () => {
                            this.db.eliminarCarpeta(this.carpetaId);
                            this.db.getFotos().subscribe(data => {
                                for (let dat of data) {
                                    if (dat.id_carpeta == this.carpetaId) {
                                        this.galeriaSvc.deleteFileRoot(dat.url, dat.nombre);
                                        this.galeriaSvc.deleteFileGaleria(dat.nombre);
                                    }
                                }
                            });
                            this.db.eliminarFotosCarpeta(this.carpetaId);
                            this.alertSvc.presentToast('Carpeta eliminada con exito');
                            this.modalCtrl.dismiss();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
CarpetaIdPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_3__["DatabaseService"] },
    { type: _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_4__["WebView"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_8__["AlertasService"] },
    { type: src_app_services_galeria_service__WEBPACK_IMPORTED_MODULE_9__["GaleriaService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], CarpetaIdPage.prototype, "carpetaId", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], CarpetaIdPage.prototype, "fotoId", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], CarpetaIdPage.prototype, "fav", void 0);
CarpetaIdPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-carpeta-id',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./carpeta-id.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/carpeta-id/carpeta-id.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./carpeta-id.page.scss */ "./src/app/pages/carpeta-id/carpeta-id.page.scss")).default]
    })
], CarpetaIdPage);



/***/ })

}]);
//# sourceMappingURL=default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module-es2015.js.map