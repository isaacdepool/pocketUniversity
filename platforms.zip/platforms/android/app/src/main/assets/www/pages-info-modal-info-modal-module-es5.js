function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-info-modal-info-modal-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesInfoModalInfoModalPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"danger\">\n    \n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"salir()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title >Detalles</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-list *ngIf=\"tipo === 'imagenCarpeta'  && ver\"\n  class=\"ion-padding\">\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">Fecha</ion-label>\n      <ion-label>{{datosFotos[0].fecha | fecha}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Carpeta\n      </ion-label>\n      <ion-label>{{datosCarpeta[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\"> \n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Ruta\n      </ion-label>\n      <ion-label>Galeria/{{datosCarpeta[0].nombre}}/{{datosFotos[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\"\n      font-size=\"small\">Nombre\n      \n    </ion-label>\n      <ion-label>{{datosFotos[0].nombre}}</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list *ngIf=\"tipo === 'carpeta' && ver\">\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Nombre\n      </ion-label>\n      <ion-label>{{datosCarpeta[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Imagenes\n      </ion-label>\n      <ion-label>{{datosFotos.length}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Materia\n      </ion-label>\n      <ion-label *ngIf=\"datosCarpeta[0].id_materia > 0\">{{datosCarpeta[0].nombre}}</ion-label>\n      <ion-label *ngIf=\"datosCarpeta[0].id_materia == 0\">Carpeta independiente</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list *ngIf=\"tipo === 'materia' && ver\">\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Nombre\n      </ion-label>\n      <ion-label>{{datosMaterias[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item >\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Periodo academico\n      </ion-label>\n      <ion-label>{{datosPeriodo[0].nombre}}</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-title *ngIf=\"tipo === 'materia'\">Horario de clases</ion-title>\n\n  <ion-item *ngIf=\"datosEvento.length == 0 && tipo === 'materia'\">\n    <ion-label color=\"medium\"\n    position=\"fixed\">\n      Sin horario de clases\n    </ion-label>\n  </ion-item>\n\n  <ion-list *ngIf=\"tipo === 'materia' && ver && datosEvento.length > 0\">\n\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Dia\n      </ion-label>\n      <ion-label>{{datosEvento[0].dia | dia: datosEvento[0].dia}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Inicio\n      </ion-label>\n      <ion-label>{{datosEvento[0].inicio | hora}}</ion-label>\n    </ion-item>\n\n  <ion-item lines=\"none\">\n    <ion-label color=\"medium\"\n    position=\"fixed\">\n      Fin\n    </ion-label>\n    <ion-label>{{datosEvento[0].fin | hora}}</ion-label>\n  </ion-item>\n\n<ion-item >\n  <ion-label color=\"medium\"\n  position=\"fixed\">\n    Comentarios\n  </ion-label>\n  <ion-label>{{datosEvento[0].comentario || 'Sin comentarios'}}</ion-label>\n</ion-item>\n</ion-list>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/info-modal/info-modal-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/info-modal/info-modal-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: InfoModalPageRoutingModule */

  /***/
  function srcAppPagesInfoModalInfoModalRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "InfoModalPageRoutingModule", function () {
      return InfoModalPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _info_modal_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./info-modal.page */
    "./src/app/pages/info-modal/info-modal.page.ts");

    var routes = [{
      path: '',
      component: _info_modal_page__WEBPACK_IMPORTED_MODULE_3__["InfoModalPage"]
    }];

    var InfoModalPageRoutingModule = function InfoModalPageRoutingModule() {
      _classCallCheck(this, InfoModalPageRoutingModule);
    };

    InfoModalPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], InfoModalPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/info-modal/info-modal.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/info-modal/info-modal.module.ts ***!
    \*******************************************************/

  /*! exports provided: InfoModalPageModule */

  /***/
  function srcAppPagesInfoModalInfoModalModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "InfoModalPageModule", function () {
      return InfoModalPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _info_modal_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./info-modal-routing.module */
    "./src/app/pages/info-modal/info-modal-routing.module.ts");
    /* harmony import */


    var _info_modal_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./info-modal.page */
    "./src/app/pages/info-modal/info-modal.page.ts");
    /* harmony import */


    var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/components/components.module */
    "./src/app/components/components.module.ts");

    var InfoModalPageModule = function InfoModalPageModule() {
      _classCallCheck(this, InfoModalPageModule);
    };

    InfoModalPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _info_modal_routing_module__WEBPACK_IMPORTED_MODULE_5__["InfoModalPageRoutingModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]],
      declarations: [_info_modal_page__WEBPACK_IMPORTED_MODULE_6__["InfoModalPage"]]
    })], InfoModalPageModule);
    /***/
  },

  /***/
  "./src/app/pages/info-modal/info-modal.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/pages/info-modal/info-modal.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesInfoModalInfoModalPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luZm8tbW9kYWwvaW5mby1tb2RhbC5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/pages/info-modal/info-modal.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/info-modal/info-modal.page.ts ***!
    \*****************************************************/

  /*! exports provided: InfoModalPage */

  /***/
  function srcAppPagesInfoModalInfoModalPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "InfoModalPage", function () {
      return InfoModalPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/db.service */
    "./src/app/services/db.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var InfoModalPage = /*#__PURE__*/function () {
      function InfoModalPage(db, modalCtrl) {
        _classCallCheck(this, InfoModalPage);

        this.db = db;
        this.modalCtrl = modalCtrl;
        this.ver = false;
        this.datosFotos = [];
        this.datosCarpeta = [];
        this.datosMaterias = [];
        this.datosEvento = [];
        this.datosPeriodo = [];
      }

      _createClass(InfoModalPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          console.log(this.id);
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          var _this = this;

          this.db.getDatabaseState().subscribe(function (boo) {
            if (boo) {
              if (_this.tipo === 'imagenCarpeta') {
                _this.cargarFotos();

                _this.cargarCarpeta();
              }

              if (_this.tipo === 'carpeta') {
                _this.cargarCarpetaId();

                _this.cargarFotos();
              }

              if (_this.tipo === 'materia') {
                _this.cargarMateriasId();
              }
            }
          });
        }
      }, {
        key: "salir",
        value: function salir() {
          this.modalCtrl.dismiss();
        }
      }, {
        key: "cargarFotos",
        value: function cargarFotos() {
          var _this2 = this;

          this.db.getFotos().subscribe(function (data) {
            var _iterator = _createForOfIteratorHelper(data),
                _step;

            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                var datos = _step.value;

                if (datos.id == _this2.id && _this2.tipo === 'imagenCarpeta') {
                  _this2.datosFotos.push(datos);

                  _this2.ver = true;
                } else if (datos.id_carpeta == _this2.id && _this2.tipo === 'carpeta') {
                  _this2.datosFotos.push(datos);
                }
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }
          });
        }
      }, {
        key: "cargarCarpeta",
        value: function cargarCarpeta() {
          var _this3 = this;

          this.db.getCarpeta().subscribe(function (data) {
            var _iterator2 = _createForOfIteratorHelper(data),
                _step2;

            try {
              for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                var datos = _step2.value;

                if (datos.id == _this3.datosFotos[0].id_carpeta) {
                  _this3.datosCarpeta.push(datos);
                }
              }
            } catch (err) {
              _iterator2.e(err);
            } finally {
              _iterator2.f();
            }

            _this3.ver = true;
          });
        }
      }, {
        key: "cargarCarpetaId",
        value: function cargarCarpetaId() {
          var _this4 = this;

          this.db.cargarCarpetaId(this.id).then(function (data) {
            _this4.datosCarpeta.push(data);

            console.log(data);
            _this4.ver = true;
          });
        }
      }, {
        key: "cargarMateriasId",
        value: function cargarMateriasId() {
          var _this5 = this;

          this.db.cargarMateriaId(this.id).then(function (data) {
            _this5.datosMaterias.push(data);

            _this5.ver = true;

            _this5.cargarEvento();

            _this5.cargarPeriodo();
          });
        }
      }, {
        key: "cargarEvento",
        value: function cargarEvento() {
          var _this6 = this;

          if (this.datosMaterias[0].id_evento > 0) {
            this.db.cargarEventoId(this.datosMaterias[0].id_evento).then(function (data) {
              if (data) {
                _this6.datosEvento.push(data);
              }
            });
          }
        }
      }, {
        key: "cargarPeriodo",
        value: function cargarPeriodo() {
          var _this7 = this;

          this.db.cargarPeriodoId(this.datosMaterias[0].id_periodo).then(function (data) {
            _this7.datosPeriodo.push(data);
          });
        }
      }]);

      return InfoModalPage;
    }();

    InfoModalPage.ctorParameters = function () {
      return [{
        type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], InfoModalPage.prototype, "tipo", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], InfoModalPage.prototype, "id", void 0);
    InfoModalPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-info-modal',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./info-modal.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./info-modal.page.scss */
      "./src/app/pages/info-modal/info-modal.page.scss"))["default"]]
    })], InfoModalPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-info-modal-info-modal-module-es5.js.map