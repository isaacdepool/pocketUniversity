function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _iterableToArrayLimit(arr, i) { if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return; var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e2) { throw _e2; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e3) { didErr = true; err = _e3; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-agg-materia-agg-materia-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/agg-materia/agg-materia.page.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/agg-materia/agg-materia.page.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesAggMateriaAggMateriaPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"danger\">\n\n    <ion-buttons slot=\"start\">\n\n     <ion-buttons slot=\"start\">\n       <ion-back-button defaultHref=\"/\"></ion-back-button>\n     </ion-buttons>\n\n    </ion-buttons>\n\n    <ion-title> {{titulo}} </ion-title>\n    \n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  \n  <form #form=\"ngForm\" (ngSubmit)=\"guardarDatos()\">\n    \n    <ion-list>\n  \n      <ion-item>\n        <ion-icon slot=\"start\" name=\"reader\"></ion-icon>\n        <ion-label position=\"floating\">Nombre de la materia</ion-label>\n  \n        <ion-input type=\"text\"\n        minlength=\"1\"\n        maxlegth=\"10\"\n        name=\"nombre\"\n        [(ngModel)]=\"modalMaterias.nombre\"\n        required></ion-input>\n  \n      </ion-item>\n      \n    </ion-list>\n  \n    <ion-list>\n  \n      <ion-item>\n        <ion-icon slot=\"start\" name=\"library\"></ion-icon>\n        <ion-label>Periodo academico</ion-label>\n  \n        <ion-select\n        cancelText = \"Cancelar\"\n        name=\"id_periodo\"\n        [(ngModel)]=\"modalMaterias.id_periodo\"\n        okText = \"Aceptar\"\n        placeholder=\"Periodo\"\n        required>\n  \n          <ion-select-option *ngFor=\"let per of dbPeriodo\"\n          [value]=\"per.id\">{{ per.nombre }}</ion-select-option>\n          \n        </ion-select>\n      </ion-item>\n      \n    </ion-list>\n  \n      <ion-list>\n  \n        <ion-item>\n  \n          <ion-icon slot=\"start\" name=\"calendar\"></ion-icon>\n          <ion-label>Agregar Horario de clases</ion-label>\n  \n          <ion-button fill=\"clear\"\n          (click)=\"ver()\">\n              <ion-icon color=\"dark\"\n              slot=\"icon-only\"\n              [name]=\"verEven? 'caret-forward' : 'caret-down'\"></ion-icon>\n            </ion-button>\n  \n        </ion-item>\n  \n      </ion-list>\n  \n        <ion-list [hidden]=\"!verEven\">\n          \n          <ion-item lines=\"none\">\n           <ion-icon slot=\"start\" name=\"time\"></ion-icon>\n       \n           <ion-input type=\"text\"\n           disabled \n           >Dia</ion-input>\n       \n           <ion-input \n           class=\"ion-text-capitalize\"\n           disabled\n           [required]=\"verEven\"\n           type=\"text\"\n           class=\"pick\"\n           placeholder=\"Dia\"\n           (click)=\"pick()\"\n           name=\"dia\"\n           [(ngModel)]=\"modalMaterias.dia\"> {{modalMaterias.dia}}</ion-input> \n           \n           </ion-item>\n     \n             <ion-item lines=\"none\">\n               <ion-icon slot=\"start\"></ion-icon>\n           \n               <ion-input type=\"text\"\n               disabled \n               >Inicio</ion-input>\n           \n               <ion-datetime\n               [required]=\"verEven\"\n               displayFormat=\"hh:mm a\"   \n               placeholder=\"00:00\"\n               cancelText = \"Cancelar\"\n               doneText= \"Aceptar\"\n               name=\"inicion\"\n               [min]=\"horaLocal\"\n               [(ngModel)]=\"modalMaterias.inicio\"\n               [value]=\"modalMaterias.inicio\"\n               ></ion-datetime> \n               \n           \n               </ion-item>\n             \n             <ion-item>\n         \n               <ion-icon slot=\"start\"></ion-icon>\n         \n             <ion-input type=\"text\"\n             disabled \n             >Fin</ion-input> \n         \n             <ion-datetime cssClass=\"datetime\"\n             [required]=\"verEven\"\n             [min]=\"modalMaterias.inicio.toISOString\"\n             displayFormat=\"hh:mm a\"  \n             placeholder=\"00:00\"\n             cancelText = \"Cancelar\"\n             doneText= \"Aceptar\"\n             name=\"fin\"\n             [(ngModel)]=\"modalMaterias.fin\"\n             ></ion-datetime> \n    \n         </ion-item>\n\n         <ion-item>\n          <ion-icon slot=\"start\" name=\"pencil\"></ion-icon>\n    \n          <ion-label position=\"floating\">\n          Comentario</ion-label>\n          \n          <ion-input\n          type=\"text\"\n          name=\"comentario\"\n          [(ngModel)]=\"modalMaterias.comentario\"\n          maxlegth=\"100\">\n          \n        </ion-input>\n        </ion-item>\n\n        </ion-list>\n  \n        <ion-button\n        class=\"ion-padding\"\n        type=\"submit\" \n        expand=\"block\"\n        [disabled]=\"form.invalid\">\n          Guardar\n        </ion-button>\n\n  </form>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/agg-materia/agg-materia-routing.module.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/pages/agg-materia/agg-materia-routing.module.ts ***!
    \*****************************************************************/

  /*! exports provided: AggMateriaPageRoutingModule */

  /***/
  function srcAppPagesAggMateriaAggMateriaRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AggMateriaPageRoutingModule", function () {
      return AggMateriaPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _agg_materia_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./agg-materia.page */
    "./src/app/pages/agg-materia/agg-materia.page.ts");

    var routes = [{
      path: '',
      component: _agg_materia_page__WEBPACK_IMPORTED_MODULE_3__["AggMateriaPage"]
    }];

    var AggMateriaPageRoutingModule = function AggMateriaPageRoutingModule() {
      _classCallCheck(this, AggMateriaPageRoutingModule);
    };

    AggMateriaPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AggMateriaPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/agg-materia/agg-materia.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/agg-materia/agg-materia.module.ts ***!
    \*********************************************************/

  /*! exports provided: AggMateriaPageModule */

  /***/
  function srcAppPagesAggMateriaAggMateriaModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AggMateriaPageModule", function () {
      return AggMateriaPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _agg_materia_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./agg-materia-routing.module */
    "./src/app/pages/agg-materia/agg-materia-routing.module.ts");
    /* harmony import */


    var _agg_materia_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./agg-materia.page */
    "./src/app/pages/agg-materia/agg-materia.page.ts");

    var AggMateriaPageModule = function AggMateriaPageModule() {
      _classCallCheck(this, AggMateriaPageModule);
    };

    AggMateriaPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _agg_materia_routing_module__WEBPACK_IMPORTED_MODULE_5__["AggMateriaPageRoutingModule"]],
      declarations: [_agg_materia_page__WEBPACK_IMPORTED_MODULE_6__["AggMateriaPage"]]
    })], AggMateriaPageModule);
    /***/
  },

  /***/
  "./src/app/pages/agg-materia/agg-materia.page.scss":
  /*!*********************************************************!*\
    !*** ./src/app/pages/agg-materia/agg-materia.page.scss ***!
    \*********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesAggMateriaAggMateriaPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".pick {\n  margin-left: 230px !important;\n  z-index: 1;\n  text-overflow: ellipsis;\n}\n\n.datetime {\n  font-size: x-large;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWdnLW1hdGVyaWEvQzpcXFVzZXJzXFxpc2FjXFxEZXNrdG9wXFxpb25pY1xccGFudGFWZXJzaW9uRWR1L3NyY1xcYXBwXFxwYWdlc1xcYWdnLW1hdGVyaWFcXGFnZy1tYXRlcmlhLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvYWdnLW1hdGVyaWEvYWdnLW1hdGVyaWEucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksNkJBQUE7RUFDQSxVQUFBO0VBQ0EsdUJBQUE7QUNDSjs7QURHQTtFQUNJLGtCQUFBO0FDQUoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9hZ2ctbWF0ZXJpYS9hZ2ctbWF0ZXJpYS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucGlja3tcclxuICAgIG1hcmdpbi1sZWZ0OiAyMzBweCAhaW1wb3J0YW50O1xyXG4gICAgei1pbmRleDogMTtcclxuICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG4gICAgLy90ZXh0LXNpemUtYWRqdXN0OiA7XHJcbn1cclxuXHJcbi5kYXRldGltZXtcclxuICAgIGZvbnQtc2l6ZTogeC1sYXJnZTtcclxufSIsIi5waWNrIHtcbiAgbWFyZ2luLWxlZnQ6IDIzMHB4ICFpbXBvcnRhbnQ7XG4gIHotaW5kZXg6IDE7XG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xufVxuXG4uZGF0ZXRpbWUge1xuICBmb250LXNpemU6IHgtbGFyZ2U7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pages/agg-materia/agg-materia.page.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/agg-materia/agg-materia.page.ts ***!
    \*******************************************************/

  /*! exports provided: AggMateriaPage */

  /***/
  function srcAppPagesAggMateriaAggMateriaPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AggMateriaPage", function () {
      return AggMateriaPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/db.service */
    "./src/app/services/db.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/services/alertas.service */
    "./src/app/services/alertas.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);

    var AggMateriaPage = /*#__PURE__*/function () {
      function AggMateriaPage(db, pk, alerta, navCtrl, activatedRoute, router) {
        var _this = this;

        _classCallCheck(this, AggMateriaPage);

        this.db = db;
        this.pk = pk;
        this.alerta = alerta;
        this.navCtrl = navCtrl;
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.dbMaterias = [];
        this.dbPeriodo = {};
        this.boo = false;
        this.verEven = false;
        this.validarEvent = false;
        this.titulo = 'Agregar materia';
        this.semanas = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'];
        this.modalMaterias = {
          // materia   
          nombre: '',
          id_evento: 0,
          id_periodo: 0,
          id_materia: 0,
          // periodo 
          periodo: '',
          // evento
          dia: 'lunes',
          inicio: '',
          fin: '',
          comentario: '',
          tipo: 'library'
        };
        this.activatedRoute.queryParams.subscribe(function (params) {
          if (_this.router.getCurrentNavigation().extras.state) {
            _this.boo = _this.router.getCurrentNavigation().extras.state.boo;
            _this.materiaId = _this.router.getCurrentNavigation().extras.state.id;
          }

          if (_this.boo) {
            _this.dataPreder();

            _this.titulo = 'Editar materia';
          }

          if (!_this.boo) {
            _this.activatedRoute.queryParams.subscribe(function (params) {
              if (_this.router.getCurrentNavigation().extras.state) {
                _this.modalMaterias.id_periodo = _this.router.getCurrentNavigation().extras.state.id;
                _this.modalMaterias.periodo = _this.router.getCurrentNavigation().extras.state.nombre;
              }
            });
          }
        });
      }

      _createClass(AggMateriaPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this2 = this;

          this.db.getDatabaseState().subscribe(function (boo) {
            if (boo) {
              _this2.db.getPeriodo().subscribe(function (data) {
                _this2.dbPeriodo = data;

                _this2.db.getMaterias().subscribe(function (data) {
                  _this2.dbMaterias = data;
                });
              });
            }
          });
        }
      }, {
        key: "pick",
        value: function pick() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this3 = this;

            var options, picker;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    options = {
                      cssClass: 'pick',
                      buttons: [{
                        text: "Cancelar",
                        role: 'cancel',
                        handler: function handler() {}
                      }, {
                        text: "Aceptar",
                        role: '',
                        handler: function handler(data) {
                          _this3.modalMaterias.dia = data.semanas.value;
                        }
                      }],
                      columns: [{
                        name: "semanas",
                        options: this.getOpt()
                      }]
                    };
                    _context.next = 3;
                    return this.pk.create(options);

                  case 3:
                    picker = _context.sent;
                    picker.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "getOpt",
        value: function getOpt() {
          var opt = [];
          this.semanas.forEach(function (x) {
            opt.push({
              text: x.toLocaleUpperCase(),
              value: x
            });
          });
          return opt;
        }
      }, {
        key: "ver",
        value: function ver() {
          this.verEven = !this.verEven;
        }
      }, {
        key: "guardarDatos",
        value: function guardarDatos() {
          var _this4 = this;

          if (this.boo) {
            this.editarDatos();
          } else {
            this.modalMaterias.nombre = this.modalMaterias.nombre.trim();
            this.validarHorario();

            if (this.verEven && this.modalMaterias.nombre.length > 0 && this.modalMaterias.inicio < this.modalMaterias.fin && this.validarEvent) {
              // Crear evento 
              this.db.agregarEvento(this.modalMaterias.nombre, this.modalMaterias.dia, this.modalMaterias.inicio, this.modalMaterias.fin, this.modalMaterias.tipo, this.modalMaterias.comentario, 1).then(function (data) {
                _this4.modalMaterias.id_evento = data; // Crear materia 

                _this4.db.agregarMaterias(_this4.modalMaterias.nombre, 1, _this4.modalMaterias.id_periodo, _this4.modalMaterias.id_evento).then(function (data) {
                  _this4.modalMaterias.id_materia = data;
                  console.log(_this4.modalMaterias.id_materia);
                }).then(function (_) {
                  // Crear carpeta 
                  _this4.db.agregarCarpeta(_this4.modalMaterias.nombre, 1, _this4.modalMaterias.id_materia);
                }).then(function (_) {
                  _this4.alerta.presentToast("Datos guardados con exito");

                  _this4.navCtrl.back();
                })["catch"](function (err) {
                  return _this4.alerta.presentToast(err);
                });
              });
            } else if (this.modalMaterias.nombre.length > 0 && !this.verEven) {
              this.db.agregarMaterias(this.modalMaterias.nombre, 1, this.modalMaterias.id_periodo, this.modalMaterias.id_evento).then(function (data) {
                _this4.modalMaterias.id_materia = data; // Crear carpeta 

                _this4.db.agregarCarpeta(_this4.modalMaterias.nombre, 1, _this4.modalMaterias.id_materia);
              }).then(function (_) {
                _this4.alerta.presentToast("Datos guardados con exito");

                _this4.navCtrl.back();
              });
            } else if (!this.validarEvent && this.verEven) {
              this.alerta.presentToast('Ya existe una materia registrada con este horario');
              this.borrarFecha();
            } else if (this.modalMaterias.inicio >= this.modalMaterias.fin && this.verEven) {
              this.alerta.presentToast('Horas incorrectas. El inicio debe ser antes que el fin');
              this.borrarFecha();
            } else this.alerta.presentToast('Ingrese un titulo para la materia');
          }
        }
      }, {
        key: "borrarFecha",
        value: function borrarFecha() {
          this.modalMaterias.inicio = '';
          this.modalMaterias.fin = '';
        }
      }, {
        key: "validarHorario",
        value: function validarHorario() {
          var evento = [];
          var id_evetoMateria;
          this.db.getEvento().subscribe(function (data) {
            evento = data;
          });

          var _iterator = _createForOfIteratorHelper(this.dbMaterias.entries()),
              _step;

          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var _step$value = _slicedToArray(_step.value, 2),
                  i = _step$value[0],
                  dat = _step$value[1];

              if (dat.id === this.materiaId) {
                id_evetoMateria = dat.id_evento;
              }
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }

          if (evento.length > 0) {
            var _iterator2 = _createForOfIteratorHelper(evento),
                _step2;

            try {
              for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                var event = _step2.value;
                console.log(this.modalMaterias.dia, " " + event.id);

                if (event.dia === this.modalMaterias.dia && id_evetoMateria != event.id && event.id && id_evetoMateria != 1) {
                  var inicio = moment__WEBPACK_IMPORTED_MODULE_6__(event.inicio).format("HH:mm");
                  var fin = moment__WEBPACK_IMPORTED_MODULE_6__(event.fin).format("HH:mm");
                  var inicioM = moment__WEBPACK_IMPORTED_MODULE_6__(this.modalMaterias.inicio).format("HH:mm");
                  var finM = moment__WEBPACK_IMPORTED_MODULE_6__(this.modalMaterias.fin).format("HH:mm");

                  if (inicio == inicioM && fin == finM || inicio <= inicioM && fin >= finM || inicio <= inicioM && fin <= finM && fin >= inicioM || inicio >= inicioM && fin >= finM && inicio <= finM || inicio >= inicioM && fin <= finM && inicio <= finM) {
                    return this.validarEvent = false;
                  } else this.validarEvent = true;
                }

                if (id_evetoMateria === 1) {
                  if (event.dia === this.modalMaterias.dia) {
                    var _inicio = moment__WEBPACK_IMPORTED_MODULE_6__(event.inicio).format("HH:mm");

                    var _fin = moment__WEBPACK_IMPORTED_MODULE_6__(event.fin).format("HH:mm");

                    var _inicioM = moment__WEBPACK_IMPORTED_MODULE_6__(this.modalMaterias.inicio).format("HH:mm");

                    var _finM = moment__WEBPACK_IMPORTED_MODULE_6__(this.modalMaterias.fin).format("HH:mm");

                    if (_inicio == _inicioM && _fin == _finM || _inicio <= _inicioM && _fin >= _finM || _inicio <= _inicioM && _fin <= _finM && _fin >= _inicioM || _inicio >= _inicioM && _fin >= _finM && _inicio <= _finM || _inicio >= _inicioM && _fin <= _finM && _inicio <= _finM) {
                      return this.validarEvent = false;
                    } else this.validarEvent = true;
                  } else this.validarEvent = true;
                } else this.validarEvent = true;
              }
            } catch (err) {
              _iterator2.e(err);
            } finally {
              _iterator2.f();
            }
          } else return this.validarEvent = true;
        }
      }, {
        key: "dataPreder",
        value: function dataPreder() {
          var _this5 = this;

          this.db.cargarMateriaId(this.materiaId).then(function (data) {
            _this5.modalMaterias.nombre = data.nombre;
            _this5.modalMaterias.id_periodo = data.id_periodo;
            _this5.modalMaterias.id_evento = data.id_evento;

            if (data.id_evento > 0) {
              _this5.db.cargarEventoId(data.id_evento).then(function (data2) {
                _this5.modalMaterias.dia = data2.dia;
                _this5.modalMaterias.inicio = data2.inicio;
                _this5.modalMaterias.fin = data2.fin;
                _this5.verEven = true;
              });
            }
          });
        }
      }, {
        key: "editarDatos",
        value: function editarDatos() {
          this.modalMaterias.nombre = this.modalMaterias.nombre.trim();
          this.validarHorario();
          console.log(this.validarEvent);

          if (this.verEven && this.modalMaterias.nombre.length > 0 && this.modalMaterias.inicio < this.modalMaterias.fin && this.validarEvent) {
            // Crear evento 
            this.db.updateEvento(this.modalMaterias.id_evento, this.modalMaterias.nombre, this.modalMaterias.dia, this.modalMaterias.inicio, this.modalMaterias.fin, this.modalMaterias.tipo, this.modalMaterias.comentario); // Crear materia 

            this.db.updateMaterias(this.materiaId, this.modalMaterias.nombre, this.modalMaterias.id_periodo); // Crear carpeta 

            this.db.updateCarpeta(this.materiaId, this.modalMaterias.nombre);
            this.alerta.presentToast("Datos actualizados con exito");
            this.navCtrl.back();
          } else if (this.modalMaterias.nombre.length > 0 && !this.verEven) {
            this.db.updateMaterias(this.materiaId, this.modalMaterias.nombre, this.modalMaterias.id_periodo); // Crear carpeta 

            this.db.updateCarpeta(this.materiaId, this.modalMaterias.nombre);
            this.alerta.presentToast("Datos actualizados con exito");
            this.navCtrl.back();
          } else if (!this.validarEvent && this.verEven) {
            this.alerta.presentToast('Ya existe una materia registrada con este horario');
            this.borrarFecha();
          } else if (this.modalMaterias.inicio >= this.modalMaterias.fin && this.verEven) {
            this.alerta.presentToast('Horas incorrectas. El inicio debe ser antes que el fin');
            this.borrarFecha();
          } else this.alerta.presentToast('Ingrese un titulo para la materia');
        }
      }]);

      return AggMateriaPage;
    }();

    AggMateriaPage.ctorParameters = function () {
      return [{
        type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PickerController"]
      }, {
        type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_4__["AlertasService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }];
    };

    AggMateriaPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-agg-materia',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./agg-materia.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/agg-materia/agg-materia.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./agg-materia.page.scss */
      "./src/app/pages/agg-materia/agg-materia.page.scss"))["default"]]
    })], AggMateriaPage);
    /***/
  },

  /***/
  "./src/app/services/alertas.service.ts":
  /*!*********************************************!*\
    !*** ./src/app/services/alertas.service.ts ***!
    \*********************************************/

  /*! exports provided: AlertasService */

  /***/
  function srcAppServicesAlertasServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AlertasService", function () {
      return AlertasService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./db.service */
    "./src/app/services/db.service.ts");

    var AlertasService = /*#__PURE__*/function () {
      function AlertasService(alertCtrl, dataSvc, db, toastCtrl) {
        _classCallCheck(this, AlertasService);

        this.alertCtrl = alertCtrl;
        this.dataSvc = dataSvc;
        this.db = db;
        this.toastCtrl = toastCtrl;
      }

      _createClass(AlertasService, [{
        key: "presentToast",
        value: function presentToast(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var toast;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.toastCtrl.create({
                      cssClass: "alert",
                      message: message,
                      duration: 2000
                    });

                  case 2:
                    toast = _context2.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }]);

      return AlertasService;
    }();

    AlertasService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
      }, {
        type: _db_service__WEBPACK_IMPORTED_MODULE_4__["DatabaseService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    AlertasService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], AlertasService);
    /***/
  }
}]);
//# sourceMappingURL=pages-agg-materia-agg-materia-module-es5.js.map