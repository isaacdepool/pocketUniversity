(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module~pages-imagen-modal-imagen-mo~3b5b6ad8"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/imagen-modal/imagen-modal.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/imagen-modal/imagen-modal.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n\n</ion-header>\n\n<ion-content>\n\n<ion-slides \n  class=\"slides\"\n  scrollbar=\"true\"\n  [options]=\"slideOpts\"\n  (ionSlidesDidLoad)=\"cambio()\"\n  (ionSlideDidChange)=\"cambio()\"\n  #slider>\n\n    <ng-container *ngFor=\"let fotos of dataFotos; let i = index\" >\n\n      <ion-slide \n      (click)=\" verOpts(fotos.id, i)\" >\n        <ion-img [src]=\"imgUrl[i]\"></ion-img>\n      </ion-slide>\n    </ng-container>\n\n  </ion-slides>\n\n\n  <ion-item [hidden]=\"opts\"\n  class=\"opts2\"\n  slot=\"fixed\"\n  color=\"dark\">\n\n  <div slot=\"start\">\n\n    <ion-button (click)=\"salir()\"\n    fill=\"clear\"\n    shape=\"round\"\n    size=\"medium\"\n    color=\"light\">\n      <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n    </ion-button>\n  \n  </div>\n\n  <div slot=\"end\">\n    \n    <ion-button (click)=\"info()\" \n    fill=\"clear\"\n    shape=\"round\"\n    size=\"medium\"\n    color=\"light\">\n      <ion-icon slot=\"icon-only\" name=\"alert-circle-outline\"></ion-icon>\n    </ion-button>\n\n  </div>\n\n  </ion-item>\n\n  \n  <ion-item [hidden]=\"opts\"\n  class=\"opts\"\n  slot=\"fixed\"\n  color=\"dark\">\n\n  <div slot=\"start\">\n\n    <ion-button (click)=\"favorite()\"\n    fill=\"clear\"\n    shape=\"round\"\n    size=\"medium\"\n    color=\"light\">\n      <ion-icon *ngIf=\"isFavorite[indexSlider] == 0\" slot=\"icon-only\" name=\"heart-Outline\"></ion-icon>\n      <ion-icon color=\"danger\" \n      *ngIf=\"isFavorite[indexSlider] == 1\" slot=\"icon-only\" name=\"heart\"></ion-icon>\n    </ion-button>\n  \n  </div>\n\n  \n  <ion-button (click)=\"compartir()\" \n  class=\"center\"\n  fill=\"clear\"\n  shape=\"round\"\n  size=\"medium\"\n  color=\"light\">\n    <ion-icon slot=\"icon-only\" name=\"share-Outline\"></ion-icon>\n  </ion-button>\n\n  <div slot=\"end\">\n    \n    <ion-button (click)=\"eliminarFoto()\" \n    fill=\"clear\"\n    shape=\"round\"\n    size=\"medium\"\n    color=\"light\">\n      <ion-icon slot=\"icon-only\" name=\"trash-Outline\"></ion-icon>\n    </ion-button>\n\n  </div>\n\n  </ion-item>\n\n\n\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"danger\">\n    \n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"salir()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title >Detalles</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-list *ngIf=\"tipo === 'imagenCarpeta'  && ver\"\n  class=\"ion-padding\">\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">Fecha</ion-label>\n      <ion-label>{{datosFotos[0].fecha | fecha}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Carpeta\n      </ion-label>\n      <ion-label>{{datosCarpeta[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\"> \n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Ruta\n      </ion-label>\n      <ion-label>Galeria/{{datosCarpeta[0].nombre}}/{{datosFotos[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\"\n      font-size=\"small\">Nombre\n      \n    </ion-label>\n      <ion-label>{{datosFotos[0].nombre}}</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list *ngIf=\"tipo === 'carpeta' && ver\">\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Nombre\n      </ion-label>\n      <ion-label>{{datosCarpeta[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Imagenes\n      </ion-label>\n      <ion-label>{{datosFotos.length}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Materia\n      </ion-label>\n      <ion-label *ngIf=\"datosCarpeta[0].id_materia > 0\">{{datosCarpeta[0].nombre}}</ion-label>\n      <ion-label *ngIf=\"datosCarpeta[0].id_materia == 0\">Carpeta independiente</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list *ngIf=\"tipo === 'materia' && ver\">\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Nombre\n      </ion-label>\n      <ion-label>{{datosMaterias[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item >\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Periodo academico\n      </ion-label>\n      <ion-label>{{datosPeriodo[0].nombre}}</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-title *ngIf=\"tipo === 'materia'\">Horario de clases</ion-title>\n\n  <ion-item *ngIf=\"datosEvento.length == 0 && tipo === 'materia'\">\n    <ion-label color=\"medium\"\n    position=\"fixed\">\n      Sin horario de clases\n    </ion-label>\n  </ion-item>\n\n  <ion-list *ngIf=\"tipo === 'materia' && ver && datosEvento.length > 0\">\n\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Dia\n      </ion-label>\n      <ion-label>{{datosEvento[0].dia | dia: datosEvento[0].dia}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Inicio\n      </ion-label>\n      <ion-label>{{datosEvento[0].inicio | hora}}</ion-label>\n    </ion-item>\n\n  <ion-item lines=\"none\">\n    <ion-label color=\"medium\"\n    position=\"fixed\">\n      Fin\n    </ion-label>\n    <ion-label>{{datosEvento[0].fin | hora}}</ion-label>\n  </ion-item>\n\n<ion-item >\n  <ion-label color=\"medium\"\n  position=\"fixed\">\n    Comentarios\n  </ion-label>\n  <ion-label>{{datosEvento[0].comentario || 'Sin comentarios'}}</ion-label>\n</ion-item>\n</ion-list>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/imagen-modal/imagen-modal.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/pages/imagen-modal/imagen-modal.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".opts {\n  z-index: 1;\n  bottom: 0;\n  width: 100%;\n  opacity: 90%;\n}\n\n.opts2 {\n  z-index: 1;\n  top: 0;\n  width: 100%;\n  opacity: 90%;\n}\n\n.center {\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaW1hZ2VuLW1vZGFsL0M6XFxVc2Vyc1xcaXNhY1xcRGVza3RvcFxcaW9uaWNcXHBhbnRhVmVyc2lvbkVkdS9zcmNcXGFwcFxccGFnZXNcXGltYWdlbi1tb2RhbFxcaW1hZ2VuLW1vZGFsLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvaW1hZ2VuLW1vZGFsL2ltYWdlbi1tb2RhbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDSSxVQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDQUo7O0FER0E7RUFDSSxVQUFBO0VBQ0EsTUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDQUo7O0FER0E7RUFFSSxZQUFBO0FDREoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9pbWFnZW4tbW9kYWwvaW1hZ2VuLW1vZGFsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4ub3B0c3tcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG9wYWNpdHk6IDkwJTtcclxufVxyXG5cclxuLm9wdHMye1xyXG4gICAgei1pbmRleDogMTtcclxuICAgIHRvcDogMDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgb3BhY2l0eTogOTAlO1xyXG59XHJcblxyXG4uY2VudGVye1xyXG5cclxuICAgIG1hcmdpbjogYXV0bztcclxufSIsIi5vcHRzIHtcbiAgei1pbmRleDogMTtcbiAgYm90dG9tOiAwO1xuICB3aWR0aDogMTAwJTtcbiAgb3BhY2l0eTogOTAlO1xufVxuXG4ub3B0czIge1xuICB6LWluZGV4OiAxO1xuICB0b3A6IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBvcGFjaXR5OiA5MCU7XG59XG5cbi5jZW50ZXIge1xuICBtYXJnaW46IGF1dG87XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/imagen-modal/imagen-modal.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/imagen-modal/imagen-modal.page.ts ***!
  \*********************************************************/
/*! exports provided: ImagenModalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImagenModalPage", function() { return ImagenModalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/db.service */ "./src/app/services/db.service.ts");
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/alertas.service */ "./src/app/services/alertas.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/social-sharing/ngx */ "./node_modules/@ionic-native/social-sharing/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _info_modal_info_modal_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../info-modal/info-modal.page */ "./src/app/pages/info-modal/info-modal.page.ts");
/* harmony import */ var src_app_services_galeria_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/galeria.service */ "./src/app/services/galeria.service.ts");








let ImagenModalPage = class ImagenModalPage {
    constructor(db, alertSvc, alertCtrl, socialSharing, modalCtrl, galeriaSvc) {
        this.db = db;
        this.alertSvc = alertSvc;
        this.alertCtrl = alertCtrl;
        this.socialSharing = socialSharing;
        this.modalCtrl = modalCtrl;
        this.galeriaSvc = galeriaSvc;
        this.isFavorite = [];
        this.opts = true;
        this.isAlbuma = true;
        this.ver = false;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400
        };
    }
    ngOnInit() {
        this.slideOpts.initialSlide = this.index;
        this.indexO = this.index;
        this.fotoIdSelect = this.id;
    }
    ionViewWillEnter() {
    }
    ionViewWillLeave() {
        // for( let [i, idx] of this.isFavorite.entries() )
        // this.db.updateFotosFav(this.dataFotos[i].id, idx)
        // .then( _ =>{
        //   // this.clear();
        // })
    }
    verOpts(id, index) {
        this.fotoIdSelect = id;
        this.indexO = index;
        if (this.opts == false) {
            this.opts = false;
            setTimeout(() => {
                this.opts = true;
            }, 4000);
        }
        else {
            this.opts = false;
            setTimeout(() => {
                this.opts = true;
            }, 4000);
        }
    }
    eliminarFoto() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'alert-css',
                header: '¿Quieres eliminar esta imagen?',
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        handler: () => {
                        }
                    },
                    {
                        text: 'Eliminar',
                        role: 'ok',
                        handler: () => {
                            for (let fotos of this.dataFotos) {
                                if (fotos.id == this.fotoIdSelect) {
                                    this.galeriaSvc.deleteFileGaleria(fotos.nombre);
                                    this.galeriaSvc.deleteFileRoot(fotos.url, fotos.nombre);
                                }
                            }
                            this.db.eliminarFotos(this.fotoIdSelect).then(_ => {
                                this.ver = !this.ver;
                                this.modalCtrl.dismiss();
                                this.isAlbuma = !this.isAlbuma;
                                this.alertSvc.presentToast("Imagen eliminada con exito");
                                this.opts = true;
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    favorite() {
        if (this.isFavorite[this.indexSlider] == 0) {
            this.isFavorite[this.indexSlider] = 1;
        }
        else
            this.isFavorite[this.indexSlider] = 0;
        this.dataFotos[this.indexSlider].favorito = this.isFavorite[this.indexSlider];
        for (let [i, idx] of this.isFavorite.entries())
            this.db.updateFotosFav(this.dataFotos[i].id, idx)
                .then(_ => {
                // this.clear();
            });
    }
    cambio() {
        this.slider.getActiveIndex().then(data => {
            this.indexSlider = data;
            this.fotoIdSelect = this.dataFotos[this.indexSlider].id;
        });
    }
    compartir() {
        this.socialSharing.share('hola', 'como estas', this.dataFotos[this.indexO].url).catch(err => console.log(err));
    }
    info() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _info_modal_info_modal_page__WEBPACK_IMPORTED_MODULE_6__["InfoModalPage"],
                componentProps: {
                    tipo: 'imagenCarpeta',
                    id: this.fotoIdSelect,
                    editarMateria: false
                }
            });
            yield modal.present();
        });
    }
    clear() {
        this.id = '';
        this.index = '';
        this.imgUrl = '';
        this.dataFotos = [];
        this.isFavorite = [];
        this.opts = true;
        this.isAlbuma = true;
        this.ver = false;
        this.fotoIdSelect = 0;
        this.indexO = 0;
        this.indexSlider = 0;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400
        };
    }
    salir() {
        this.modalCtrl.dismiss();
    }
};
ImagenModalPage.ctorParameters = () => [
    { type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"] },
    { type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__["AlertasService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_5__["SocialSharing"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: src_app_services_galeria_service__WEBPACK_IMPORTED_MODULE_7__["GaleriaService"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], ImagenModalPage.prototype, "id", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], ImagenModalPage.prototype, "index", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], ImagenModalPage.prototype, "imgUrl", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], ImagenModalPage.prototype, "dataFotos", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], ImagenModalPage.prototype, "isFavorite", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('slider')
], ImagenModalPage.prototype, "slider", void 0);
ImagenModalPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-imagen-modal',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./imagen-modal.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/imagen-modal/imagen-modal.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./imagen-modal.page.scss */ "./src/app/pages/imagen-modal/imagen-modal.page.scss")).default]
    })
], ImagenModalPage);



/***/ }),

/***/ "./src/app/pages/info-modal/info-modal.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/pages/info-modal/info-modal.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luZm8tbW9kYWwvaW5mby1tb2RhbC5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/info-modal/info-modal.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/info-modal/info-modal.page.ts ***!
  \*****************************************************/
/*! exports provided: InfoModalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfoModalPage", function() { return InfoModalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/db.service */ "./src/app/services/db.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let InfoModalPage = class InfoModalPage {
    constructor(db, modalCtrl) {
        this.db = db;
        this.modalCtrl = modalCtrl;
        this.ver = false;
        this.datosFotos = [];
        this.datosCarpeta = [];
        this.datosMaterias = [];
        this.datosEvento = [];
        this.datosPeriodo = [];
    }
    ngOnInit() {
        console.log(this.id);
    }
    ionViewWillEnter() {
        this.db.getDatabaseState().subscribe(boo => {
            if (boo) {
                if (this.tipo === 'imagenCarpeta') {
                    this.cargarFotos();
                    this.cargarCarpeta();
                }
                if (this.tipo === 'carpeta') {
                    this.cargarCarpetaId();
                    this.cargarFotos();
                }
                if (this.tipo === 'materia') {
                    this.cargarMateriasId();
                }
            }
        });
    }
    salir() {
        this.modalCtrl.dismiss();
    }
    cargarFotos() {
        this.db.getFotos().subscribe(data => {
            for (let datos of data) {
                if (datos.id == this.id && this.tipo === 'imagenCarpeta') {
                    this.datosFotos.push(datos);
                    this.ver = true;
                }
                else if (datos.id_carpeta == this.id && this.tipo === 'carpeta') {
                    this.datosFotos.push(datos);
                }
            }
        });
    }
    cargarCarpeta() {
        this.db.getCarpeta().subscribe(data => {
            for (let datos of data) {
                if (datos.id == this.datosFotos[0].id_carpeta) {
                    this.datosCarpeta.push(datos);
                }
            }
            this.ver = true;
        });
    }
    cargarCarpetaId() {
        this.db.cargarCarpetaId(this.id).then(data => {
            this.datosCarpeta.push(data);
            console.log(data);
            this.ver = true;
        });
    }
    cargarMateriasId() {
        this.db.cargarMateriaId(this.id).then(data => {
            this.datosMaterias.push(data);
            this.ver = true;
            this.cargarEvento();
            this.cargarPeriodo();
        });
    }
    cargarEvento() {
        if (this.datosMaterias[0].id_evento > 0) {
            this.db.cargarEventoId(this.datosMaterias[0].id_evento).then(data => {
                if (data) {
                    this.datosEvento.push(data);
                }
            });
        }
    }
    cargarPeriodo() {
        this.db.cargarPeriodoId(this.datosMaterias[0].id_periodo).then(data => {
            this.datosPeriodo.push(data);
        });
    }
};
InfoModalPage.ctorParameters = () => [
    { type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], InfoModalPage.prototype, "tipo", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], InfoModalPage.prototype, "id", void 0);
InfoModalPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-info-modal',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./info-modal.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./info-modal.page.scss */ "./src/app/pages/info-modal/info-modal.page.scss")).default]
    })
], InfoModalPage);



/***/ }),

/***/ "./src/app/services/alertas.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/alertas.service.ts ***!
  \*********************************************/
/*! exports provided: AlertasService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertasService", function() { return AlertasService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./data.service */ "./src/app/services/data.service.ts");
/* harmony import */ var _db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./db.service */ "./src/app/services/db.service.ts");





let AlertasService = class AlertasService {
    constructor(alertCtrl, dataSvc, db, toastCtrl) {
        this.alertCtrl = alertCtrl;
        this.dataSvc = dataSvc;
        this.db = db;
        this.toastCtrl = toastCtrl;
    }
    presentToast(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                cssClass: "alert",
                message,
                duration: 2000,
            });
            toast.present();
        });
    }
};
AlertasService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"] },
    { type: _db_service__WEBPACK_IMPORTED_MODULE_4__["DatabaseService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
AlertasService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AlertasService);



/***/ })

}]);
//# sourceMappingURL=default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module~pages-imagen-modal-imagen-mo~3b5b6ad8-es2015.js.map