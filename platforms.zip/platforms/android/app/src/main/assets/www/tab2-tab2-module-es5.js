function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab2-tab2-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab2/tab2.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab2/tab2.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesTab2Tab2PageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar color=\"header\">\n        <ion-buttons slot=\"start\">\n            <ion-back-button defaultHref=\"tabs/tab1\"></ion-back-button>\n            <ion-title>Ingresar gasto</ion-title>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n\n    <ion-item lines=\"none\">\n        <h1>\n            Categorias\n        </h1>\n    </ion-item>\n\n    <form #form=\"ngForm\" (ngSubmit)=\"ingresarGasto()\">\n           \n        <ion-segment scrollable=\"true\" \n        mode=\"md\" \n        color=\"header\" \n        (ionChange)=\"cambioCategoria( $event)\" \n        [value]=\"icon[0]\">\n\n            <ion-segment-button mode=\"md\" *ngFor=\"let ico of icon\" [value]=\"ico.nom\">\n                <ion-label class=\"ion-text-capitalize\">\n                    <ion-icon class=\"ic\" [name]=\"ico.icono \"></ion-icon>\n                </ion-label>\n                {{ico.nom}}\n            </ion-segment-button>\n\n\n\n        </ion-segment>\n\n        <div class=\"bot\">\n            <ion-list class=\"ion-padding\">\n                        <ion-item>\n                            <ion-input placeholder=\"$ 0.0\"\n                            type=\"cc-number\" \n                            name=\"value\" \n                            inputmode=\"decimal\" \n                            autocorrect=\"on\" \n                            [(ngModel)]=\"value\" \n                            pattern=\"[0-9]+(?:[.,][0-9]{1,2})?\" \n                            step=\"0.01\" \n                            strong></ion-input>\n\n                            <ion-button\n                            slot=\"end\" \n                            strong fill=\"clear\" \n                            (click)=\"numbers('borrar')\">\n                                <ion-icon slot=\"icon-only\" name=\"backspace-outline\"></ion-icon>\n                            </ion-button>\n                        </ion-item>\n\n                        <!-- Comentario -->\n        <ion-item>\n          <ion-icon slot=\"start\" name=\"pencil\"></ion-icon>\n    \n          <ion-label position=\"floating\">\n            Descripcion</ion-label>\n          \n          <ion-input\n          type=\"text\"\n          name=\"Descrip\"\n          [(ngModel)]=\"descrip\"\n          maxlegth=\"100\">\n          \n        </ion-input>\n        \n        \n      </ion-item>\n      \n            </ion-list>\n            \n\n        </div>\n        <ion-button class=\"ion-padding\"\n        [disabled]=\"form.invalid\" \n        type=\"submit\" \n        expand=\"full\" \n        color=\"danger\">\n            Agregar\n        </ion-button>\n    </form>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/tab2/tab2-routing.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/pages/tab2/tab2-routing.module.ts ***!
    \***************************************************/

  /*! exports provided: Tab2PageRoutingModule */

  /***/
  function srcAppPagesTab2Tab2RoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Tab2PageRoutingModule", function () {
      return Tab2PageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _tab2_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./tab2.page */
    "./src/app/pages/tab2/tab2.page.ts");

    var routes = [{
      path: '',
      component: _tab2_page__WEBPACK_IMPORTED_MODULE_3__["Tab2Page"]
    }];

    var Tab2PageRoutingModule = function Tab2PageRoutingModule() {
      _classCallCheck(this, Tab2PageRoutingModule);
    };

    Tab2PageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], Tab2PageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/tab2/tab2.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/pages/tab2/tab2.module.ts ***!
    \*******************************************/

  /*! exports provided: Tab2PageModule */

  /***/
  function srcAppPagesTab2Tab2ModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Tab2PageModule", function () {
      return Tab2PageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _tab2_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./tab2-routing.module */
    "./src/app/pages/tab2/tab2-routing.module.ts");
    /* harmony import */


    var _tab2_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./tab2.page */
    "./src/app/pages/tab2/tab2.page.ts");
    /* harmony import */


    var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/components/components.module */
    "./src/app/components/components.module.ts");

    var Tab2PageModule = function Tab2PageModule() {
      _classCallCheck(this, Tab2PageModule);
    };

    Tab2PageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _tab2_routing_module__WEBPACK_IMPORTED_MODULE_5__["Tab2PageRoutingModule"]],
      declarations: [_tab2_page__WEBPACK_IMPORTED_MODULE_6__["Tab2Page"]]
    })], Tab2PageModule);
    /***/
  },

  /***/
  "./src/app/pages/tab2/tab2.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/pages/tab2/tab2.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesTab2Tab2PageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-icon {\n  font-size: 24px;\n}\n\n.num-bo {\n  width: 32.2%;\n  height: 64px;\n}\n\nion-button {\n  --color: #eb445a;\n  --ripple-color: rgb(192, 186, 186);\n}\n\n.add {\n  position: fixed;\n  left: 0;\n  bottom: 0px;\n  right: 0;\n}\n\n.ic {\n  color: grey;\n}\n\nion-segment {\n  margin-top: 20px;\n}\n\n.segment-button-checked {\n  color: var(--ion-color-danger) !important;\n}\n\n.bot {\n  margin-top: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdGFiMi9DOlxcVXNlcnNcXGlzYWNcXERlc2t0b3BcXGlvbmljXFxwYW50YVZlcnNpb25FZHUvc3JjXFxhcHBcXHBhZ2VzXFx0YWIyXFx0YWIyLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvdGFiMi90YWIyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7QUNDSjs7QURFQTtFQUNJLFlBQUE7RUFDQSxZQUFBO0FDQ0o7O0FERUE7RUFDSSxnQkFBQTtFQUNBLGtDQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxRQUFBO0FDQ0o7O0FERUE7RUFDSSxXQUFBO0FDQ0o7O0FERUE7RUFDSSxnQkFBQTtBQ0NKOztBREVBO0VBQ0kseUNBQUE7QUNDSjs7QURFQTtFQUNJLGdCQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy90YWIyL3RhYjIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWljb24ge1xyXG4gICAgZm9udC1zaXplOiAyNHB4O1xyXG59XHJcblxyXG4ubnVtLWJvIHtcclxuICAgIHdpZHRoOiAzMi4yJTtcclxuICAgIGhlaWdodDogNjRweDtcclxufVxyXG5cclxuaW9uLWJ1dHRvbiB7XHJcbiAgICAtLWNvbG9yOiAjZWI0NDVhO1xyXG4gICAgLS1yaXBwbGUtY29sb3I6IHJnYigxOTIsIDE4NiwgMTg2KTtcclxufVxyXG5cclxuLmFkZCB7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgYm90dG9tOiAwcHg7XHJcbiAgICByaWdodDogMDtcclxufVxyXG5cclxuLmljIHtcclxuICAgIGNvbG9yOiBncmV5O1xyXG59XHJcblxyXG5pb24tc2VnbWVudCB7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG59XHJcblxyXG4uc2VnbWVudC1idXR0b24tY2hlY2tlZCB7XHJcbiAgICBjb2xvcjogdmFyKCAtLWlvbi1jb2xvci1kYW5nZXIpICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5ib3Qge1xyXG4gICAgbWFyZ2luLXRvcDogMzBweDtcclxufSIsImlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNHB4O1xufVxuXG4ubnVtLWJvIHtcbiAgd2lkdGg6IDMyLjIlO1xuICBoZWlnaHQ6IDY0cHg7XG59XG5cbmlvbi1idXR0b24ge1xuICAtLWNvbG9yOiAjZWI0NDVhO1xuICAtLXJpcHBsZS1jb2xvcjogcmdiKDE5MiwgMTg2LCAxODYpO1xufVxuXG4uYWRkIHtcbiAgcG9zaXRpb246IGZpeGVkO1xuICBsZWZ0OiAwO1xuICBib3R0b206IDBweDtcbiAgcmlnaHQ6IDA7XG59XG5cbi5pYyB7XG4gIGNvbG9yOiBncmV5O1xufVxuXG5pb24tc2VnbWVudCB7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG59XG5cbi5zZWdtZW50LWJ1dHRvbi1jaGVja2VkIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYW5nZXIpICFpbXBvcnRhbnQ7XG59XG5cbi5ib3Qge1xuICBtYXJnaW4tdG9wOiAzMHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/tab2/tab2.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/pages/tab2/tab2.page.ts ***!
    \*****************************************/

  /*! exports provided: Tab2Page */

  /***/
  function srcAppPagesTab2Tab2PageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Tab2Page", function () {
      return Tab2Page;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/db.service */
    "./src/app/services/db.service.ts");
    /* harmony import */


    var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/services/alertas.service */
    "./src/app/services/alertas.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var Tab2Page = /*#__PURE__*/function () {
      function Tab2Page(db, alerta, navCtrl) {
        _classCallCheck(this, Tab2Page);

        this.db = db;
        this.alerta = alerta;
        this.navCtrl = navCtrl;
        this.now = new Date();
        this.icosele = '';
        this.value = '';
        this.listo = true;
        this.coma = 0;
        this.id_gasto = 0;
        this.descrip = ''; // tslint:disable-next-line:max-line-length

        this.icon = [{
          icono: 'shirt',
          nom: 'Ropa'
        }, {
          icono: 'fast-food',
          nom: 'Comida'
        }, {
          icono: 'book',
          nom: 'Universidad'
        }, {
          icono: 'wallet',
          nom: 'Deudas'
        }, {
          icono: 'shuffle',
          nom: 'Otros'
        }];
        this.numeros = [[7, 8, 9], [4, 5, 6], [1, 2, 3], [',', 0, 'C']];
        this.disabled = false;
        this.disabled2 = false;
      }

      _createClass(Tab2Page, [{
        key: "cambioCategoria",
        value: function cambioCategoria(event) {
          // this.noticias = [];
          this.segment.value = event.detail.value;
        }
      }, {
        key: "numbers",
        value: function numbers(num) {
          if (num === '.') {
            this.disabled = true;
          }

          if (num === 'borrar') {
            this.value = this.value.substring(0, this.value.length - 1);

            if (this.value.indexOf(',')) {
              this.disabled = false;
            }
          } else {
            if (this.listo) {
              this.value = '' + num;
            } else {
              this.value += '' + num;
            }

            this.listo = false;
          }

          if (num === 'C') {
            this.value = '0';
            this.listo = true;
            this.disabled2 = false;
            this.disabled = false;
            this.coma = 0;
            this.descrip = '';
          }
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.segment.value = this.icon[0].nom;
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ingresarGasto",
        value: function ingresarGasto() {
          var _this = this;

          switch (this.segment.value) {
            case 'Ropa':
              {
                this.icosele = 'shirt';
                break;
              }

            case 'Universidad':
              {
                this.icosele = 'book';
                break;
              }

            case 'Comida':
              {
                this.icosele = 'fast-food';
                break;
              }

            case 'Deudas':
              {
                this.icosele = 'wallet';
                break;
              }

            case 'Otros':
              {
                this.icosele = 'shuffle';
                break;
              }

            default:
              {
                //statements; 
                break;
              }
          }

          if (parseFloat(this.value) > 0) {
            // Agregar Gasto 
            this.db.agregarGasto(this.value, this.segment.value, this.descrip, this.now.toISOString(), this.icosele, 1).then(function (_) {
              _this.alerta.presentToast('Datos guardados con exito');

              _this.navCtrl.back();
            })["catch"](function (err) {
              return _this.alerta.presentToast(err);
            })["finally"]();
          } else {
            this.alerta.presentToast('Ingrese un monto');
          }
        }
      }]);

      return Tab2Page;
    }();

    Tab2Page.ctorParameters = function () {
      return [{
        type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"]
      }, {
        type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_3__["AlertasService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonSegment"])], Tab2Page.prototype, "segment", void 0);
    Tab2Page = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-tab2',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./tab2.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tab2/tab2.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./tab2.page.scss */
      "./src/app/pages/tab2/tab2.page.scss"))["default"]]
    })], Tab2Page);
    /***/
  },

  /***/
  "./src/app/services/alertas.service.ts":
  /*!*********************************************!*\
    !*** ./src/app/services/alertas.service.ts ***!
    \*********************************************/

  /*! exports provided: AlertasService */

  /***/
  function srcAppServicesAlertasServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AlertasService", function () {
      return AlertasService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./db.service */
    "./src/app/services/db.service.ts");

    var AlertasService = /*#__PURE__*/function () {
      function AlertasService(alertCtrl, dataSvc, db, toastCtrl) {
        _classCallCheck(this, AlertasService);

        this.alertCtrl = alertCtrl;
        this.dataSvc = dataSvc;
        this.db = db;
        this.toastCtrl = toastCtrl;
      }

      _createClass(AlertasService, [{
        key: "presentToast",
        value: function presentToast(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var toast;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.toastCtrl.create({
                      cssClass: "alert",
                      message: message,
                      duration: 2000
                    });

                  case 2:
                    toast = _context.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }]);

      return AlertasService;
    }();

    AlertasService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
      }, {
        type: _db_service__WEBPACK_IMPORTED_MODULE_4__["DatabaseService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    AlertasService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], AlertasService);
    /***/
  }
}]);
//# sourceMappingURL=tab2-tab2-module-es5.js.map