function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
  /***/
  "./$$_lazy_route_resource lazy recursive":
  /*!******************************************************!*\
    !*** ./$$_lazy_route_resource lazy namespace object ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function $$_lazy_route_resourceLazyRecursive(module, exports) {
    function webpackEmptyAsyncContext(req) {
      // Here Promise.resolve().then() is used instead of new Promise() to prevent
      // uncaught exception popping up in devtools
      return Promise.resolve().then(function () {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      });
    }

    webpackEmptyAsyncContext.keys = function () {
      return [];
    };

    webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
    module.exports = webpackEmptyAsyncContext;
    webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
    /***/
  },

  /***/
  "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
  /*!*****************************************************************************************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
    \*****************************************************************************************************************************************/

  /*! no static exports found */

  /***/
  function node_modulesIonicCoreDistEsmLazyRecursiveEntryJs$IncludeEntryJs$ExcludeSystemEntryJs$(module, exports, __webpack_require__) {
    var map = {
      "./ion-action-sheet-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-action-sheet-ios.entry.js", "common", 0],
      "./ion-action-sheet-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-action-sheet-md.entry.js", "common", 1],
      "./ion-alert-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-alert-ios.entry.js", "common", 2],
      "./ion-alert-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-alert-md.entry.js", "common", 3],
      "./ion-app_8-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-app_8-ios.entry.js", "common", 4],
      "./ion-app_8-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-app_8-md.entry.js", "common", 5],
      "./ion-avatar_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-avatar_3-ios.entry.js", "common", 6],
      "./ion-avatar_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-avatar_3-md.entry.js", "common", 7],
      "./ion-back-button-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-back-button-ios.entry.js", "common", 8],
      "./ion-back-button-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-back-button-md.entry.js", "common", 9],
      "./ion-backdrop-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-backdrop-ios.entry.js", 10],
      "./ion-backdrop-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-backdrop-md.entry.js", 11],
      "./ion-button_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-button_2-ios.entry.js", "common", 12],
      "./ion-button_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-button_2-md.entry.js", "common", 13],
      "./ion-card_5-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-card_5-ios.entry.js", "common", 14],
      "./ion-card_5-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-card_5-md.entry.js", "common", 15],
      "./ion-checkbox-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-checkbox-ios.entry.js", "common", 16],
      "./ion-checkbox-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-checkbox-md.entry.js", "common", 17],
      "./ion-chip-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-chip-ios.entry.js", "common", 18],
      "./ion-chip-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-chip-md.entry.js", "common", 19],
      "./ion-col_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js", 20],
      "./ion-datetime_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-datetime_3-ios.entry.js", "common", 21],
      "./ion-datetime_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-datetime_3-md.entry.js", "common", 22],
      "./ion-fab_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-fab_3-ios.entry.js", "common", 23],
      "./ion-fab_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-fab_3-md.entry.js", "common", 24],
      "./ion-img.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-img.entry.js", 25],
      "./ion-infinite-scroll_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-ios.entry.js", 26],
      "./ion-infinite-scroll_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2-md.entry.js", 27],
      "./ion-input-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-input-ios.entry.js", "common", 28],
      "./ion-input-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-input-md.entry.js", "common", 29],
      "./ion-item-option_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item-option_3-ios.entry.js", "common", 30],
      "./ion-item-option_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item-option_3-md.entry.js", "common", 31],
      "./ion-item_8-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item_8-ios.entry.js", "common", 32],
      "./ion-item_8-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item_8-md.entry.js", "common", 33],
      "./ion-loading-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-loading-ios.entry.js", "common", 34],
      "./ion-loading-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-loading-md.entry.js", "common", 35],
      "./ion-menu_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-menu_3-ios.entry.js", "common", 36],
      "./ion-menu_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-menu_3-md.entry.js", "common", 37],
      "./ion-modal-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-modal-ios.entry.js", "common", 38],
      "./ion-modal-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-modal-md.entry.js", "common", 39],
      "./ion-nav_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-nav_2.entry.js", "common", 40],
      "./ion-popover-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-popover-ios.entry.js", "common", 41],
      "./ion-popover-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-popover-md.entry.js", "common", 42],
      "./ion-progress-bar-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-progress-bar-ios.entry.js", "common", 43],
      "./ion-progress-bar-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-progress-bar-md.entry.js", "common", 44],
      "./ion-radio_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-radio_2-ios.entry.js", "common", 45],
      "./ion-radio_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-radio_2-md.entry.js", "common", 46],
      "./ion-range-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-range-ios.entry.js", "common", 47],
      "./ion-range-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-range-md.entry.js", "common", 48],
      "./ion-refresher_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-refresher_2-ios.entry.js", "common", 49],
      "./ion-refresher_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-refresher_2-md.entry.js", "common", 50],
      "./ion-reorder_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-reorder_2-ios.entry.js", "common", 51],
      "./ion-reorder_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-reorder_2-md.entry.js", "common", 52],
      "./ion-ripple-effect.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js", 53],
      "./ion-route_4.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js", "common", 54],
      "./ion-searchbar-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-searchbar-ios.entry.js", "common", 55],
      "./ion-searchbar-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-searchbar-md.entry.js", "common", 56],
      "./ion-segment_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-segment_2-ios.entry.js", "common", 57],
      "./ion-segment_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-segment_2-md.entry.js", "common", 58],
      "./ion-select_3-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-select_3-ios.entry.js", "common", 59],
      "./ion-select_3-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-select_3-md.entry.js", "common", 60],
      "./ion-slide_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-slide_2-ios.entry.js", 61],
      "./ion-slide_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-slide_2-md.entry.js", 62],
      "./ion-spinner.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js", "common", 63],
      "./ion-split-pane-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-split-pane-ios.entry.js", 64],
      "./ion-split-pane-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-split-pane-md.entry.js", 65],
      "./ion-tab-bar_2-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-ios.entry.js", "common", 66],
      "./ion-tab-bar_2-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab-bar_2-md.entry.js", "common", 67],
      "./ion-tab_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js", "common", 68],
      "./ion-text.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-text.entry.js", "common", 69],
      "./ion-textarea-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-textarea-ios.entry.js", "common", 70],
      "./ion-textarea-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-textarea-md.entry.js", "common", 71],
      "./ion-toast-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toast-ios.entry.js", "common", 72],
      "./ion-toast-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toast-md.entry.js", "common", 73],
      "./ion-toggle-ios.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toggle-ios.entry.js", "common", 74],
      "./ion-toggle-md.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toggle-md.entry.js", "common", 75],
      "./ion-virtual-scroll.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js", 76]
    };

    function webpackAsyncContext(req) {
      if (!__webpack_require__.o(map, req)) {
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      var ids = map[req],
          id = ids[0];
      return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function () {
        return __webpack_require__(id);
      });
    }

    webpackAsyncContext.keys = function webpackAsyncContextKeys() {
      return Object.keys(map);
    };

    webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
    module.exports = webpackAsyncContext;
    /***/
  },

  /***/
  "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
  /*!**************************************************!*\
    !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
    \**************************************************/

  /*! no static exports found */

  /***/
  function node_modulesMomentLocaleSyncRecursive$(module, exports, __webpack_require__) {
    var map = {
      "./af": "./node_modules/moment/locale/af.js",
      "./af.js": "./node_modules/moment/locale/af.js",
      "./ar": "./node_modules/moment/locale/ar.js",
      "./ar-dz": "./node_modules/moment/locale/ar-dz.js",
      "./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
      "./ar-kw": "./node_modules/moment/locale/ar-kw.js",
      "./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
      "./ar-ly": "./node_modules/moment/locale/ar-ly.js",
      "./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
      "./ar-ma": "./node_modules/moment/locale/ar-ma.js",
      "./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
      "./ar-sa": "./node_modules/moment/locale/ar-sa.js",
      "./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
      "./ar-tn": "./node_modules/moment/locale/ar-tn.js",
      "./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
      "./ar.js": "./node_modules/moment/locale/ar.js",
      "./az": "./node_modules/moment/locale/az.js",
      "./az.js": "./node_modules/moment/locale/az.js",
      "./be": "./node_modules/moment/locale/be.js",
      "./be.js": "./node_modules/moment/locale/be.js",
      "./bg": "./node_modules/moment/locale/bg.js",
      "./bg.js": "./node_modules/moment/locale/bg.js",
      "./bm": "./node_modules/moment/locale/bm.js",
      "./bm.js": "./node_modules/moment/locale/bm.js",
      "./bn": "./node_modules/moment/locale/bn.js",
      "./bn-bd": "./node_modules/moment/locale/bn-bd.js",
      "./bn-bd.js": "./node_modules/moment/locale/bn-bd.js",
      "./bn.js": "./node_modules/moment/locale/bn.js",
      "./bo": "./node_modules/moment/locale/bo.js",
      "./bo.js": "./node_modules/moment/locale/bo.js",
      "./br": "./node_modules/moment/locale/br.js",
      "./br.js": "./node_modules/moment/locale/br.js",
      "./bs": "./node_modules/moment/locale/bs.js",
      "./bs.js": "./node_modules/moment/locale/bs.js",
      "./ca": "./node_modules/moment/locale/ca.js",
      "./ca.js": "./node_modules/moment/locale/ca.js",
      "./cs": "./node_modules/moment/locale/cs.js",
      "./cs.js": "./node_modules/moment/locale/cs.js",
      "./cv": "./node_modules/moment/locale/cv.js",
      "./cv.js": "./node_modules/moment/locale/cv.js",
      "./cy": "./node_modules/moment/locale/cy.js",
      "./cy.js": "./node_modules/moment/locale/cy.js",
      "./da": "./node_modules/moment/locale/da.js",
      "./da.js": "./node_modules/moment/locale/da.js",
      "./de": "./node_modules/moment/locale/de.js",
      "./de-at": "./node_modules/moment/locale/de-at.js",
      "./de-at.js": "./node_modules/moment/locale/de-at.js",
      "./de-ch": "./node_modules/moment/locale/de-ch.js",
      "./de-ch.js": "./node_modules/moment/locale/de-ch.js",
      "./de.js": "./node_modules/moment/locale/de.js",
      "./dv": "./node_modules/moment/locale/dv.js",
      "./dv.js": "./node_modules/moment/locale/dv.js",
      "./el": "./node_modules/moment/locale/el.js",
      "./el.js": "./node_modules/moment/locale/el.js",
      "./en-au": "./node_modules/moment/locale/en-au.js",
      "./en-au.js": "./node_modules/moment/locale/en-au.js",
      "./en-ca": "./node_modules/moment/locale/en-ca.js",
      "./en-ca.js": "./node_modules/moment/locale/en-ca.js",
      "./en-gb": "./node_modules/moment/locale/en-gb.js",
      "./en-gb.js": "./node_modules/moment/locale/en-gb.js",
      "./en-ie": "./node_modules/moment/locale/en-ie.js",
      "./en-ie.js": "./node_modules/moment/locale/en-ie.js",
      "./en-il": "./node_modules/moment/locale/en-il.js",
      "./en-il.js": "./node_modules/moment/locale/en-il.js",
      "./en-in": "./node_modules/moment/locale/en-in.js",
      "./en-in.js": "./node_modules/moment/locale/en-in.js",
      "./en-nz": "./node_modules/moment/locale/en-nz.js",
      "./en-nz.js": "./node_modules/moment/locale/en-nz.js",
      "./en-sg": "./node_modules/moment/locale/en-sg.js",
      "./en-sg.js": "./node_modules/moment/locale/en-sg.js",
      "./eo": "./node_modules/moment/locale/eo.js",
      "./eo.js": "./node_modules/moment/locale/eo.js",
      "./es": "./node_modules/moment/locale/es.js",
      "./es-do": "./node_modules/moment/locale/es-do.js",
      "./es-do.js": "./node_modules/moment/locale/es-do.js",
      "./es-mx": "./node_modules/moment/locale/es-mx.js",
      "./es-mx.js": "./node_modules/moment/locale/es-mx.js",
      "./es-us": "./node_modules/moment/locale/es-us.js",
      "./es-us.js": "./node_modules/moment/locale/es-us.js",
      "./es.js": "./node_modules/moment/locale/es.js",
      "./et": "./node_modules/moment/locale/et.js",
      "./et.js": "./node_modules/moment/locale/et.js",
      "./eu": "./node_modules/moment/locale/eu.js",
      "./eu.js": "./node_modules/moment/locale/eu.js",
      "./fa": "./node_modules/moment/locale/fa.js",
      "./fa.js": "./node_modules/moment/locale/fa.js",
      "./fi": "./node_modules/moment/locale/fi.js",
      "./fi.js": "./node_modules/moment/locale/fi.js",
      "./fil": "./node_modules/moment/locale/fil.js",
      "./fil.js": "./node_modules/moment/locale/fil.js",
      "./fo": "./node_modules/moment/locale/fo.js",
      "./fo.js": "./node_modules/moment/locale/fo.js",
      "./fr": "./node_modules/moment/locale/fr.js",
      "./fr-ca": "./node_modules/moment/locale/fr-ca.js",
      "./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
      "./fr-ch": "./node_modules/moment/locale/fr-ch.js",
      "./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
      "./fr.js": "./node_modules/moment/locale/fr.js",
      "./fy": "./node_modules/moment/locale/fy.js",
      "./fy.js": "./node_modules/moment/locale/fy.js",
      "./ga": "./node_modules/moment/locale/ga.js",
      "./ga.js": "./node_modules/moment/locale/ga.js",
      "./gd": "./node_modules/moment/locale/gd.js",
      "./gd.js": "./node_modules/moment/locale/gd.js",
      "./gl": "./node_modules/moment/locale/gl.js",
      "./gl.js": "./node_modules/moment/locale/gl.js",
      "./gom-deva": "./node_modules/moment/locale/gom-deva.js",
      "./gom-deva.js": "./node_modules/moment/locale/gom-deva.js",
      "./gom-latn": "./node_modules/moment/locale/gom-latn.js",
      "./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
      "./gu": "./node_modules/moment/locale/gu.js",
      "./gu.js": "./node_modules/moment/locale/gu.js",
      "./he": "./node_modules/moment/locale/he.js",
      "./he.js": "./node_modules/moment/locale/he.js",
      "./hi": "./node_modules/moment/locale/hi.js",
      "./hi.js": "./node_modules/moment/locale/hi.js",
      "./hr": "./node_modules/moment/locale/hr.js",
      "./hr.js": "./node_modules/moment/locale/hr.js",
      "./hu": "./node_modules/moment/locale/hu.js",
      "./hu.js": "./node_modules/moment/locale/hu.js",
      "./hy-am": "./node_modules/moment/locale/hy-am.js",
      "./hy-am.js": "./node_modules/moment/locale/hy-am.js",
      "./id": "./node_modules/moment/locale/id.js",
      "./id.js": "./node_modules/moment/locale/id.js",
      "./is": "./node_modules/moment/locale/is.js",
      "./is.js": "./node_modules/moment/locale/is.js",
      "./it": "./node_modules/moment/locale/it.js",
      "./it-ch": "./node_modules/moment/locale/it-ch.js",
      "./it-ch.js": "./node_modules/moment/locale/it-ch.js",
      "./it.js": "./node_modules/moment/locale/it.js",
      "./ja": "./node_modules/moment/locale/ja.js",
      "./ja.js": "./node_modules/moment/locale/ja.js",
      "./jv": "./node_modules/moment/locale/jv.js",
      "./jv.js": "./node_modules/moment/locale/jv.js",
      "./ka": "./node_modules/moment/locale/ka.js",
      "./ka.js": "./node_modules/moment/locale/ka.js",
      "./kk": "./node_modules/moment/locale/kk.js",
      "./kk.js": "./node_modules/moment/locale/kk.js",
      "./km": "./node_modules/moment/locale/km.js",
      "./km.js": "./node_modules/moment/locale/km.js",
      "./kn": "./node_modules/moment/locale/kn.js",
      "./kn.js": "./node_modules/moment/locale/kn.js",
      "./ko": "./node_modules/moment/locale/ko.js",
      "./ko.js": "./node_modules/moment/locale/ko.js",
      "./ku": "./node_modules/moment/locale/ku.js",
      "./ku.js": "./node_modules/moment/locale/ku.js",
      "./ky": "./node_modules/moment/locale/ky.js",
      "./ky.js": "./node_modules/moment/locale/ky.js",
      "./lb": "./node_modules/moment/locale/lb.js",
      "./lb.js": "./node_modules/moment/locale/lb.js",
      "./lo": "./node_modules/moment/locale/lo.js",
      "./lo.js": "./node_modules/moment/locale/lo.js",
      "./lt": "./node_modules/moment/locale/lt.js",
      "./lt.js": "./node_modules/moment/locale/lt.js",
      "./lv": "./node_modules/moment/locale/lv.js",
      "./lv.js": "./node_modules/moment/locale/lv.js",
      "./me": "./node_modules/moment/locale/me.js",
      "./me.js": "./node_modules/moment/locale/me.js",
      "./mi": "./node_modules/moment/locale/mi.js",
      "./mi.js": "./node_modules/moment/locale/mi.js",
      "./mk": "./node_modules/moment/locale/mk.js",
      "./mk.js": "./node_modules/moment/locale/mk.js",
      "./ml": "./node_modules/moment/locale/ml.js",
      "./ml.js": "./node_modules/moment/locale/ml.js",
      "./mn": "./node_modules/moment/locale/mn.js",
      "./mn.js": "./node_modules/moment/locale/mn.js",
      "./mr": "./node_modules/moment/locale/mr.js",
      "./mr.js": "./node_modules/moment/locale/mr.js",
      "./ms": "./node_modules/moment/locale/ms.js",
      "./ms-my": "./node_modules/moment/locale/ms-my.js",
      "./ms-my.js": "./node_modules/moment/locale/ms-my.js",
      "./ms.js": "./node_modules/moment/locale/ms.js",
      "./mt": "./node_modules/moment/locale/mt.js",
      "./mt.js": "./node_modules/moment/locale/mt.js",
      "./my": "./node_modules/moment/locale/my.js",
      "./my.js": "./node_modules/moment/locale/my.js",
      "./nb": "./node_modules/moment/locale/nb.js",
      "./nb.js": "./node_modules/moment/locale/nb.js",
      "./ne": "./node_modules/moment/locale/ne.js",
      "./ne.js": "./node_modules/moment/locale/ne.js",
      "./nl": "./node_modules/moment/locale/nl.js",
      "./nl-be": "./node_modules/moment/locale/nl-be.js",
      "./nl-be.js": "./node_modules/moment/locale/nl-be.js",
      "./nl.js": "./node_modules/moment/locale/nl.js",
      "./nn": "./node_modules/moment/locale/nn.js",
      "./nn.js": "./node_modules/moment/locale/nn.js",
      "./oc-lnc": "./node_modules/moment/locale/oc-lnc.js",
      "./oc-lnc.js": "./node_modules/moment/locale/oc-lnc.js",
      "./pa-in": "./node_modules/moment/locale/pa-in.js",
      "./pa-in.js": "./node_modules/moment/locale/pa-in.js",
      "./pl": "./node_modules/moment/locale/pl.js",
      "./pl.js": "./node_modules/moment/locale/pl.js",
      "./pt": "./node_modules/moment/locale/pt.js",
      "./pt-br": "./node_modules/moment/locale/pt-br.js",
      "./pt-br.js": "./node_modules/moment/locale/pt-br.js",
      "./pt.js": "./node_modules/moment/locale/pt.js",
      "./ro": "./node_modules/moment/locale/ro.js",
      "./ro.js": "./node_modules/moment/locale/ro.js",
      "./ru": "./node_modules/moment/locale/ru.js",
      "./ru.js": "./node_modules/moment/locale/ru.js",
      "./sd": "./node_modules/moment/locale/sd.js",
      "./sd.js": "./node_modules/moment/locale/sd.js",
      "./se": "./node_modules/moment/locale/se.js",
      "./se.js": "./node_modules/moment/locale/se.js",
      "./si": "./node_modules/moment/locale/si.js",
      "./si.js": "./node_modules/moment/locale/si.js",
      "./sk": "./node_modules/moment/locale/sk.js",
      "./sk.js": "./node_modules/moment/locale/sk.js",
      "./sl": "./node_modules/moment/locale/sl.js",
      "./sl.js": "./node_modules/moment/locale/sl.js",
      "./sq": "./node_modules/moment/locale/sq.js",
      "./sq.js": "./node_modules/moment/locale/sq.js",
      "./sr": "./node_modules/moment/locale/sr.js",
      "./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
      "./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
      "./sr.js": "./node_modules/moment/locale/sr.js",
      "./ss": "./node_modules/moment/locale/ss.js",
      "./ss.js": "./node_modules/moment/locale/ss.js",
      "./sv": "./node_modules/moment/locale/sv.js",
      "./sv.js": "./node_modules/moment/locale/sv.js",
      "./sw": "./node_modules/moment/locale/sw.js",
      "./sw.js": "./node_modules/moment/locale/sw.js",
      "./ta": "./node_modules/moment/locale/ta.js",
      "./ta.js": "./node_modules/moment/locale/ta.js",
      "./te": "./node_modules/moment/locale/te.js",
      "./te.js": "./node_modules/moment/locale/te.js",
      "./tet": "./node_modules/moment/locale/tet.js",
      "./tet.js": "./node_modules/moment/locale/tet.js",
      "./tg": "./node_modules/moment/locale/tg.js",
      "./tg.js": "./node_modules/moment/locale/tg.js",
      "./th": "./node_modules/moment/locale/th.js",
      "./th.js": "./node_modules/moment/locale/th.js",
      "./tk": "./node_modules/moment/locale/tk.js",
      "./tk.js": "./node_modules/moment/locale/tk.js",
      "./tl-ph": "./node_modules/moment/locale/tl-ph.js",
      "./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
      "./tlh": "./node_modules/moment/locale/tlh.js",
      "./tlh.js": "./node_modules/moment/locale/tlh.js",
      "./tr": "./node_modules/moment/locale/tr.js",
      "./tr.js": "./node_modules/moment/locale/tr.js",
      "./tzl": "./node_modules/moment/locale/tzl.js",
      "./tzl.js": "./node_modules/moment/locale/tzl.js",
      "./tzm": "./node_modules/moment/locale/tzm.js",
      "./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
      "./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
      "./tzm.js": "./node_modules/moment/locale/tzm.js",
      "./ug-cn": "./node_modules/moment/locale/ug-cn.js",
      "./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
      "./uk": "./node_modules/moment/locale/uk.js",
      "./uk.js": "./node_modules/moment/locale/uk.js",
      "./ur": "./node_modules/moment/locale/ur.js",
      "./ur.js": "./node_modules/moment/locale/ur.js",
      "./uz": "./node_modules/moment/locale/uz.js",
      "./uz-latn": "./node_modules/moment/locale/uz-latn.js",
      "./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
      "./uz.js": "./node_modules/moment/locale/uz.js",
      "./vi": "./node_modules/moment/locale/vi.js",
      "./vi.js": "./node_modules/moment/locale/vi.js",
      "./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
      "./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
      "./yo": "./node_modules/moment/locale/yo.js",
      "./yo.js": "./node_modules/moment/locale/yo.js",
      "./zh-cn": "./node_modules/moment/locale/zh-cn.js",
      "./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
      "./zh-hk": "./node_modules/moment/locale/zh-hk.js",
      "./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
      "./zh-mo": "./node_modules/moment/locale/zh-mo.js",
      "./zh-mo.js": "./node_modules/moment/locale/zh-mo.js",
      "./zh-tw": "./node_modules/moment/locale/zh-tw.js",
      "./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
    };

    function webpackContext(req) {
      var id = webpackContextResolve(req);
      return __webpack_require__(id);
    }

    function webpackContextResolve(req) {
      if (!__webpack_require__.o(map, req)) {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      }

      return map[req];
    }

    webpackContext.keys = function webpackContextKeys() {
      return Object.keys(map);
    };

    webpackContext.resolve = webpackContextResolve;
    module.exports = webpackContext;
    webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
  /*!**************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
    \**************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAppComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-app>\n\n  <app-menu></app-menu>\n  <ion-router-outlet id=\"main\"></ion-router-outlet>\n</ion-app>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/components/fab/fab.component.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/fab/fab.component.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppComponentsFabFabComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n  <ion-fab >\n\n    <ion-fab-button color=\"header\"\n    (click)=\"onClick()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n    \n    \n  </ion-fab>\n\n  \n\n\n  \n\n  \n\n  ";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/components/header/header.component.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/header/header.component.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppComponentsHeaderHeaderComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"header\">\n\n    <ion-buttons slot=\"start\">\n\n      <ion-menu-button \n      menu=\"desp\"></ion-menu-button>\n\n    </ion-buttons>\n\n    <ion-title> {{ titulo }} </ion-title>\n\n    <ion-buttons slot=\"end\">\n\n      <ion-button (click)=\"camara()\"> \n\n        <ion-icon slot=\"icon-only\" name=\"camera\"></ion-icon>\n\n    </ion-button>\n\n    </ion-buttons>\n    \n\n  </ion-toolbar>\n\n  \n</ion-header>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/components/menu/menu.component.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/menu/menu.component.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppComponentsMenuMenuComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-menu side=\"start\" \n  menuId=\"desp\" \n  contentId=\"main\">\n    <ion-header>\n      <ion-toolbar color=\"primary\">\n        \n        <!-- Logo -->\n        <ion-img src=\"/assets/shapes.svg\"></ion-img>\n \n      </ion-toolbar>\n    </ion-header>\n\n    <ion-content\n     class=\"padding\">\n      <ion-list>\n\n        <ion-menu-toggle *ngFor=\"let c of components | async; let id = index\" >\n          \n          <ion-item lines=\"none\"\n          *ngIf=\"c.redirecTo != '/ayuda' && c.redirecTo != '/config'\"\n          [routerLink]=\"c.redirecTo\">\n          \n            <ion-icon slot=\"start\"\n            [name]=\"c.icon\"></ion-icon>\n\n            <ion-label>{{ c.name }}</ion-label>\n\n          </ion-item>\n          \n\n        </ion-menu-toggle>\n\n\n      </ion-list>\n\n      <ion-footer>\n\n        <ion-toolbar>\n\n\n          <ion-list>\n  \n            <ion-menu-toggle\n            *ngFor=\"let c of components | async; let id = index\" >\n            \n              <ion-item lines=\"none\"\n              *ngIf=\"c.redirecTo == '/ayuda' || c.redirecTo == '/config'\"\n              [routerLink]=\"c.redirecTo\">\n                <ion-icon slot=\"start\"\n                [name]=\"c.icon\"></ion-icon>\n                <ion-label>{{ c.name }}</ion-label>\n              </ion-item>\n              \n    \n            </ion-menu-toggle>\n  \n          </ion-list>\n\n        </ion-toolbar>\n        \n      </ion-footer>\n    </ion-content>\n  </ion-menu>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-archivos/popover-archivos.component.html":
  /*!*******************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-archivos/popover-archivos.component.html ***!
    \*******************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppComponentsPopoverArchivosPopoverArchivosComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-list>\n  <ion-item *ngFor=\"let it of opt\"\n  color=\"dark\"\n  lines=\"none\"\n  (click)=\"onClick( it.nombre, it.url )\">\n\n    <!-- <ion-icon slot=\"start\" [name]=\"it.icon\"></ion-icon> -->\n    <ion-label\n    class=\"ion-text-capitalize\">{{ it.nombre }}</ion-label>\n  </ion-item> \n</ion-list>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-options/popover-options.component.html":
  /*!*****************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-options/popover-options.component.html ***!
    \*****************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppComponentsPopoverOptionsPopoverOptionsComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-list>\n  <ion-item *ngFor=\"let it of items; let i = index;\"\n  lines=\"none\"\n  (click)=\"onClick( it.nombre )\">\n\n    <ion-icon slot=\"start\" [name]=\"it.icon\"></ion-icon>\n    <ion-label class=\"ion-text-capitalize\">{{ it.nombre }}</ion-label>\n  </ion-item> \n</ion-list>\n ";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover/popover.component.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover/popover.component.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppComponentsPopoverPopoverComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-list>\n  <ion-item *ngFor=\"let it of items; let i = index;\"\n  lines = \"none\"\n  (click)=\"onClick( it.nombre )\"l>\n\n    <ion-icon slot=\"start\" [name]=\"it.icon\"></ion-icon>\n    <ion-label class=\"ion-text-capitalize\">{{ it.nombre }}</ion-label>\n  </ion-item> \n</ion-list>\n\n";
    /***/
  },

  /***/
  "./src/app/app-routing.module.ts":
  /*!***************************************!*\
    !*** ./src/app/app-routing.module.ts ***!
    \***************************************/

  /*! exports provided: AppRoutingModule */

  /***/
  function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
      return AppRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var routes = [{
      path: '',
      redirectTo: 'inicio',
      pathMatch: 'full'
    }, {
      path: 'inicio',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-inicio-inicio-module */
        "pages-inicio-inicio-module").then(__webpack_require__.bind(null,
        /*! ./pages/inicio/inicio.module */
        "./src/app/pages/inicio/inicio.module.ts")).then(function (m) {
          return m.InicioPageModule;
        });
      }
    }, {
      path: 'events',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-events-events-module */
        "pages-events-events-module").then(__webpack_require__.bind(null,
        /*! ./pages/events/events.module */
        "./src/app/pages/events/events.module.ts")).then(function (m) {
          return m.EventsPageModule;
        });
      }
    }, {
      path: 'materias',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-materias-materias-module */
        "pages-materias-materias-module").then(__webpack_require__.bind(null,
        /*! ./pages/materias/materias.module */
        "./src/app/pages/materias/materias.module.ts")).then(function (m) {
          return m.MateriasPageModule;
        });
      }
    }, {
      path: 'horario-clases',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | pages-horario-clases-horario-clases-module */
        [__webpack_require__.e("common"), __webpack_require__.e("pages-horario-clases-horario-clases-module")]).then(__webpack_require__.bind(null,
        /*! ./pages/horario-clases/horario-clases.module */
        "./src/app/pages/horario-clases/horario-clases.module.ts")).then(function (m) {
          return m.HorarioClasesPageModule;
        });
      }
    }, {
      path: 'config',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-config-config-module */
        "pages-config-config-module").then(__webpack_require__.bind(null,
        /*! ./pages/config/config.module */
        "./src/app/pages/config/config.module.ts")).then(function (m) {
          return m.ConfigPageModule;
        });
      }
    }, {
      path: 'ayuda',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-ayuda-ayuda-module */
        "pages-ayuda-ayuda-module").then(__webpack_require__.bind(null,
        /*! ./pages/ayuda/ayuda.module */
        "./src/app/pages/ayuda/ayuda.module.ts")).then(function (m) {
          return m.AyudaPageModule;
        });
      }
    }, {
      path: 'cuaderno',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-cuaderno-cuaderno-module */
        "pages-cuaderno-cuaderno-module").then(__webpack_require__.bind(null,
        /*! ./pages/cuaderno/cuaderno.module */
        "./src/app/pages/cuaderno/cuaderno.module.ts")).then(function (m) {
          return m.CuadernoPageModule;
        });
      }
    }, {
      path: 'galeria',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | pages-galeria-galeria-module */
        [__webpack_require__.e("default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module~pages-imagen-modal-imagen-mo~3b5b6ad8"), __webpack_require__.e("default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module"), __webpack_require__.e("pages-galeria-galeria-module")]).then(__webpack_require__.bind(null,
        /*! ./pages/galeria/galeria.module */
        "./src/app/pages/galeria/galeria.module.ts")).then(function (m) {
          return m.GaleriaPageModule;
        });
      }
    }, {
      path: 'agg-evento',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-agg-evento-agg-evento-module */
        "pages-agg-evento-agg-evento-module").then(__webpack_require__.bind(null,
        /*! ./pages/agg-evento/agg-evento.module */
        "./src/app/pages/agg-evento/agg-evento.module.ts")).then(function (m) {
          return m.AggEventoPageModule;
        });
      }
    }, {
      path: 'agg-periodo',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-agg-periodo-agg-periodo-module */
        "pages-agg-periodo-agg-periodo-module").then(__webpack_require__.bind(null,
        /*! ./pages/agg-periodo/agg-periodo.module */
        "./src/app/pages/agg-periodo/agg-periodo.module.ts")).then(function (m) {
          return m.AggPeriodoPageModule;
        });
      }
    }, {
      path: 'agg-materia',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-agg-materia-agg-materia-module */
        "pages-agg-materia-agg-materia-module").then(__webpack_require__.bind(null,
        /*! ./pages/agg-materia/agg-materia.module */
        "./src/app/pages/agg-materia/agg-materia.module.ts")).then(function (m) {
          return m.AggMateriaPageModule;
        });
      }
    }, {
      path: 'cuaderno-id/:idC/:idM',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-cuaderno-id-cuaderno-id-module */
        "pages-cuaderno-id-cuaderno-id-module").then(__webpack_require__.bind(null,
        /*! ./pages/cuaderno-id/cuaderno-id.module */
        "./src/app/pages/cuaderno-id/cuaderno-id.module.ts")).then(function (m) {
          return m.CuadernoIdPageModule;
        });
      }
    }, {
      path: 'materia-id/:id',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-materia-id-materia-id-module */
        "pages-materia-id-materia-id-module").then(__webpack_require__.bind(null,
        /*! ./pages/materia-id/materia-id.module */
        "./src/app/pages/materia-id/materia-id.module.ts")).then(function (m) {
          return m.MateriaIdPageModule;
        });
      }
    }, {
      path: 'carpeta-id',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | pages-carpeta-id-carpeta-id-module */
        [__webpack_require__.e("default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module~pages-imagen-modal-imagen-mo~3b5b6ad8"), __webpack_require__.e("default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module"), __webpack_require__.e("pages-carpeta-id-carpeta-id-module")]).then(__webpack_require__.bind(null,
        /*! ./pages/carpeta-id/carpeta-id.module */
        "./src/app/pages/carpeta-id/carpeta-id.module.ts")).then(function (m) {
          return m.CarpetaIdPageModule;
        });
      }
    }, {
      path: 'cal-modal',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-cal-modal-cal-modal-module */
        "common").then(__webpack_require__.bind(null,
        /*! ./pages/cal-modal/cal-modal.module */
        "./src/app/pages/cal-modal/cal-modal.module.ts")).then(function (m) {
          return m.CalModalPageModule;
        });
      }
    }, {
      path: 'info-modal',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-info-modal-info-modal-module */
        "pages-info-modal-info-modal-module").then(__webpack_require__.bind(null,
        /*! ./pages/info-modal/info-modal.module */
        "./src/app/pages/info-modal/info-modal.module.ts")).then(function (m) {
          return m.InfoModalPageModule;
        });
      }
    }, {
      path: 'imagen-modal',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | pages-imagen-modal-imagen-modal-module */
        [__webpack_require__.e("default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module~pages-imagen-modal-imagen-mo~3b5b6ad8"), __webpack_require__.e("pages-imagen-modal-imagen-modal-module")]).then(__webpack_require__.bind(null,
        /*! ./pages/imagen-modal/imagen-modal.module */
        "./src/app/pages/imagen-modal/imagen-modal.module.ts")).then(function (m) {
          return m.ImagenModalPageModule;
        });
      }
    }, {
      path: 'tabs',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-tabs-tabs-module */
        "pages-tabs-tabs-module").then(__webpack_require__.bind(null,
        /*! ./pages/tabs/tabs.module */
        "./src/app/pages/tabs/tabs.module.ts")).then(function (m) {
          return m.TabsPageModule;
        });
      }
    }, {
      path: 'tab1',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-tab1-tab1-module */
        "tab1-tab1-module").then(__webpack_require__.bind(null,
        /*! ./pages/tab1/tab1.module */
        "./src/app/pages/tab1/tab1.module.ts")).then(function (m) {
          return m.Tab1PageModule;
        });
      }
    }, {
      path: 'tabs',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-tabs-tabs-module */
        "pages-tabs-tabs-module").then(__webpack_require__.bind(null,
        /*! ./pages/tabs/tabs.module */
        "./src/app/pages/tabs/tabs.module.ts")).then(function (m) {
          return m.TabsPageModule;
        });
      }
    }, {
      path: 'tab2',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-tab2-tab2-module */
        "tab2-tab2-module").then(__webpack_require__.bind(null,
        /*! ./pages/tab2/tab2.module */
        "./src/app/pages/tab2/tab2.module.ts")).then(function (m) {
          return m.Tab2PageModule;
        });
      }
    }, {
      path: 'tab3',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-tab3-tab3-module */
        "tab3-tab3-module").then(__webpack_require__.bind(null,
        /*! ./pages/tab3/tab3.module */
        "./src/app/pages/tab3/tab3.module.ts")).then(function (m) {
          return m.Tab3PageModule;
        });
      }
    }, {
      path: 'login',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-login-login-module */
        "pages-login-login-module").then(__webpack_require__.bind(null,
        /*! ./pages/login/login.module */
        "./src/app/pages/login/login.module.ts")).then(function (m) {
          return m.LoginPageModule;
        });
      }
    }, {
      path: 'welcome',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-welcome-welcome-module */
        "pages-welcome-welcome-module").then(__webpack_require__.bind(null,
        /*! ./pages/welcome/welcome.module */
        "./src/app/pages/welcome/welcome.module.ts")).then(function (m) {
          return m.WelcomePageModule;
        });
      }
    }, {
      path: 'signup',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | pages-signup-signup-module */
        "pages-signup-signup-module").then(__webpack_require__.bind(null,
        /*! ./pages/signup/signup.module */
        "./src/app/pages/signup/signup.module.ts")).then(function (m) {
          return m.SignupPageModule;
        });
      }
    }];

    var AppRoutingModule = function AppRoutingModule() {
      _classCallCheck(this, AppRoutingModule);
    };

    AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, {
        preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"]
      })],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AppRoutingModule);
    /***/
  },

  /***/
  "./src/app/app.component.scss":
  /*!************************************!*\
    !*** ./src/app/app.component.scss ***!
    \************************************/

  /*! exports provided: default */

  /***/
  function srcAppAppComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/app.component.ts":
  /*!**********************************!*\
    !*** ./src/app/app.component.ts ***!
    \**********************************/

  /*! exports provided: AppComponent */

  /***/
  function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
      return AppComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/splash-screen/ngx */
    "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/status-bar/ngx */
    "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");

    var AppComponent = /*#__PURE__*/function () {
      function AppComponent(platform, splashScreen, statusBar) {
        _classCallCheck(this, AppComponent);

        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.initializeApp();
      }

      _createClass(AppComponent, [{
        key: "initializeApp",
        value: function initializeApp() {
          var _this = this;

          this.platform.ready().then(function () {
            _this.statusBar.styleBlackTranslucent();

            _this.splashScreen.hide();

            _this.checkDarkmode();
          });
        }
      }, {
        key: "checkDarkmode",
        value: function checkDarkmode() {
          var prefersDark = window.matchMedia('(prefers-color-scheme: dark)');

          if (prefersDark.matches) {
            document.body.classList.toggle('dark');
          }
        }
      }]);

      return AppComponent;
    }();

    AppComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"]
      }, {
        type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]
      }];
    };

    AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-root',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./app.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./app.component.scss */
      "./src/app/app.component.scss"))["default"]]
    })], AppComponent);
    /***/
  },

  /***/
  "./src/app/app.module.ts":
  /*!*******************************!*\
    !*** ./src/app/app.module.ts ***!
    \*******************************/

  /*! exports provided: AppModule */

  /***/
  function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppModule", function () {
      return AppModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic-native/splash-screen/ngx */
    "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic-native/status-bar/ngx */
    "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./app-routing.module */
    "./src/app/app-routing.module.ts");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./app.component */
    "./src/app/app.component.ts");
    /* harmony import */


    var _components_components_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./components/components.module */
    "./src/app/components/components.module.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var _ionic_native_sqlite_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @ionic-native/sqlite/ngx */
    "./node_modules/@ionic-native/sqlite/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_sqlite_porter_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! @ionic-native/sqlite-porter/ngx */
    "./node_modules/@ionic-native/sqlite-porter/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_storage__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! @ionic/storage */
    "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
    /* harmony import */


    var _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! @ionic-native/image-picker/ngx */
    "./node_modules/@ionic-native/image-picker/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! @ionic-native/File/ngx */
    "./node_modules/@ionic-native/File/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_media_capture_ngx__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! @ionic-native/media-capture/ngx */
    "./node_modules/@ionic-native/media-capture/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_media_ngx__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! @ionic-native/media/ngx */
    "./node_modules/@ionic-native/media/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_streaming_media_ngx__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
    /*! @ionic-native/streaming-media/ngx */
    "./node_modules/@ionic-native/streaming-media/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
    /*! @ionic-native/photo-viewer/ngx */
    "./node_modules/@ionic-native/photo-viewer/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_Camera_ngx__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
    /*! @ionic-native/Camera/ngx */
    "./node_modules/@ionic-native/Camera/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
    /*! @ionic-native/file-path/ngx */
    "./node_modules/@ionic-native/file-path/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
    /*! @ionic-native/file-chooser/ngx */
    "./node_modules/@ionic-native/file-chooser/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(
    /*! @ionic-native/file-opener/ngx */
    "./node_modules/@ionic-native/file-opener/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(
    /*! @ionic-native/ionic-webview/ngx */
    "./node_modules/@ionic-native/ionic-webview/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(
    /*! @ionic-native/social-sharing/ngx */
    "./node_modules/@ionic-native/social-sharing/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var ionic2_calendar__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(
    /*! ionic2-calendar */
    "./node_modules/ionic2-calendar/__ivy_ngcc__/fesm2015/ionic2-calendar.js");
    /* harmony import */


    var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(
    /*! @ionic-native/local-notifications/ngx */
    "./node_modules/@ionic-native/local-notifications/__ivy_ngcc__/ngx/index.js"); //DB 
    //Media 


    var AppModule = function AppModule() {
      _classCallCheck(this, AppModule);
    };

    AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      declarations: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]],
      entryComponents: [],
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"], _components_components_module__WEBPACK_IMPORTED_MODULE_9__["ComponentsModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_10__["HttpClientModule"], _ionic_storage__WEBPACK_IMPORTED_MODULE_13__["IonicStorageModule"]],
      exports: [],
      providers: [_ionic_native_Camera_ngx__WEBPACK_IMPORTED_MODULE_20__["Camera"], _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_24__["WebView"], _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_27__["LocalNotifications"], _ionic_native_social_sharing_ngx__WEBPACK_IMPORTED_MODULE_25__["SocialSharing"], ionic2_calendar__WEBPACK_IMPORTED_MODULE_26__["NgCalendarModule"], _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_22__["FileChooser"], _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_23__["FileOpener"], _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_21__["FilePath"], _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_14__["ImagePicker"], _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_15__["File"], _ionic_native_media_capture_ngx__WEBPACK_IMPORTED_MODULE_16__["MediaCapture"], _ionic_native_media_ngx__WEBPACK_IMPORTED_MODULE_17__["Media"], _ionic_native_streaming_media_ngx__WEBPACK_IMPORTED_MODULE_18__["StreamingMedia"], _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_19__["PhotoViewer"], _ionic_native_sqlite_ngx__WEBPACK_IMPORTED_MODULE_11__["SQLite"], {
        provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"],
        useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"]
      }, _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"], _ionic_native_sqlite_porter_ngx__WEBPACK_IMPORTED_MODULE_12__["SQLitePorter"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"], {
        provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"],
        useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"]
      }],
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
    })], AppModule);
    /***/
  },

  /***/
  "./src/app/components/components.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/components/components.module.ts ***!
    \*************************************************/

  /*! exports provided: ComponentsModule */

  /***/
  function srcAppComponentsComponentsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ComponentsModule", function () {
      return ComponentsModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _header_header_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./header/header.component */
    "./src/app/components/header/header.component.ts");
    /* harmony import */


    var _menu_menu_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./menu/menu.component */
    "./src/app/components/menu/menu.component.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _fab_fab_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./fab/fab.component */
    "./src/app/components/fab/fab.component.ts");
    /* harmony import */


    var _popover_popover_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./popover/popover.component */
    "./src/app/components/popover/popover.component.ts");
    /* harmony import */


    var src_app_pipes_fecha_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! src/app/pipes/fecha.pipe */
    "./src/app/pipes/fecha.pipe.ts");
    /* harmony import */


    var _pipes_dia_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ../pipes/dia.pipe */
    "./src/app/pipes/dia.pipe.ts");
    /* harmony import */


    var _pipes_hora_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ../pipes/hora.pipe */
    "./src/app/pipes/hora.pipe.ts");
    /* harmony import */


    var _popover_options_popover_options_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./popover-options/popover-options.component */
    "./src/app/components/popover-options/popover-options.component.ts");
    /* harmony import */


    var _pipes_filtro_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ../pipes/filtro.pipe */
    "./src/app/pipes/filtro.pipe.ts");
    /* harmony import */


    var _popover_archivos_popover_archivos_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! ./popover-archivos/popover-archivos.component */
    "./src/app/components/popover-archivos/popover-archivos.component.ts");

    var ComponentsModule = function ComponentsModule() {
      _classCallCheck(this, ComponentsModule);
    };

    ComponentsModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      declarations: [_header_header_component__WEBPACK_IMPORTED_MODULE_4__["HeaderComponent"], _menu_menu_component__WEBPACK_IMPORTED_MODULE_5__["MenuComponent"], _fab_fab_component__WEBPACK_IMPORTED_MODULE_7__["FabComponent"], _popover_popover_component__WEBPACK_IMPORTED_MODULE_8__["PopoverComponent"], _popover_options_popover_options_component__WEBPACK_IMPORTED_MODULE_12__["PopoverOptionsComponent"], _popover_archivos_popover_archivos_component__WEBPACK_IMPORTED_MODULE_14__["PopoverArchivosComponent"], src_app_pipes_fecha_pipe__WEBPACK_IMPORTED_MODULE_9__["FechaPipe"], _pipes_dia_pipe__WEBPACK_IMPORTED_MODULE_10__["DiaPipe"], _pipes_hora_pipe__WEBPACK_IMPORTED_MODULE_11__["HoraPipe"], _pipes_filtro_pipe__WEBPACK_IMPORTED_MODULE_13__["FiltroPipe"]],
      exports: [_header_header_component__WEBPACK_IMPORTED_MODULE_4__["HeaderComponent"], _menu_menu_component__WEBPACK_IMPORTED_MODULE_5__["MenuComponent"], _fab_fab_component__WEBPACK_IMPORTED_MODULE_7__["FabComponent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"], _popover_options_popover_options_component__WEBPACK_IMPORTED_MODULE_12__["PopoverOptionsComponent"], _popover_archivos_popover_archivos_component__WEBPACK_IMPORTED_MODULE_14__["PopoverArchivosComponent"], src_app_pipes_fecha_pipe__WEBPACK_IMPORTED_MODULE_9__["FechaPipe"], _pipes_dia_pipe__WEBPACK_IMPORTED_MODULE_10__["DiaPipe"], _pipes_hora_pipe__WEBPACK_IMPORTED_MODULE_11__["HoraPipe"], _pipes_filtro_pipe__WEBPACK_IMPORTED_MODULE_13__["FiltroPipe"]],
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"]]
    })], ComponentsModule);
    /***/
  },

  /***/
  "./src/app/components/fab/fab.component.scss":
  /*!***************************************************!*\
    !*** ./src/app/components/fab/fab.component.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppComponentsFabFabComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-fab-button[data-desc] {\n  position: relative;\n}\n\nion-fab-button[data-desc]::after {\n  position: absolute;\n  content: attr(data-desc);\n  z-index: 1;\n  right: 55px;\n  bottom: 4px;\n  background-color: var(--ion-color-primary);\n  padding: 9px;\n  border-radius: 15px;\n  color: white;\n  box-shadow: 0 3px 5px -1px rgba(0, 0, 0, 0.2), 0 6px 10px 0 rgba(0, 0, 0, 0.14), 0 1px 18px 0 rgba(0, 0, 0, 0.12);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9mYWIvQzpcXFVzZXJzXFxpc2FjXFxEZXNrdG9wXFxpb25pY1xccGFudGFWZXJzaW9uRWR1L3NyY1xcYXBwXFxjb21wb25lbnRzXFxmYWJcXGZhYi5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvY29tcG9uZW50cy9mYWIvZmFiLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7QUNDSjs7QURFRTtFQUNFLGtCQUFBO0VBQ0Esd0JBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSwwQ0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxpSEFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9mYWIvZmFiLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWZhYi1idXR0b25bZGF0YS1kZXNjXSB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1mYWItYnV0dG9uW2RhdGEtZGVzY106OmFmdGVyIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGNvbnRlbnQ6IGF0dHIoZGF0YS1kZXNjKTtcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICByaWdodDogNTVweDtcclxuICAgIGJvdHRvbTogNHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgcGFkZGluZzogOXB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJveC1zaGFkb3c6IDAgM3B4IDVweCAtMXB4IHJnYmEoMCwwLDAsMC4yKSwgMCA2cHggMTBweCAwIHJnYmEoMCwwLDAsMC4xNCksIDAgMXB4IDE4cHggMCByZ2JhKDAsMCwwLDAuMTIpO1xyXG4gIH0iLCJpb24tZmFiLWJ1dHRvbltkYXRhLWRlc2NdIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG5pb24tZmFiLWJ1dHRvbltkYXRhLWRlc2NdOjphZnRlciB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgY29udGVudDogYXR0cihkYXRhLWRlc2MpO1xuICB6LWluZGV4OiAxO1xuICByaWdodDogNTVweDtcbiAgYm90dG9tOiA0cHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgcGFkZGluZzogOXB4O1xuICBib3JkZXItcmFkaXVzOiAxNXB4O1xuICBjb2xvcjogd2hpdGU7XG4gIGJveC1zaGFkb3c6IDAgM3B4IDVweCAtMXB4IHJnYmEoMCwgMCwgMCwgMC4yKSwgMCA2cHggMTBweCAwIHJnYmEoMCwgMCwgMCwgMC4xNCksIDAgMXB4IDE4cHggMCByZ2JhKDAsIDAsIDAsIDAuMTIpO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/components/fab/fab.component.ts":
  /*!*************************************************!*\
    !*** ./src/app/components/fab/fab.component.ts ***!
    \*************************************************/

  /*! exports provided: FabComponent */

  /***/
  function srcAppComponentsFabFabComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FabComponent", function () {
      return FabComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var FabComponent = /*#__PURE__*/function () {
      function FabComponent(nav) {
        _classCallCheck(this, FabComponent);

        this.nav = nav;
        this.opts = '';
        this.idMateria = '0';
      }

      _createClass(FabComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          if (this.pageEvent) {
            this.opts = '/agg-evento';
          }

          if (this.pageInicio) {
            this.opts = 'Insertar opciones inicio';
          }

          if (this.pageHorario) {
            this.opts = '/agg-materia';
          }

          if (this.pageCuaderno) {
            this.opts = '/agg-materia';
          }

          if (this.pageMaterias) {
            this.opts = 'Insertar opciones materias';
          }

          if (this.pageGaleria) {
            this.opts = 'Insertar opciones Galeria';
          }

          if (this.pageCuadernoId) {
            this.opts = 'Insertar opciones cuaderno';
          }

          if (this.pageMateriaId) {
            this.opts = '/cuaderno-id/0/' + this.idMateria;
          }

          return;
        }
      }, {
        key: "onClick",
        value: function onClick() {
          this.nav.navigateForward(this.opts);
        }
      }]);

      return FabComponent;
    }();

    FabComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], FabComponent.prototype, "pageInicio", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], FabComponent.prototype, "pageEvent", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], FabComponent.prototype, "pageMaterias", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], FabComponent.prototype, "pageCuaderno", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], FabComponent.prototype, "pageHorario", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], FabComponent.prototype, "pageGaleria", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], FabComponent.prototype, "pageMateriaId", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], FabComponent.prototype, "pageCuadernoId", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], FabComponent.prototype, "idMateria", void 0);
    FabComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-fab',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./fab.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/components/fab/fab.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./fab.component.scss */
      "./src/app/components/fab/fab.component.scss"))["default"]]
    })], FabComponent);
    /***/
  },

  /***/
  "./src/app/components/header/header.component.scss":
  /*!*********************************************************!*\
    !*** ./src/app/components/header/header.component.scss ***!
    \*********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppComponentsHeaderHeaderComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/components/header/header.component.ts":
  /*!*******************************************************!*\
    !*** ./src/app/components/header/header.component.ts ***!
    \*******************************************************/

  /*! exports provided: HeaderComponent */

  /***/
  function srcAppComponentsHeaderHeaderComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HeaderComponent", function () {
      return HeaderComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_services_galeria_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/services/galeria.service */
    "./src/app/services/galeria.service.ts");

    var Media_folder_name = 'Media';
    var Local_location_name = "file:///storage/emulated/0/";

    var HeaderComponent = /*#__PURE__*/function () {
      function HeaderComponent(menuCtrl, galeriaSvc) {
        _classCallCheck(this, HeaderComponent);

        this.menuCtrl = menuCtrl;
        this.galeriaSvc = galeriaSvc;
        this.files = [];
        this.url = [];
      }

      _createClass(HeaderComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "toggleMenu",
        value: function toggleMenu() {
          this.menuCtrl.toggle();
        }
      }, {
        key: "camara",
        value: function camara() {
          var _this2 = this;

          this.galeriaSvc.getCamera().subscribe(function (boo) {
            if (boo) {
              _this2.galeriaSvc.captureImage();
            }
          });
        }
      }]);

      return HeaderComponent;
    }();

    HeaderComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]
      }, {
        type: src_app_services_galeria_service__WEBPACK_IMPORTED_MODULE_3__["GaleriaService"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], HeaderComponent.prototype, "titulo", void 0);
    HeaderComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-header',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./header.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/components/header/header.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./header.component.scss */
      "./src/app/components/header/header.component.scss"))["default"]]
    })], HeaderComponent);
    /***/
  },

  /***/
  "./src/app/components/menu/menu.component.scss":
  /*!*****************************************************!*\
    !*** ./src/app/components/menu/menu.component.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppComponentsMenuMenuComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvbWVudS9tZW51LmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/components/menu/menu.component.ts":
  /*!***************************************************!*\
    !*** ./src/app/components/menu/menu.component.ts ***!
    \***************************************************/

  /*! exports provided: MenuComponent */

  /***/
  function srcAppComponentsMenuMenuComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MenuComponent", function () {
      return MenuComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_services_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/data.service */
    "./src/app/services/data.service.ts");

    var MenuComponent = /*#__PURE__*/function () {
      function MenuComponent(dataService) {
        _classCallCheck(this, MenuComponent);

        this.dataService = dataService;
      }

      _createClass(MenuComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.components = this.dataService.getData();
        }
      }]);

      return MenuComponent;
    }();

    MenuComponent.ctorParameters = function () {
      return [{
        type: src_app_services_data_service__WEBPACK_IMPORTED_MODULE_2__["DataService"]
      }];
    };

    MenuComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-menu',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./menu.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/components/menu/menu.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./menu.component.scss */
      "./src/app/components/menu/menu.component.scss"))["default"]]
    })], MenuComponent);
    /***/
  },

  /***/
  "./src/app/components/popover-archivos/popover-archivos.component.scss":
  /*!*****************************************************************************!*\
    !*** ./src/app/components/popover-archivos/popover-archivos.component.scss ***!
    \*****************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppComponentsPopoverArchivosPopoverArchivosComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvcG9wb3Zlci1hcmNoaXZvcy9wb3BvdmVyLWFyY2hpdm9zLmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/components/popover-archivos/popover-archivos.component.ts":
  /*!***************************************************************************!*\
    !*** ./src/app/components/popover-archivos/popover-archivos.component.ts ***!
    \***************************************************************************/

  /*! exports provided: PopoverArchivosComponent */

  /***/
  function srcAppComponentsPopoverArchivosPopoverArchivosComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PopoverArchivosComponent", function () {
      return PopoverArchivosComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var PopoverArchivosComponent = /*#__PURE__*/function () {
      function PopoverArchivosComponent(popoverCtrl) {
        _classCallCheck(this, PopoverArchivosComponent);

        this.popoverCtrl = popoverCtrl;
        this.opt = [{
          nombre: 'Cargar Archivos'
        }];
        this.item2 = '';
        this.url2 = '';
      }

      _createClass(PopoverArchivosComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onClick",
        value: function onClick(item, url) {
          if (item.length > 0) {
            this.item2 = item, this.url2 = url;
          }

          this.popoverCtrl.dismiss({
            item: item,
            url: url
          });
        }
      }]);

      return PopoverArchivosComponent;
    }();

    PopoverArchivosComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], PopoverArchivosComponent.prototype, "opt", void 0);
    PopoverArchivosComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-popover-archivos',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./popover-archivos.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-archivos/popover-archivos.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./popover-archivos.component.scss */
      "./src/app/components/popover-archivos/popover-archivos.component.scss"))["default"]]
    })], PopoverArchivosComponent);
    /***/
  },

  /***/
  "./src/app/components/popover-options/popover-options.component.scss":
  /*!***************************************************************************!*\
    !*** ./src/app/components/popover-options/popover-options.component.scss ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppComponentsPopoverOptionsPopoverOptionsComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvcG9wb3Zlci1vcHRpb25zL3BvcG92ZXItb3B0aW9ucy5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/components/popover-options/popover-options.component.ts":
  /*!*************************************************************************!*\
    !*** ./src/app/components/popover-options/popover-options.component.ts ***!
    \*************************************************************************/

  /*! exports provided: PopoverOptionsComponent */

  /***/
  function srcAppComponentsPopoverOptionsPopoverOptionsComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PopoverOptionsComponent", function () {
      return PopoverOptionsComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var PopoverOptionsComponent = /*#__PURE__*/function () {
      function PopoverOptionsComponent(popoverCtrl) {
        _classCallCheck(this, PopoverOptionsComponent);

        this.popoverCtrl = popoverCtrl;
        this.items = [{
          nombre: 'Crear carpeta',
          icon: 'folder-open'
        }];
      }

      _createClass(PopoverOptionsComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onClick",
        value: function onClick(item) {
          this.popoverCtrl.dismiss({
            item: item
          });
        }
      }]);

      return PopoverOptionsComponent;
    }();

    PopoverOptionsComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]
      }];
    };

    PopoverOptionsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-popover-options',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./popover-options.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover-options/popover-options.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./popover-options.component.scss */
      "./src/app/components/popover-options/popover-options.component.scss"))["default"]]
    })], PopoverOptionsComponent);
    /***/
  },

  /***/
  "./src/app/components/popover/popover.component.scss":
  /*!***********************************************************!*\
    !*** ./src/app/components/popover/popover.component.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppComponentsPopoverPopoverComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvcG9wb3Zlci9wb3BvdmVyLmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/components/popover/popover.component.ts":
  /*!*********************************************************!*\
    !*** ./src/app/components/popover/popover.component.ts ***!
    \*********************************************************/

  /*! exports provided: PopoverComponent */

  /***/
  function srcAppComponentsPopoverPopoverComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PopoverComponent", function () {
      return PopoverComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var PopoverComponent = /*#__PURE__*/function () {
      function PopoverComponent(popoverCtrl) {
        _classCallCheck(this, PopoverComponent);

        this.popoverCtrl = popoverCtrl;
        this.opts = {};
        this.items = [{
          nombre: 'editar',
          icon: 'create'
        }, {
          nombre: 'eliminar',
          icon: 'trash'
        }];
      }

      _createClass(PopoverComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onClick",
        value: function onClick(valor) {
          this.popoverCtrl.dismiss({
            item: valor
          });
        }
      }]);

      return PopoverComponent;
    }();

    PopoverComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]
      }];
    };

    PopoverComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-popover',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./popover.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/components/popover/popover.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./popover.component.scss */
      "./src/app/components/popover/popover.component.scss"))["default"]]
    })], PopoverComponent);
    /***/
  },

  /***/
  "./src/app/pipes/dia.pipe.ts":
  /*!***********************************!*\
    !*** ./src/app/pipes/dia.pipe.ts ***!
    \***********************************/

  /*! exports provided: DiaPipe */

  /***/
  function srcAppPipesDiaPipeTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DiaPipe", function () {
      return DiaPipe;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);

    var DiaPipe = /*#__PURE__*/function () {
      function DiaPipe() {
        _classCallCheck(this, DiaPipe);
      }

      _createClass(DiaPipe, [{
        key: "transform",
        value: function transform(value, valid) {
          if (valid === 'lunes' || valid === 'martes' || valid === 'miércoles' || valid === 'jueves' || valid === 'viernes' || valid === 'sábado' || valid === 'domingo') {
            return valid;
          } else {
            value = new Date(value);
            var fecha = value.toISOString();
            var dia = fecha.toString();
            return moment__WEBPACK_IMPORTED_MODULE_2__(dia).format('DD MMMM YYYY');
          }
        }
      }]);

      return DiaPipe;
    }();

    DiaPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
      name: 'dia'
    })], DiaPipe);
    /***/
  },

  /***/
  "./src/app/pipes/fecha.pipe.ts":
  /*!*************************************!*\
    !*** ./src/app/pipes/fecha.pipe.ts ***!
    \*************************************/

  /*! exports provided: FechaPipe */

  /***/
  function srcAppPipesFechaPipeTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FechaPipe", function () {
      return FechaPipe;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);

    var FechaPipe = /*#__PURE__*/function () {
      function FechaPipe() {
        _classCallCheck(this, FechaPipe);
      }

      _createClass(FechaPipe, [{
        key: "transform",
        value: function transform(value) {
          value = new Date(value);
          var fecha = value.toISOString();
          var dia = fecha.toString();
          return moment__WEBPACK_IMPORTED_MODULE_2__(dia).format('DD MMMM YYYY, hh:mm a');
        }
      }]);

      return FechaPipe;
    }();

    FechaPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
      name: 'fecha'
    })], FechaPipe);
    /***/
  },

  /***/
  "./src/app/pipes/filtro.pipe.ts":
  /*!**************************************!*\
    !*** ./src/app/pipes/filtro.pipe.ts ***!
    \**************************************/

  /*! exports provided: FiltroPipe */

  /***/
  function srcAppPipesFiltroPipeTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FiltroPipe", function () {
      return FiltroPipe;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var FiltroPipe = /*#__PURE__*/function () {
      function FiltroPipe() {
        _classCallCheck(this, FiltroPipe);
      }

      _createClass(FiltroPipe, [{
        key: "transform",
        value: function transform(arreglo, texto, columna) {
          if (texto === '') {
            return arreglo;
          }

          texto = texto.toLowerCase();
          return arreglo.filter(function (item) {
            return item[columna].toLowerCase().includes(texto);
          });
        }
      }]);

      return FiltroPipe;
    }();

    FiltroPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
      name: 'filtro'
    })], FiltroPipe);
    /***/
  },

  /***/
  "./src/app/pipes/hora.pipe.ts":
  /*!************************************!*\
    !*** ./src/app/pipes/hora.pipe.ts ***!
    \************************************/

  /*! exports provided: HoraPipe */

  /***/
  function srcAppPipesHoraPipeTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HoraPipe", function () {
      return HoraPipe;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);

    var HoraPipe = /*#__PURE__*/function () {
      function HoraPipe() {
        _classCallCheck(this, HoraPipe);
      }

      _createClass(HoraPipe, [{
        key: "transform",
        value: function transform(value) {
          value = new Date(value);
          var fecha = value.toISOString();
          var dia = fecha.toString();
          return moment__WEBPACK_IMPORTED_MODULE_2__(dia).format('hh:mm a');
        }
      }]);

      return HoraPipe;
    }();

    HoraPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
      name: 'hora'
    })], HoraPipe);
    /***/
  },

  /***/
  "./src/app/services/data.service.ts":
  /*!******************************************!*\
    !*** ./src/app/services/data.service.ts ***!
    \******************************************/

  /*! exports provided: DataService */

  /***/
  function srcAppServicesDataServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DataService", function () {
      return DataService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");

    var DataService = /*#__PURE__*/function () {
      function DataService(http) {
        _classCallCheck(this, DataService);

        this.http = http;
      }

      _createClass(DataService, [{
        key: "getData",
        value: function getData() {
          return this.http.get('/assets/data/menu.json');
        }
      }, {
        key: "getYoutube",
        value: function getYoutube() {
          return this.http.get('https://www.googleapis.com/youtube/v3/search?part=snippet&q=clases%de%20ingles&type=video&key=AIzaSyA6DilEzJe0GK-Y_5la5uYQjiDt41-zM74&');
        }
      }]);

      return DataService;
    }();

    DataService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    DataService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], DataService);
    /***/
  },

  /***/
  "./src/app/services/db.service.ts":
  /*!****************************************!*\
    !*** ./src/app/services/db.service.ts ***!
    \****************************************/

  /*! exports provided: DatabaseService */

  /***/
  function srcAppServicesDbServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DatabaseService", function () {
      return DatabaseService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_sqlite_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/sqlite/ngx */
    "./node_modules/@ionic-native/sqlite/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_sqlite_porter_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic-native/sqlite-porter/ngx */
    "./node_modules/@ionic-native/sqlite-porter/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");

    var DatabaseService = /*#__PURE__*/function () {
      function DatabaseService(platform, sqlitePorter, sqlite, http) {
        var _this3 = this;

        _classCallCheck(this, DatabaseService);

        this.platform = platform;
        this.sqlitePorter = sqlitePorter;
        this.sqlite = sqlite;
        this.http = http;
        this.dbReady = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"](false);
        this.usuario = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.materias = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.evento = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.periodo = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.cuaderno = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.fotos = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.carpeta = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.archivos = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.finanzas = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.id_materia = 0;
        this.id_evento = 0;
        this.id_cuaderno = 0;
        this.id_carpeta = 0; //Abrir BDD      

        this.platform.ready().then(function () {
          _this3.sqlite.create({
            name: 'ionic.db',
            location: 'default'
          }).then(function (db) {
            _this3.database = db;

            _this3.seedDatabase();
          });
        });
      }

      _createClass(DatabaseService, [{
        key: "seedDatabase",
        value: function seedDatabase() {
          var _this4 = this;

          this.http.get('/assets/data/base.sql', {
            responseType: 'text'
          }).subscribe(function (sql) {
            _this4.sqlitePorter.importSqlToDb(_this4.database, sql).then(function (_) {
              _this4.cargarUsuario();

              _this4.cargarMaterias();

              _this4.cargarEvento();

              _this4.cargarPeriodo();

              _this4.cargarCuaderno();

              _this4.cargarFotos();

              _this4.cargarCarpeta();

              _this4.cargarArchivo();

              _this4.cargarFinanzas();

              _this4.dbReady.next(true);
            })["catch"](function (e) {
              return console.error(e);
            });
          });
        }
      }, {
        key: "getDatabaseState",
        value: function getDatabaseState() {
          return this.dbReady.asObservable();
        }
      }, {
        key: "getUser",
        value: function getUser() {
          return this.usuario.asObservable();
        }
      }, {
        key: "getMaterias",
        value: function getMaterias() {
          return this.materias.asObservable();
        }
      }, {
        key: "getEvento",
        value: function getEvento() {
          return this.evento.asObservable();
        }
      }, {
        key: "getPeriodo",
        value: function getPeriodo() {
          return this.periodo.asObservable();
        }
      }, {
        key: "getCuaderno",
        value: function getCuaderno() {
          return this.cuaderno.asObservable();
        }
      }, {
        key: "getFotos",
        value: function getFotos() {
          return this.fotos.asObservable();
        }
      }, {
        key: "getCarpeta",
        value: function getCarpeta() {
          return this.carpeta.asObservable();
        }
      }, {
        key: "getArchivo",
        value: function getArchivo() {
          return this.archivos.asObservable();
        }
      }, {
        key: "getGasto",
        value: function getGasto() {
          return this.finanzas.asObservable();
        } // CRUD Usuario   

      }, {
        key: "cargarUsuario",
        value: function cargarUsuario() {
          var _this5 = this;

          return this.database.executeSql('SELECT * FROM usuario', []).then(function (data) {
            var usuarios = [];

            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                usuarios.push({
                  id: data.rows.item(i).id,
                  nombre: data.rows.item(i).nombre,
                  apellido: data.rows.item(i).apellido,
                  avatar: data.rows.item(i).avatar
                });
              }
            }

            _this5.usuario.next(usuarios);
          });
        }
      }, {
        key: "agregarUsuario",
        value: function agregarUsuario(name, apellido, avatar) {
          var _this6 = this;

          var data = [name, apellido, avatar];
          return this.database.executeSql('INSERT INTO usuario (nombre, apellido, avatar) VALUES (?, ?, ?)', data).then(function (data) {
            _this6.cargarUsuario();
          });
        }
      }, {
        key: "getUsuario",
        value: function getUsuario(id) {
          return this.database.executeSql('SELECT * FROM usuario WHERE id = ?', [id]).then(function (data) {
            return {
              id: data.rows.item(0).id,
              nombre: data.rows.item(0).nombre,
              apellido: data.rows.item(0).apellido,
              avatar: data.rows.item(0).avatar
            };
          });
        }
      }, {
        key: "eliminarUsuario",
        value: function eliminarUsuario(id) {
          var _this7 = this;

          return this.database.executeSql('DELETE FROM usuario WHERE id = ?', [id]).then(function (_) {
            _this7.cargarUsuario();

            _this7.cargarMaterias();
          });
        }
      }, {
        key: "updateUsuario",
        value: function updateUsuario(dev) {
          var _this8 = this;

          var data = [dev.nombre, dev.apellido, dev.avatar];
          return this.database.executeSql("UPDATE usuario SET nombre = ?, apellido = ?, avatar = ? WHERE id = ".concat(dev.id), data).then(function (data) {
            _this8.cargarUsuario();
          });
        } // CRUD Materias

      }, {
        key: "cargarMaterias",
        value: function cargarMaterias() {
          var _this9 = this;

          var query = 'SELECT materias.nombre, materias.id, id_usuario, id_periodo, id_evento, usuario.nombre AS usuario FROM materias JOIN usuario ON usuario.id = materias.id_usuario';
          return this.database.executeSql(query, []).then(function (data) {
            var materias = [];

            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                materias.push({
                  nombre: data.rows.item(i).nombre,
                  id: data.rows.item(i).id,
                  id_usuario: data.rows.item(i).id_usuario,
                  id_periodo: data.rows.item(i).id_periodo,
                  id_evento: data.rows.item(i).id_evento,
                  usuario: data.rows.item(i).usuario
                });
                _this9.id_materia = data.rows.item(i).id;
              }
            }

            _this9.materias.next(materias);

            return _this9.id_materia;
          });
        }
      }, {
        key: "cargarMateriaId",
        value: function cargarMateriaId(id) {
          return this.database.executeSql('SELECT * FROM materias WHERE id = ?', [id]).then(function (data) {
            return {
              id: data.rows.item(0).id,
              nombre: data.rows.item(0).nombre,
              id_usuario: data.rows.item(0).id_usuario,
              id_periodo: data.rows.item(0).id_periodo,
              id_evento: data.rows.item(0).id_evento
            };
          });
        }
      }, {
        key: "cargarMateriaPeriodo",
        value: function cargarMateriaPeriodo(id) {
          return this.database.executeSql('SELECT * FROM materias WHERE id_periodo = ?', [id]).then(function (data) {
            var materias = [];

            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                materias.push({
                  id: data.rows.item(i).id,
                  nombre: data.rows.item(i).nombre,
                  id_usuario: data.rows.item(i).id_usuario,
                  id_periodo: data.rows.item(i).id_periodo,
                  id_evento: data.rows.item(i).id_evento
                });
              }
            }

            return materias;
          });
        }
      }, {
        key: "cargarMateriaEvento",
        value: function cargarMateriaEvento(id) {
          return this.database.executeSql('SELECT * FROM materias WHERE id_evento = ?', [id]).then(function (data) {
            var materias = [];

            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                materias.push({
                  id: data.rows.item(i).id,
                  nombre: data.rows.item(i).nombre,
                  id_usuario: data.rows.item(i).id_usuario,
                  id_periodo: data.rows.item(i).id_periodo,
                  id_evento: data.rows.item(i).id_evento
                });
              }
            }

            return materias;
          });
        }
      }, {
        key: "agregarMaterias",
        value: function agregarMaterias(nombre, id_usuario, id_periodo, id_evento) {
          var _this10 = this;

          var data = [nombre, id_usuario, id_periodo, id_evento];
          return this.database.executeSql('INSERT INTO materias (nombre, id_usuario, id_periodo, id_evento) VALUES (?, ?, ?, ?)', data).then(function (_) {
            _this10.cargarMaterias();

            return _this10.id_materia + 1;
          });
        }
      }, {
        key: "updateMaterias",
        value: function updateMaterias(id, nombre, id_periodo) {
          var _this11 = this;

          var data = [nombre, id_periodo];
          return this.database.executeSql("UPDATE materias SET nombre = ?, id_periodo = ? WHERE id = ".concat(id), data).then(function (_) {
            _this11.cargarMaterias();
          });
        }
      }, {
        key: "eliminarMateriasPeriodo",
        value: function eliminarMateriasPeriodo(id) {
          var _this12 = this;

          return this.database.executeSql('DELETE FROM materias WHERE id_periodo = ?', [id]).then(function (_) {
            _this12.cargarMaterias();
          });
        }
      }, {
        key: "eliminarMaterias",
        value: function eliminarMaterias(id) {
          var _this13 = this;

          return this.database.executeSql('DELETE FROM materias WHERE id = ?', [id]).then(function (_) {
            _this13.cargarMaterias();
          });
        } //CRUD EVENTO 

      }, {
        key: "cargarEvento",
        value: function cargarEvento() {
          var _this14 = this;

          var query = 'SELECT evento.id, evento.nombre, evento.dia, evento.inicio, evento.fin, evento.tipo, evento.comentario, evento.id_usuario FROM evento JOIN usuario ON usuario.id = evento.id_usuario';
          return this.database.executeSql(query, []).then(function (data) {
            var evento = [];

            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                evento.push({
                  id: data.rows.item(i).id,
                  nombre: data.rows.item(i).nombre,
                  dia: data.rows.item(i).dia,
                  inicio: data.rows.item(i).inicio,
                  fin: data.rows.item(i).fin,
                  tipo: data.rows.item(i).tipo,
                  comentario: data.rows.item(i).comentario,
                  id_usuario: data.rows.item(i).id_usuario
                });
                _this14.id_evento = data.rows.item(i).id;
              }
            }

            _this14.evento.next(evento);

            return _this14.id_evento;
          });
        }
      }, {
        key: "agregarEvento",
        value: function agregarEvento(nombre, dia, inicio, fin, tipo, comentario, id_usuario) {
          var _this15 = this;

          var data = [nombre, dia, inicio, fin, tipo, comentario, id_usuario];
          return this.database.executeSql('INSERT INTO evento (nombre, dia, inicio, fin, tipo, comentario, id_usuario) VALUES (?,?,?,?,?,?,?)', data).then(function (data) {
            _this15.cargarEvento();

            return _this15.id_evento + 1;
          });
        }
      }, {
        key: "cargarEventoId",
        value: function cargarEventoId(id) {
          return this.database.executeSql('SELECT * FROM evento WHERE id = ?', [id]).then(function (data) {
            return {
              id: data.rows.item(0).id,
              nombre: data.rows.item(0).nombre,
              dia: data.rows.item(0).dia,
              inicio: data.rows.item(0).inicio,
              fin: data.rows.item(0).fin,
              tipo: data.rows.item(0).tipo,
              comentario: data.rows.item(0).comentario,
              id_usuario: data.rows.item(0).id_usuario
            };
          });
        }
      }, {
        key: "eliminarEvento",
        value: function eliminarEvento(id) {
          var _this16 = this;

          return this.database.executeSql('DELETE FROM evento WHERE id = ?', [id]).then(function (_) {
            _this16.cargarEvento();
          });
        }
      }, {
        key: "updateEvento",
        value: function updateEvento(id, nombre, dia, inicio, fin, tipo, comentario) {
          var _this17 = this;

          var data = [nombre, dia, inicio, fin, tipo, comentario];
          return this.database.executeSql("UPDATE evento SET nombre = ?, dia = ?, inicio = ?, fin = ?, tipo = ?, comentario = ? WHERE id = ".concat(id), data).then(function (data) {
            _this17.cargarEvento();
          });
        } // CRUD Periodo

      }, {
        key: "cargarPeriodo",
        value: function cargarPeriodo() {
          var _this18 = this;

          var query = 'SELECT periodo.id, periodo.nombre, periodo.id_usuario, usuario.nombre AS usuario FROM periodo JOIN usuario ON usuario.id = periodo.id_usuario';
          return this.database.executeSql(query, []).then(function (data) {
            var periodo = [];

            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                periodo.push({
                  id: data.rows.item(i).id,
                  nombre: data.rows.item(i).nombre,
                  id_usuario: data.rows.item(i).id_usuario,
                  usuario: data.rows.item(i).usuario
                });
              }
            }

            _this18.periodo.next(periodo);
          });
        }
      }, {
        key: "cargarPeriodoId",
        value: function cargarPeriodoId(id) {
          return this.database.executeSql('SELECT * FROM periodo WHERE id = ?', [id]).then(function (data) {
            return {
              id: data.rows.item(0).id,
              nombre: data.rows.item(0).nombre,
              id_usuario: data.rows.item(0).id_usuario
            };
          });
        }
      }, {
        key: "agregarPeriodo",
        value: function agregarPeriodo(nombre, id_usuario) {
          var _this19 = this;

          var data = [nombre, id_usuario];
          return this.database.executeSql('INSERT INTO periodo (nombre, id_usuario) VALUES (?,?)', data).then(function (_) {
            _this19.cargarPeriodo();
          });
        }
      }, {
        key: "updatePeriodo",
        value: function updatePeriodo(id, nombre) {
          var _this20 = this;

          var data = [nombre];
          return this.database.executeSql("UPDATE periodo SET nombre = ? WHERE id = ".concat(id), data).then(function (_) {
            _this20.cargarPeriodo();
          });
        }
      }, {
        key: "eliminarPeriodo",
        value: function eliminarPeriodo(id) {
          var _this21 = this;

          return this.database.executeSql('DELETE FROM periodo WHERE id = ?', [id]).then(function (_) {
            _this21.cargarPeriodo();
          });
        } // CRUD Cuaderno

      }, {
        key: "cargarCuaderno",
        value: function cargarCuaderno() {
          var _this22 = this;

          var query = 'SELECT * FROM cuaderno';
          return this.database.executeSql(query, []).then(function (data) {
            var cuaderno = [];

            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                cuaderno.push({
                  id: data.rows.item(i).id,
                  titulo: data.rows.item(i).titulo,
                  fecha_crea: data.rows.item(i).fecha_crea,
                  fecha_mod: data.rows.item(i).fecha_mod,
                  contenido: data.rows.item(i).contenido,
                  id_usuario: data.rows.item(i).id_usuario,
                  id_materia: data.rows.item(i).id_materia
                });
                _this22.id_cuaderno = data.rows.item(i).id;
              }
            }

            _this22.cuaderno.next(cuaderno);
          });
        }
      }, {
        key: "cargarCuadernoId",
        value: function cargarCuadernoId(id) {
          return this.database.executeSql('SELECT * FROM cuaderno WHERE id = ?', [id]).then(function (data) {
            return {
              id: data.rows.item(0).id,
              titulo: data.rows.item(0).titulo,
              fecha_crea: data.rows.item(0).fecha_crea,
              fecha_mod: data.rows.item(0).fecha_mod,
              contenido: data.rows.item(0).contenido,
              id_usuario: data.rows.item(0).id_usuario,
              id_materia: data.rows.item(0).id_materia
            };
          });
        }
      }, {
        key: "agregarCuaderno",
        value: function agregarCuaderno(titulo, fecha_crea, fecha_mod, contenido, id_materia) {
          var _this23 = this;

          var data = [titulo, fecha_crea, fecha_mod, contenido, id_materia];
          return this.database.executeSql('INSERT INTO cuaderno (titulo, fecha_crea, fecha_mod, contenido, id_materia) values (?,?,?,?,?)', data).then(function (_) {
            _this23.cargarCuaderno();

            return _this23.id_cuaderno + 1;
          });
        }
      }, {
        key: "updateCuaderno",
        value: function updateCuaderno(id, titulo, fecha_crea, fecha_mod, contenido, id_materia) {
          var _this24 = this;

          var data = [titulo, fecha_crea, fecha_mod, contenido, id_materia];
          return this.database.executeSql("UPDATE cuaderno SET titulo = ?, fecha_crea = ?, fecha_mod = ?, contenido = ?, id_materia = ? WHERE id = ".concat(id), data).then(function (_) {
            _this24.cargarCuaderno();
          });
        }
      }, {
        key: "eliminarCuaderno",
        value: function eliminarCuaderno(id) {
          var _this25 = this;

          return this.database.executeSql('DELETE FROM cuaderno WHERE id = ?', [id]).then(function (_) {
            _this25.cargarCuaderno();
          });
        }
      }, {
        key: "eliminarCuadernoPeriodo",
        value: function eliminarCuadernoPeriodo(id) {
          var _this26 = this;

          return this.database.executeSql('DELETE FROM cuaderno WHERE id_materia = ?', [id]).then(function (_) {
            _this26.cargarCuaderno();
          });
        } // CRUD Fotos

      }, {
        key: "cargarFotos",
        value: function cargarFotos() {
          var _this27 = this;

          var query = 'SELECT * FROM fotos';
          return this.database.executeSql(query, []).then(function (data) {
            var fotos = [];

            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                fotos.push({
                  id: data.rows.item(i).id,
                  nombre: data.rows.item(i).nombre,
                  url: data.rows.item(i).url,
                  fecha: data.rows.item(i).fecha,
                  favorito: data.rows.item(i).favorito,
                  id_carpeta: data.rows.item(i).id_carpeta,
                  id_usuario: data.rows.item(i).id_usuario
                });
              }
            }

            _this27.fotos.next(fotos);
          });
        }
      }, {
        key: "agregarFotos",
        value: function agregarFotos(nombre, url, fecha, id_carpeta, id_usuario) {
          var _this28 = this;

          var data = [nombre, url, fecha, 0, id_carpeta, id_usuario];
          return this.database.executeSql('INSERT INTO fotos (nombre, url, fecha, favorito, id_carpeta, id_usuario) values (?,?,?,?,?,?)', data).then(function (_) {
            _this28.cargarFotos();
          });
        }
      }, {
        key: "eliminarFotos",
        value: function eliminarFotos(id) {
          var _this29 = this;

          return this.database.executeSql('DELETE FROM fotos WHERE id = ?', [id]).then(function (_) {
            _this29.cargarFotos();
          });
        }
      }, {
        key: "updateFotosFav",
        value: function updateFotosFav(id, fav) {
          var _this30 = this;

          var data = [fav];
          return this.database.executeSql("UPDATE fotos SET favorito = ? WHERE id = ".concat(id), data).then(function (data) {
            _this30.cargarFotos();
          });
        }
      }, {
        key: "eliminarFotosCarpeta",
        value: function eliminarFotosCarpeta(id) {
          var _this31 = this;

          return this.database.executeSql('DELETE FROM fotos WHERE id_carpeta = ?', [id]).then(function (_) {
            _this31.cargarFotos();
          });
        } // CRUD Carpeta 

      }, {
        key: "cargarCarpeta",
        value: function cargarCarpeta() {
          var _this32 = this;

          var query = 'SELECT * FROM carpeta';
          return this.database.executeSql(query, []).then(function (data) {
            var carpetas = [];

            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                carpetas.push({
                  id: data.rows.item(i).id,
                  nombre: data.rows.item(i).nombre,
                  id_usuario: data.rows.item(i).id_usuario,
                  id_materia: data.rows.item(i).id_materia
                });
                _this32.id_carpeta = data.rows.item(i).id;
              }
            }

            _this32.carpeta.next(carpetas);
          });
        }
      }, {
        key: "cargarCarpetaId",
        value: function cargarCarpetaId(id) {
          return this.database.executeSql('SELECT * FROM carpeta WHERE id = ?', [id]).then(function (data) {
            return {
              id: data.rows.item(0).id,
              nombre: data.rows.item(0).nombre,
              id_usuario: data.rows.item(0).id_usuario,
              id_materia: data.rows.item(0).id_materia
            };
          });
        }
      }, {
        key: "agregarCarpeta",
        value: function agregarCarpeta(nombre, id_usuario, id_materia) {
          var _this33 = this;

          var data = [nombre, id_usuario, id_materia];
          return this.database.executeSql('INSERT INTO carpeta (nombre, id_usuario, id_materia) VALUES (?,?,?)', data).then(function (_) {
            _this33.cargarCarpeta();

            return _this33.id_carpeta + 1;
          });
        }
      }, {
        key: "agregarCarpetaPreder",
        value: function agregarCarpetaPreder() {
          var _this34 = this;

          var id = 1;
          var nombre = 'Otros';
          var data = [id, nombre];
          return this.database.executeSql("INSERT INTO carpeta (id, nombre) VALUES (?,?)", data).then(function (_) {
            _this34.cargarCarpeta();
          });
        }
      }, {
        key: "eliminarCarpeta",
        value: function eliminarCarpeta(id) {
          var _this35 = this;

          return this.database.executeSql('DELETE FROM carpeta WHERE id = ?', [id]).then(function (_) {
            _this35.cargarCarpeta();
          });
        }
      }, {
        key: "updateCarpeta",
        value: function updateCarpeta(id, nombre) {
          var _this36 = this;

          var data = [nombre];
          return this.database.executeSql("UPDATE carpeta SET nombre = ? WHERE id_materia = ".concat(id), data).then(function (_) {
            _this36.cargarCarpeta();
          });
        }
      }, {
        key: "updateCarpetaLibre",
        value: function updateCarpetaLibre(id, nombre) {
          var _this37 = this;

          var data = [nombre];
          return this.database.executeSql("UPDATE carpeta SET nombre = ? WHERE id = ".concat(id), data).then(function (_) {
            _this37.cargarCarpeta();
          });
        } // CRUD Archivos 

      }, {
        key: "cargarArchivo",
        value: function cargarArchivo() {
          var _this38 = this;

          var query = 'SELECT * FROM archivos';
          return this.database.executeSql(query, []).then(function (data) {
            var archivos = [];

            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                archivos.push({
                  id: data.rows.item(i).id,
                  nombre: data.rows.item(i).nombre,
                  url: data.rows.item(i).url,
                  id_usuario: data.rows.item(i).id_usuario,
                  id_cuaderno: data.rows.item(i).id_cuaderno
                });
              }
            }

            _this38.archivos.next(archivos);
          });
        }
      }, {
        key: "agregarArchivos",
        value: function agregarArchivos(url, nombre, id_usuario, id_cuaderno) {
          var _this39 = this;

          var data = [url, nombre, id_usuario, id_cuaderno];
          return this.database.executeSql('INSERT INTO archivos (url, nombre, id_usuario, id_cuaderno) VALUES (?,?,?,?)', data).then(function (_) {
            _this39.cargarArchivo();
          });
        }
      }, {
        key: "cargarArchivosCuaderno",
        value: function cargarArchivosCuaderno(id) {
          return this.database.executeSql('SELECT * FROM archivos WHERE id_cuaderno = ?', [id]).then(function (data) {
            var archivos = [];

            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                archivos.push({
                  nombre: data.rows.item(i).nombre,
                  url: data.rows.item(i).url
                });
              }
            }

            return archivos;
          });
        }
      }, {
        key: "eliminarArchivoCuaderno",
        value: function eliminarArchivoCuaderno(id) {
          var _this40 = this;

          return this.database.executeSql('DELETE FROM archivos WHERE id_cuaderno = ?', [id]).then(function (_) {
            _this40.cargarArchivo();
          });
        } // CRUD Finanzas

      }, {
        key: "cargarFinanzas",
        value: function cargarFinanzas() {
          var _this41 = this;

          var query = 'SELECT * FROM finanzas';
          return this.database.executeSql(query, []).then(function (data) {
            var finanzas = [];

            if (data.rows.length > 0) {
              for (var i = 0; i < data.rows.length; i++) {
                finanzas.push({
                  id: data.rows.item(i).id,
                  gasto: data.rows.item(i).gasto,
                  tipo_gasto: data.rows.item(i).tipo_gasto,
                  descripcion: data.rows.item(i).descripcion,
                  fecha: data.rows.item(i).fecha,
                  icono: data.rows.item(i).icono,
                  id_usuario: data.rows.item(i).id_usuario
                });
              }
            }

            _this41.finanzas.next(finanzas);
          });
        }
      }, {
        key: "cargarFinanzasId",
        value: function cargarFinanzasId(id) {
          // return this.database.executeSql('SELECT * FROM finanzas WHERE id = ?', [id])
          return this.database.executeSql('SELECT * FROM finanzas WHERE id = ?'[id]).then(function (data) {
            return {
              id: data.rows.item(0).id,
              gasto: data.rows.item(0).gasto,
              tipo_gasto: data.rows.item(0).tipo_gasto,
              descripcion: data.rows.item(0).descripcion,
              fecha: data.rows.item(0).fecha,
              icono: data.rows.item(0).icono,
              id_usuario: data.rows.item(0).id_usuario
            };
          });
        }
      }, {
        key: "agregarGasto",
        value: function agregarGasto(gasto, tipo_gasto, descripcion, fecha, icono, id_usuario) {
          var _this42 = this;

          var data = [gasto, tipo_gasto, descripcion, fecha, icono, id_usuario];
          return this.database.executeSql('INSERT INTO finanzas (gasto, tipo_gasto, descripcion, fecha,icono ,id_usuario) VALUES (?,?,?,?,?,?)', data).then(function (_) {
            _this42.cargarFinanzas();
          });
        }
      }, {
        key: "eliminarGasto",
        value: function eliminarGasto(id) {
          var _this43 = this;

          return this.database.executeSql('DELETE FROM finanzas WHERE id = ?', [id]).then(function (_) {
            _this43.cargarFinanzas();
          });
        }
      }]);

      return DatabaseService;
    }();

    DatabaseService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"]
      }, {
        type: _ionic_native_sqlite_porter_ngx__WEBPACK_IMPORTED_MODULE_5__["SQLitePorter"]
      }, {
        type: _ionic_native_sqlite_ngx__WEBPACK_IMPORTED_MODULE_2__["SQLite"]
      }, {
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"]
      }];
    };

    DatabaseService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], DatabaseService);
    /***/
  },

  /***/
  "./src/app/services/galeria.service.ts":
  /*!*********************************************!*\
    !*** ./src/app/services/galeria.service.ts ***!
    \*********************************************/

  /*! exports provided: GaleriaService */

  /***/
  function srcAppServicesGaleriaServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GaleriaService", function () {
      return GaleriaService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_media_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/media/ngx */
    "./node_modules/@ionic-native/media/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_media_capture_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/media-capture/ngx */
    "./node_modules/@ionic-native/media-capture/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic-native/File/ngx */
    "./node_modules/@ionic-native/File/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _db_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./db.service */
    "./src/app/services/db.service.ts");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);

    var Media_folder_name = 'Myapp';
    var Local_location_name = "file:///storage/emulated/0/";
    var Media_folder_name_Galeria = 'Galeria';
    var Local_location_name_Galeria = "file:///storage/emulated/0/Myapp/";

    var GaleriaService = /*#__PURE__*/function () {
      function GaleriaService(file, media, mediaCapture, plt, db, alert) {
        var _this44 = this;

        _classCallCheck(this, GaleriaService);

        this.file = file;
        this.media = media;
        this.mediaCapture = mediaCapture;
        this.plt = plt;
        this.db = db;
        this.alert = alert;
        this.fileReady = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"](false);
        this.fecha = new Date();
        this.files = [];
        this.url_img = new rxjs__WEBPACK_IMPORTED_MODULE_6__["BehaviorSubject"]([]);
        this.materias = [];
        this.eventos = [];
        this.carpeta = [];
        this.foto = {
          nombre: '',
          url: '',
          fecha: this.fecha,
          id_usuario: 1,
          id_carpeta: 0
        };
        this.Materia = {
          id_materia: 0,
          dia: '',
          inicio: '',
          fin: ''
        };
        this.plt.ready().then(function () {
          // Crear carpeta 
          // Raiz 
          var path = _this44.file.dataDirectory;

          _this44.file.checkDir(path, Media_folder_name_Galeria).then(function () {
            _this44.cargarArchivos();
          }, function (err) {
            _this44.file.createDir(path, Media_folder_name_Galeria, false);
          }); // LOCAL 
          // MyApp


          var path2 = Local_location_name;

          _this44.file.checkDir(path2, Media_folder_name).then(function () {
            _this44.cargarArchivos();
          }, function (err) {
            _this44.file.createDir(path2, Media_folder_name, false);
          }); // Galeria


          var path3 = Local_location_name_Galeria;

          _this44.file.checkDir(path3, Media_folder_name_Galeria).then(function () {}, function (err) {
            _this44.file.createDir(path3, Media_folder_name_Galeria, false);
          });

          _this44.fileReady.next(true);
        });
      }

      _createClass(GaleriaService, [{
        key: "getCamera",
        value: function getCamera() {
          return this.fileReady.asObservable();
        }
      }, {
        key: "guardarFoto",
        value: function guardarFoto(id) {
          this.foto.id_carpeta = id;
          this.db.agregarFotos(this.foto.nombre, this.foto.url, this.foto.fecha, this.foto.id_carpeta, this.foto.id_usuario);
        }
      }, {
        key: "cargarArchivos",
        value: function cargarArchivos() {
          var _this45 = this;

          this.file.listDir(this.file.dataDirectory, Media_folder_name_Galeria).then(function (data) {
            if (data.length > 0) {
              _this45.files = data;
            }
          }, function (err) {
            return console.log('error al cargar archivos', err);
          });
        }
      }, {
        key: "captureImage",
        value: function captureImage() {
          var _this46 = this;

          this.mediaCapture.captureImage({
            limit: 1
          }).then(function (data) {
            _this46.cargarMateria(data[0].fullPath, data);
          }, function (err) {
            return console.log(err);
          });
        }
      }, {
        key: "copyFileToLocalDir",
        value: function copyFileToLocalDir(fullPath, data, id) {
          var _this47 = this;

          var myPath = fullPath;

          if (fullPath.indexOf('file://') < 0) {
            myPath = 'file://' + fullPath;
          }

          var ext = myPath.split('.').pop();
          var d = Date.now();
          var newName = "".concat(d, ".").concat(ext);
          var name = myPath.substr(myPath.lastIndexOf('/') + 1);
          var copyFrom = myPath.substr(0, myPath.lastIndexOf('/') + 1);
          var copyToLocal = Local_location_name_Galeria + Media_folder_name_Galeria;
          var copyToNative = this.file.dataDirectory + Media_folder_name_Galeria;
          this.file.copyFile(copyFrom, name, copyToLocal, newName).then(function (success) {
            console.log(success);

            _this47.cargarArchivos();
          }, function (err) {
            console.log(err);
          });
          this.file.copyFile(copyFrom, name, copyToNative, newName).then(function (success) {
            _this47.cargarArchivos();

            _this47.full = success;
            _this47.foto.nombre = success.name;
            _this47.foto.url = success.nativeURL;

            _this47.guardarFoto(id);

            _this47.deleteFileLocal(data);
          }, function (err) {
            console.log(err);
          });
        }
      }, {
        key: "openFile",
        value: function openFile(f) {
          if (f.name.indexOf('.wav') > -1) {
            // We need to remove file:/// from the path for the audio plugin to work
            var path = f.nativeURL.replace(/^file:\/\//, '');
            var audioFile = this.media.create(path);
            audioFile.play(); // }else if (f.name.indexOf('.MOV') > -1  || f.name.indexOf('.mp4') > -1){
            // // E.g: Use the Streaming Media plugin to play a video  
            //   this.streamingMedia.playVideo(f.nativeURL);
            // } else if(f.name.indexOf('jpg') > -1){
            //     // E.g: Use the Photoviewer to present an Image
            //     this.photoViewer.show(f.nativeURL, 'MY awesome image');
          }
        }
      }, {
        key: "deleteFile",
        value: function deleteFile(f) {
          var _this48 = this;

          var path = f.nativeURL.substr(0, f.nativeURL.lastIndexOf('/') + 1);
          this.file.removeFile(path, f.name).then(function () {
            _this48.cargarArchivos();
          }, function (err) {
            return console.log('error remove: ', err);
          });
        }
      }, {
        key: "deleteFileGaleria",
        value: function deleteFileGaleria(nombre) {
          var _this49 = this;

          var n = Local_location_name_Galeria + Media_folder_name_Galeria + '/';
          var path = n.substr(0, n.lastIndexOf('/') + 1);
          console.log(path, nombre);
          this.file.removeFile(path, nombre).then(function () {
            _this49.cargarArchivos();
          }, function (err) {
            return console.log('error remove: ', err);
          });
        }
      }, {
        key: "deleteFileRoot",
        value: function deleteFileRoot(f, nombre) {
          var _this50 = this;

          var path = f.substr(0, f.lastIndexOf('/') + 1);
          this.file.removeFile(path, nombre).then(function () {
            console.log(path, nombre);

            _this50.cargarArchivos();
          }, function (err) {
            return console.log('error remove: ', err);
          });
        }
      }, {
        key: "deleteFileLocal",
        value: function deleteFileLocal(f) {
          var _this51 = this;

          var path = f[0].fullPath.substr(0, f[0].fullPath.lastIndexOf('/') + 1);
          this.file.removeFile(path, f[0].name).then(function () {
            _this51.cargarArchivos();
          }, function (err) {
            return console.log('error remove: ', err);
          });
        }
      }, {
        key: "b64",
        value: function b64(fullPath) {
          var myPath = fullPath;

          if (fullPath.indexOf('file://') < 0) {
            myPath = 'file://' + fullPath;
          }

          var imagePath = myPath.substr(0, myPath.lastIndexOf('/') + 1);
          var imageName = myPath.substr(myPath.lastIndexOf('/') + 1);
          return this.file.readAsDataURL(imagePath, imageName);
        }
      }, {
        key: "cargarMateria",
        value: function cargarMateria(fullPath, data) {
          var _this52 = this;

          this.db.getMaterias().subscribe(function (dat) {
            _this52.materias = dat;

            _this52.cargarDB(fullPath, data);
          }).unsubscribe();
        }
      }, {
        key: "cargarDB",
        value: function cargarDB(fullPath, data) {
          var _this53 = this;

          this.db.getEvento().subscribe(function (dat) {
            _this53.eventos = dat;

            _this53.db.getCarpeta().subscribe(function (dat) {
              _this53.carpeta = dat;

              _this53.validarFecha(fullPath, data);
            }).unsubscribe();
          }).unsubscribe();
        }
      }, {
        key: "validarFecha",
        value: function validarFecha(fullPath, data) {
          var hora = moment__WEBPACK_IMPORTED_MODULE_8__(this.fecha).format("hh:mm a");
          var dia = moment__WEBPACK_IMPORTED_MODULE_8__(this.fecha).format("dddd");

          if (this.eventos.length > 0) {
            var _iterator = _createForOfIteratorHelper(this.eventos),
                _step;

            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                var ev = _step.value;

                var _iterator2 = _createForOfIteratorHelper(this.materias),
                    _step2;

                try {
                  for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                    var mate = _step2.value;

                    if (ev.dia === dia) {
                      if (mate.id_evento === ev.id) {
                        if (moment__WEBPACK_IMPORTED_MODULE_8__(ev.inicio).format("hh:mm a") <= hora && moment__WEBPACK_IMPORTED_MODULE_8__(ev.fin).format("hh:mm a") >= hora) {
                          return this.opts(mate.id, mate.nombre, fullPath, data);
                        }
                      }
                    }
                  }
                } catch (err) {
                  _iterator2.e(err);
                } finally {
                  _iterator2.f();
                }
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }

            this.opts(0, "Otros", fullPath, data);
          } else return this.opts(0, "Otros", fullPath, data);
        }
      }, {
        key: "opts",
        value: function opts(id, carpeta, fullPath, data) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this54 = this;

            var mensaje, input, _iterator3, _step3, car, alert;

            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    mensaje = '';
                    input = {
                      data: []
                    };
                    _iterator3 = _createForOfIteratorHelper(this.carpeta);

                    try {
                      for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                        car = _step3.value;
                        input.data.push({
                          name: car.nombre,
                          type: 'radio',
                          value: car.id,
                          label: car.nombre,
                          checked: carpeta == car.nombre
                        });
                      }
                    } catch (err) {
                      _iterator3.e(err);
                    } finally {
                      _iterator3.f();
                    }

                    if (carpeta !== 'Otros') {
                      mensaje = 'Estas en clases \'' + carpeta + '\'';
                    }

                    _context.next = 7;
                    return this.alert.create({
                      cssClass: 'my-custom-class',
                      header: 'Donde quieres guardar la imagen?',
                      message: mensaje,
                      inputs: input.data,
                      backdropDismiss: false,
                      buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler() {}
                      }, {
                        text: 'Ok',
                        handler: function handler(dat) {
                          if (dat < 0) {
                            _this54.db.agregarCarpeta(carpeta, 1, id).then(function (data) {});

                            _this54.copyFileToLocalDir(fullPath, data, 1);
                          }

                          if (_this54.carpeta.length == 0) {
                            _this54.db.agregarCarpetaPreder().then(function (_) {
                              _this54.copyFileToLocalDir(fullPath, data, 1);
                            });
                          } else {
                            _this54.copyFileToLocalDir(fullPath, data, dat);
                          }
                        }
                      }]
                    });

                  case 7:
                    alert = _context.sent;
                    _context.next = 10;
                    return alert.present();

                  case 10:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }]);

      return GaleriaService;
    }();

    GaleriaService.ctorParameters = function () {
      return [{
        type: _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_5__["File"]
      }, {
        type: _ionic_native_media_ngx__WEBPACK_IMPORTED_MODULE_2__["Media"]
      }, {
        type: _ionic_native_media_capture_ngx__WEBPACK_IMPORTED_MODULE_3__["MediaCapture"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"]
      }, {
        type: _db_service__WEBPACK_IMPORTED_MODULE_7__["DatabaseService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
      }];
    };

    GaleriaService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], GaleriaService);
    /***/
  },

  /***/
  "./src/environments/environment.ts":
  /*!*****************************************!*\
    !*** ./src/environments/environment.ts ***!
    \*****************************************/

  /*! exports provided: environment */

  /***/
  function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "environment", function () {
      return environment;
    }); // This file can be replaced during build by using the `fileReplacements` array.
    // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
    // The list of file replacements can be found in `angular.json`.


    var environment = {
      production: false
    };
    /*
     * For easier debugging in development mode, you can import the following file
     * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
     *
     * This import should be commented out in production mode because it will have a negative impact
     * on performance if an error is thrown.
     */
    // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

    /***/
  },

  /***/
  "./src/main.ts":
  /*!*********************!*\
    !*** ./src/main.ts ***!
    \*********************/

  /*! no exports provided */

  /***/
  function srcMainTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/platform-browser-dynamic */
    "./node_modules/@angular/platform-browser-dynamic/__ivy_ngcc__/fesm2015/platform-browser-dynamic.js");
    /* harmony import */


    var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./app/app.module */
    "./src/app/app.module.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./environments/environment */
    "./src/environments/environment.ts");

    if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
    }

    Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])["catch"](function (err) {
      return console.log(err);
    });
    /***/
  },

  /***/
  0:
  /*!***************************!*\
    !*** multi ./src/main.ts ***!
    \***************************/

  /*! no static exports found */

  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__(
    /*! C:\Users\isac\Desktop\ionic\pantaVersionEdu\src\main.ts */
    "./src/main.ts");
    /***/
  }
}, [[0, "runtime", "vendor"]]]);
//# sourceMappingURL=main-es5.js.map