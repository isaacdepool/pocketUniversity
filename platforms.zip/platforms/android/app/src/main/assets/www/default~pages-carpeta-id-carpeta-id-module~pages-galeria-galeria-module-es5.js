function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/carpeta-id/carpeta-id.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/carpeta-id/carpeta-id.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesCarpetaIdCarpetaIdPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n\n  <ion-toolbar color=\"danger\">\n    \n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"salir()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-buttons slot=\"end\">\n\n      <ion-button *ngIf=\"!fav\" (click)=\"opts( $event )\">\n        <ion-icon slot=\"icon-only\" name=\"ellipsis-vertical-outline\"></ion-icon>\n      </ion-button>\n\n    </ion-buttons>\n\n    <ion-title *ngIf=\"!ver\"></ion-title>\n\n    <div *ngIf=\"!fav && ver && dataFotos.length > 1\" >\n\n      <ion-title class=\"ion-text-capitalize\">{{dataCarpeta.nombre}}</ion-title>\n      <ion-title size=\"small\"\n      color=\"dark\">{{dataFotos.length}} Imagenes</ion-title>\n      \n    </div>\n\n    <div *ngIf=\"!fav && ver && dataFotos.length == 0\" >\n\n      <ion-title >{{dataCarpeta.nombre}}</ion-title>\n      <ion-title size=\"small\"\n      color=\"dark\">Sin Imagenes</ion-title>\n      \n    </div>\n\n    <div *ngIf=\"!fav && ver && dataFotos.length == 1\" >\n\n      <ion-title >{{dataCarpeta.nombre}}</ion-title>\n      <ion-title size=\"small\"\n      color=\"dark\">{{dataFotos.length}} Imagen</ion-title>\n      \n    </div>\n    \n    <ion-title *ngIf=\"fav\" class=\"ion-text-capitalize\">Favoritos</ion-title>\n    <div *ngIf=\"fav && ver && dataFotos.length > 1\" >\n\n      <ion-title size=\"small\"\n      color=\"dark\">{{dataFotos.length}} Imagenes</ion-title>\n      \n    </div>\n\n    <div *ngIf=\"fav && ver && dataFotos.length == 0\" >\n\n      <ion-title size=\"small\"\n      color=\"dark\">Sin Imagenes</ion-title>\n      \n    </div>\n\n    <div *ngIf=\"fav && ver && dataFotos.length == 1\" >\n      \n      <ion-title size=\"small\"\n      color=\"dark\">{{dataFotos.length}} Imagen</ion-title>\n      \n    </div>\n\n    \n\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n\n<ng-container>\n \n    <ion-row >\n\n      <ng-container *ngFor=\"let fotos of dataFotos; let i = index\">\n        \n        <ion-col size=\"6\" class=\"padding\" >\n            \n            <ion-card *ngIf=\"ver\"\n            class=\"card-size\" >\n              <ion-img class=\"img-size\" (click)=\"img($event, fotos.id, i)\" [src]=\"imgUrl[i]\"></ion-img>\n            </ion-card>\n            \n            <ion-skeleton-text *ngIf=\"!ver\"\n            color=\"medium\"\n            class=\"card-size\"\n            animated \n            style=\"width: 100%\"></ion-skeleton-text>\n  \n        </ion-col>\n\n      </ng-container>\n        </ion-row>\n\n</ng-container>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/carpeta-id/carpeta-id.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/pages/carpeta-id/carpeta-id.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesCarpetaIdCarpetaIdPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".card-size {\n  height: 95%;\n  width: 95%;\n}\n\n.padding {\n  height: 200px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY2FycGV0YS1pZC9DOlxcVXNlcnNcXGlzYWNcXERlc2t0b3BcXGlvbmljXFxwYW50YVZlcnNpb25FZHUvc3JjXFxhcHBcXHBhZ2VzXFxjYXJwZXRhLWlkXFxjYXJwZXRhLWlkLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvY2FycGV0YS1pZC9jYXJwZXRhLWlkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxVQUFBO0FDQ0o7O0FERUE7RUFDSSxhQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9jYXJwZXRhLWlkL2NhcnBldGEtaWQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNhcmQtc2l6ZXtcclxuICAgIGhlaWdodDogOTUlO1xyXG4gICAgd2lkdGg6IDk1JTtcclxufVxyXG5cclxuLnBhZGRpbmd7XHJcbiAgICBoZWlnaHQ6IDIwMHB4O1xyXG59XHJcbiIsIi5jYXJkLXNpemUge1xuICBoZWlnaHQ6IDk1JTtcbiAgd2lkdGg6IDk1JTtcbn1cblxuLnBhZGRpbmcge1xuICBoZWlnaHQ6IDIwMHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/carpeta-id/carpeta-id.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/carpeta-id/carpeta-id.page.ts ***!
    \*****************************************************/

  /*! exports provided: CarpetaIdPage */

  /***/
  function srcAppPagesCarpetaIdCarpetaIdPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CarpetaIdPage", function () {
      return CarpetaIdPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/services/db.service */
    "./src/app/services/db.service.ts");
    /* harmony import */


    var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/ionic-webview/ngx */
    "./node_modules/@ionic-native/ionic-webview/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _imagen_modal_imagen_modal_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../imagen-modal/imagen-modal.page */
    "./src/app/pages/imagen-modal/imagen-modal.page.ts");
    /* harmony import */


    var src_app_components_popover_popover_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/components/popover/popover.component */
    "./src/app/components/popover/popover.component.ts");
    /* harmony import */


    var _info_modal_info_modal_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../info-modal/info-modal.page */
    "./src/app/pages/info-modal/info-modal.page.ts");
    /* harmony import */


    var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! src/app/services/alertas.service */
    "./src/app/services/alertas.service.ts");
    /* harmony import */


    var src_app_services_galeria_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! src/app/services/galeria.service */
    "./src/app/services/galeria.service.ts");

    var CarpetaIdPage = /*#__PURE__*/function () {
      function CarpetaIdPage(modalCtrl, db, webView, popoverCtrl, alertCtrl, alertSvc, galeriaSvc, navCtrl) {
        _classCallCheck(this, CarpetaIdPage);

        this.modalCtrl = modalCtrl;
        this.db = db;
        this.webView = webView;
        this.popoverCtrl = popoverCtrl;
        this.alertCtrl = alertCtrl;
        this.alertSvc = alertSvc;
        this.galeriaSvc = galeriaSvc;
        this.navCtrl = navCtrl;
        this.fav = false;
        this.dataFotos = [];
        this.imgUrl = [];
        this.isFavorite = [];
        this.ver = false;
      }

      _createClass(CarpetaIdPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          if (this.fav) {
            this.cargarFavoritos();
          } else this.cargar();
        }
      }, {
        key: "cargar",
        value: function cargar() {
          var _this = this;

          this.db.getDatabaseState().subscribe(function (boo) {
            if (boo) {
              _this.db.cargarCarpetaId(_this.carpetaId).then(function (data) {
                _this.dataCarpeta = data;

                if (data.id_materia > 0) {
                  _this.db.cargarMateriaId(data.id_materia).then(function (data) {
                    _this.dataMateria = data;
                  });
                }
              });

              _this.db.getFotos().subscribe(function (data) {
                var i = 0;
                _this.dataFotos = [];
                _this.imgUrl = [];

                var _iterator = _createForOfIteratorHelper(data),
                    _step;

                try {
                  for (_iterator.s(); !(_step = _iterator.n()).done;) {
                    var fotos = _step.value;

                    if (fotos.id_carpeta == _this.carpetaId) {
                      _this.dataFotos.push(fotos);

                      _this.isFavorite[i] = fotos.favorito;
                      _this.imgUrl[i] = _this.webView.convertFileSrc(fotos.url);
                      i++;
                    }
                  }
                } catch (err) {
                  _iterator.e(err);
                } finally {
                  _iterator.f();
                }
              });
            }

            return setTimeout(function () {
              _this.ver = true;
            }, 200);
          });
        }
      }, {
        key: "cargarFavoritos",
        value: function cargarFavoritos() {
          var _this2 = this;

          this.db.getFotos().subscribe(function (data) {
            var i = 0;
            _this2.dataFotos = [];
            _this2.imgUrl = [];

            var _iterator2 = _createForOfIteratorHelper(data),
                _step2;

            try {
              for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                var fotos = _step2.value;

                if (fotos.favorito == 1) {
                  console.log(data);

                  _this2.dataFotos.push(fotos);

                  _this2.isFavorite[i] = fotos.favorito;
                  _this2.imgUrl[i] = _this2.webView.convertFileSrc(fotos.url);
                  i++;
                }
              }
            } catch (err) {
              _iterator2.e(err);
            } finally {
              _iterator2.f();
            }

            return setTimeout(function () {
              _this2.ver = true;
            }, 200);
          });
        }
      }, {
        key: "img",
        value: function img(event, id, index) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var modal;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.modalCtrl.create({
                      component: _imagen_modal_imagen_modal_page__WEBPACK_IMPORTED_MODULE_5__["ImagenModalPage"],
                      componentProps: {
                        id: id,
                        index: index,
                        dataFotos: this.dataFotos,
                        imgUrl: this.imgUrl,
                        isFavorite: this.isFavorite
                      }
                    });

                  case 2:
                    modal = _context.sent;
                    _context.next = 5;
                    return modal.present();

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "opts",
        value: function opts() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var itemsC, boo, popover, _yield$popover$onDidD, data;

            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    itemsC = {
                      nombre: 'info',
                      icon: 'alert-circle'
                    };
                    boo = true;
                    _context2.next = 4;
                    return this.popoverCtrl.create({
                      component: src_app_components_popover_popover_component__WEBPACK_IMPORTED_MODULE_6__["PopoverComponent"],
                      cssClass: 'css_popover',
                      event: event,
                      mode: 'ios',
                      componentProps: {
                        itemsC: itemsC,
                        boo: boo
                      }
                    });

                  case 4:
                    popover = _context2.sent;
                    _context2.next = 7;
                    return popover.present();

                  case 7:
                    _context2.next = 9;
                    return popover.onDidDismiss();

                  case 9:
                    _yield$popover$onDidD = _context2.sent;
                    data = _yield$popover$onDidD.data;

                    if (data) {
                      if (data.item === 'info') {
                        this.info();
                      }

                      if (data.item === 'editar') {
                        this.editar();
                      }

                      if (data.item === 'eliminar') {
                        this.eliminar();
                      }
                    }

                  case 12:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "info",
        value: function info() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var modal;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.modalCtrl.create({
                      component: _info_modal_info_modal_page__WEBPACK_IMPORTED_MODULE_7__["InfoModalPage"],
                      componentProps: {
                        tipo: 'carpeta',
                        id: this.carpetaId
                      }
                    });

                  case 2:
                    modal = _context3.sent;
                    _context3.next = 5;
                    return modal.present();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "salir",
        value: function salir() {
          this.modalCtrl.dismiss();
        }
      }, {
        key: "editar",
        value: function editar() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var _this3 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    if (!(this.dataCarpeta.id_materia != 0)) {
                      _context4.next = 4;
                      break;
                    }

                    this.restringido();
                    _context4.next = 9;
                    break;

                  case 4:
                    _context4.next = 6;
                    return this.alertCtrl.create({
                      header: 'Editar carpeta',
                      backdropDismiss: false,
                      cssClass: 'alert-css',
                      inputs: [{
                        name: 'nombre',
                        type: 'text',
                        value: this.dataCarpeta.nombre
                      }],
                      buttons: [{
                        text: 'Cancelar',
                        role: 'cancel',
                        handler: function handler(blah) {}
                      }, {
                        text: 'Guardar',
                        handler: function handler(data) {
                          data.nombre = data.nombre.trim();

                          if (data.nombre.length > 0) {
                            _this3.db.updateCarpetaLibre(_this3.carpetaId, data.nombre).then(function (_) {
                              _this3.ionViewWillEnter();

                              _this3.alertSvc.presentToast("Datos actualizados correctamente");
                            });
                          } else _this3.alertSvc.presentToast("Debes ingresar un titulo");
                        }
                      }]
                    });

                  case 6:
                    alert = _context4.sent;
                    _context4.next = 9;
                    return alert.present();

                  case 9:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "restringido",
        value: function restringido() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var _this4 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.alertCtrl.create({
                      header: 'Editar carpeta',
                      message: 'Esta caperta pertece a una materia, si quieres editarla tienes que hacerlo desde \'Editar materia\'',
                      backdropDismiss: false,
                      cssClass: 'alert-css',
                      buttons: [{
                        text: 'Cancelar',
                        role: 'cancel'
                      }, {
                        text: 'Editar materia',
                        handler: function handler() {
                          _this4.modalCtrl.dismiss({
                            idMateria: _this4.dataMateria.id,
                            editarMateria: true
                          });
                        }
                      }]
                    });

                  case 2:
                    alert = _context5.sent;
                    _context5.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "eliminar",
        value: function eliminar() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var _this5 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    _context6.next = 2;
                    return this.alertCtrl.create({
                      header: '¿Quieres eliminar esta carpeta?',
                      message: 'Se eliminaran todas las imagenes',
                      backdropDismiss: false,
                      cssClass: 'alert-css',
                      buttons: [{
                        text: 'Cancelar',
                        role: 'cancel'
                      }, {
                        text: 'Eliminar',
                        handler: function handler() {
                          _this5.db.eliminarCarpeta(_this5.carpetaId);

                          _this5.db.getFotos().subscribe(function (data) {
                            var _iterator3 = _createForOfIteratorHelper(data),
                                _step3;

                            try {
                              for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                                var dat = _step3.value;

                                if (dat.id_carpeta == _this5.carpetaId) {
                                  _this5.galeriaSvc.deleteFileRoot(dat.url, dat.nombre);

                                  _this5.galeriaSvc.deleteFileGaleria(dat.nombre);
                                }
                              }
                            } catch (err) {
                              _iterator3.e(err);
                            } finally {
                              _iterator3.f();
                            }
                          });

                          _this5.db.eliminarFotosCarpeta(_this5.carpetaId);

                          _this5.alertSvc.presentToast('Carpeta eliminada con exito');

                          _this5.modalCtrl.dismiss();
                        }
                      }]
                    });

                  case 2:
                    alert = _context6.sent;
                    _context6.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }]);

      return CarpetaIdPage;
    }();

    CarpetaIdPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_3__["DatabaseService"]
      }, {
        type: _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_4__["WebView"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_8__["AlertasService"]
      }, {
        type: src_app_services_galeria_service__WEBPACK_IMPORTED_MODULE_9__["GaleriaService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CarpetaIdPage.prototype, "carpetaId", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CarpetaIdPage.prototype, "fotoId", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CarpetaIdPage.prototype, "fav", void 0);
    CarpetaIdPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-carpeta-id',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./carpeta-id.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/carpeta-id/carpeta-id.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./carpeta-id.page.scss */
      "./src/app/pages/carpeta-id/carpeta-id.page.scss"))["default"]]
    })], CarpetaIdPage);
    /***/
  }
}]);
//# sourceMappingURL=default~pages-carpeta-id-carpeta-id-module~pages-galeria-galeria-module-es5.js.map