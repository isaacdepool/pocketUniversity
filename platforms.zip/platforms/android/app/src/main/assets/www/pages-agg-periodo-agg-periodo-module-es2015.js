(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-agg-periodo-agg-periodo-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/agg-periodo/agg-periodo.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/agg-periodo/agg-periodo.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n        <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>Agregar nuevo periodo</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  \n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/agg-periodo/agg-periodo-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/agg-periodo/agg-periodo-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: AggPeriodoPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AggPeriodoPageRoutingModule", function() { return AggPeriodoPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _agg_periodo_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./agg-periodo.page */ "./src/app/pages/agg-periodo/agg-periodo.page.ts");




const routes = [
    {
        path: '',
        component: _agg_periodo_page__WEBPACK_IMPORTED_MODULE_3__["AggPeriodoPage"]
    }
];
let AggPeriodoPageRoutingModule = class AggPeriodoPageRoutingModule {
};
AggPeriodoPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AggPeriodoPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/agg-periodo/agg-periodo.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/agg-periodo/agg-periodo.module.ts ***!
  \*********************************************************/
/*! exports provided: AggPeriodoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AggPeriodoPageModule", function() { return AggPeriodoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _agg_periodo_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./agg-periodo-routing.module */ "./src/app/pages/agg-periodo/agg-periodo-routing.module.ts");
/* harmony import */ var _agg_periodo_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./agg-periodo.page */ "./src/app/pages/agg-periodo/agg-periodo.page.ts");







let AggPeriodoPageModule = class AggPeriodoPageModule {
};
AggPeriodoPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _agg_periodo_routing_module__WEBPACK_IMPORTED_MODULE_5__["AggPeriodoPageRoutingModule"]
        ],
        declarations: [_agg_periodo_page__WEBPACK_IMPORTED_MODULE_6__["AggPeriodoPage"]]
    })
], AggPeriodoPageModule);



/***/ }),

/***/ "./src/app/pages/agg-periodo/agg-periodo.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/agg-periodo/agg-periodo.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FnZy1wZXJpb2RvL2FnZy1wZXJpb2RvLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/pages/agg-periodo/agg-periodo.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/agg-periodo/agg-periodo.page.ts ***!
  \*******************************************************/
/*! exports provided: AggPeriodoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AggPeriodoPage", function() { return AggPeriodoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let AggPeriodoPage = class AggPeriodoPage {
    constructor() { }
    ngOnInit() {
    }
};
AggPeriodoPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-agg-periodo',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./agg-periodo.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/agg-periodo/agg-periodo.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./agg-periodo.page.scss */ "./src/app/pages/agg-periodo/agg-periodo.page.scss")).default]
    })
], AggPeriodoPage);



/***/ })

}]);
//# sourceMappingURL=pages-agg-periodo-agg-periodo-module-es2015.js.map