function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-materias-materias-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/materias/materias.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/materias/materias.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMateriasMateriasPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<app-header titulo=\"Periodos academicos\"></app-header>\n\n<ion-content>\n  \n  <ion-list lines=\"none\">\n    <ion-item> \n      <h3>Periodo academico</h3>\n    </ion-item>\n  </ion-list>   \n\n  <ion-button (click)=\"nuevoPeriodo()\" \n  expand=\"block\" \n  fill=\"clear\" \n  shape=\"round\">\n  <ion-icon slot=\"start\" name=\"add\"></ion-icon>\n    Agregar nuevo periodo\n  </ion-button>\n\n  <ion-card *ngFor=\"let per of dataPeriodo, let idx = index\">\n\n    <ion-card-header color=\"tertiary\">\n      <ion-card-subtitle> \n\n        <ion-button fill=\"clear\"\n        (click)=\"onClick( idx )\">\n            <ion-icon color=\"dark\"\n            slot=\"icon-only\"\n            [name]=\"verTri != idx? 'caret-forward' : 'caret-down'\"></ion-icon>\n          </ion-button>\n\n        <label> {{per.nombre || \"1 trimertre\" }} </label>\n\n        <div class=\"more\">\n        \n          <ion-button fill=\"clear\"\n          (click)=\"opts($event, per.id)\">\n            <ion-icon color=\"dark\"\n            slot=\"icon-only\"\n            name=\"ellipsis-vertical\"></ion-icon>\n          </ion-button>\n  \n        </div>\n        \n      </ion-card-subtitle>\n    </ion-card-header>\n    <div *ngFor=\"let mate of dataMateria\">\n\n\n      <ion-item (click)=\"irCuaderno( mate.id )\"\n      *ngIf=\"mate.id_periodo === per.id\"\n      [hidden] =\"verTri != idx\"\n      color=\"dark\">\n      \n      <ion-label>\n        {{ mate.nombre }}\n      </ion-label>\n\n      <ion-icon slot=\"end\"\n       name=\"caret-forward\"></ion-icon>\n\n  </ion-item>\n  </div>\n\n  <ion-item  class=\"ion-text-center\"\n  [hidden] =\"verTri != idx\"\n  (click)=\"aggMateria(per.id, per.nombre)\"\n  color=\"dark\">\n\n    <ion-label color=\"primary\">\n      <ion-icon\n      name=\"add\"\n      slot=\"icon-only\"></ion-icon>\n      \n      Agregar materia\n    </ion-label>\n\n\n  </ion-item>\n\n\n\n</ion-card>\n  \n\n<app-fab slot=\"fixed\"\nclass=\"fixed\"\n[pageCuaderno]=\"true\"></app-fab>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/materias/materias-routing.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/materias/materias-routing.module.ts ***!
    \***********************************************************/

  /*! exports provided: MateriasPageRoutingModule */

  /***/
  function srcAppPagesMateriasMateriasRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MateriasPageRoutingModule", function () {
      return MateriasPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _materias_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./materias.page */
    "./src/app/pages/materias/materias.page.ts");

    var routes = [{
      path: '',
      component: _materias_page__WEBPACK_IMPORTED_MODULE_3__["MateriasPage"]
    }];

    var MateriasPageRoutingModule = function MateriasPageRoutingModule() {
      _classCallCheck(this, MateriasPageRoutingModule);
    };

    MateriasPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MateriasPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/materias/materias.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/pages/materias/materias.module.ts ***!
    \***************************************************/

  /*! exports provided: MateriasPageModule */

  /***/
  function srcAppPagesMateriasMateriasModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MateriasPageModule", function () {
      return MateriasPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _materias_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./materias-routing.module */
    "./src/app/pages/materias/materias-routing.module.ts");
    /* harmony import */


    var _materias_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./materias.page */
    "./src/app/pages/materias/materias.page.ts");
    /* harmony import */


    var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/components/components.module */
    "./src/app/components/components.module.ts");

    var MateriasPageModule = function MateriasPageModule() {
      _classCallCheck(this, MateriasPageModule);
    };

    MateriasPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _materias_routing_module__WEBPACK_IMPORTED_MODULE_5__["MateriasPageRoutingModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]],
      declarations: [_materias_page__WEBPACK_IMPORTED_MODULE_6__["MateriasPage"]]
    })], MateriasPageModule);
    /***/
  },

  /***/
  "./src/app/pages/materias/materias.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/pages/materias/materias.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMateriasMateriasPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL21hdGVyaWFzL21hdGVyaWFzLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/pages/materias/materias.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/pages/materias/materias.page.ts ***!
    \*************************************************/

  /*! exports provided: MateriasPage */

  /***/
  function srcAppPagesMateriasMateriasPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MateriasPage", function () {
      return MateriasPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_components_popover_popover_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/components/popover/popover.component */
    "./src/app/components/popover/popover.component.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/services/alertas.service */
    "./src/app/services/alertas.service.ts");
    /* harmony import */


    var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/services/db.service */
    "./src/app/services/db.service.ts");

    var MateriasPage = /*#__PURE__*/function () {
      function MateriasPage(popoverCtrl, alertCtrl, navCtrl, db, alertSvc, router) {
        _classCallCheck(this, MateriasPage);

        this.popoverCtrl = popoverCtrl;
        this.alertCtrl = alertCtrl;
        this.navCtrl = navCtrl;
        this.db = db;
        this.alertSvc = alertSvc;
        this.router = router;
        this.dataMateria = [];
        this.periodo = {
          nombre: '',
          id_usuario: 1
        };
        this.valid = false;
      }

      _createClass(MateriasPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          this.db.getDatabaseState().subscribe(function (boo) {
            if (boo) {
              _this.db.getPeriodo().subscribe(function (data) {
                _this.dataPeriodo = data;
              });

              _this.db.getMaterias().subscribe(function (data) {
                _this.dataMateria = data;
              });
            }
          });
        }
      }, {
        key: "onClick",
        value: function onClick(idx) {
          if (this.verTri === idx) {
            this.verTri = null;
          } else {
            this.verTri = idx;
          }
        }
      }, {
        key: "opts",
        value: function opts(event, id) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var popover, _yield$popover$onDidD, data;

            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.popoverCtrl.create({
                      component: src_app_components_popover_popover_component__WEBPACK_IMPORTED_MODULE_3__["PopoverComponent"],
                      cssClass: 'css_popover',
                      event: event,
                      mode: 'ios'
                    });

                  case 2:
                    popover = _context.sent;
                    _context.next = 5;
                    return popover.present();

                  case 5:
                    _context.next = 7;
                    return popover.onDidDismiss();

                  case 7:
                    _yield$popover$onDidD = _context.sent;
                    data = _yield$popover$onDidD.data;

                    if (data) {
                      this.opt = data.item;
                      this.optPeriodo(id);
                    }

                  case 10:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "optPeriodo",
        value: function optPeriodo(id) {
          if (this.opt === 'eliminar') {
            this.eliminarPeriodo(id);
          } else if (this.opt === 'editar') {
            this.cargarPeriodo(id);
          }
        }
      }, {
        key: "eliminarPeriodo",
        value: function eliminarPeriodo(id) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this2 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.alertCtrl.create({
                      cssClass: 'alert-css',
                      header: '¿Quieres eliminar este periodo?',
                      message: 'Se eliminaran materias, notas y eventos...',
                      backdropDismiss: false,
                      buttons: [{
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler(blah) {}
                      }, {
                        text: 'Eliminar periodo',
                        handler: function handler(blah) {
                          _this2.db.eliminarPeriodo(id);

                          _this2.db.cargarMateriaPeriodo(id).then(function (data) {
                            var _iterator = _createForOfIteratorHelper(data),
                                _step;

                            try {
                              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                                var mate = _step.value;

                                if (mate.id_evento > 0) {
                                  _this2.db.eliminarEvento(mate.id_evento);
                                }

                                _this2.db.eliminarCuadernoPeriodo(mate.id);
                              }
                            } catch (err) {
                              _iterator.e(err);
                            } finally {
                              _iterator.f();
                            }

                            _this2.db.eliminarMateriasPeriodo(id);
                          });

                          _this2.alertSvc.presentToast("Periodo eliminado con exito");
                        }
                      }]
                    });

                  case 2:
                    alert = _context2.sent;
                    _context2.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "nuevoPeriodo",
        value: function nuevoPeriodo() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this3 = this;

            var text, value, header, alert;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    text = 'titulo';
                    value = '';
                    header = 'Agregar Periodo';

                    if (this.valid) {
                      text = this.prederPeriodo.nombre;
                      value = this.prederPeriodo.nombre;
                      header = 'Editar periodo';
                    }

                    _context3.next = 6;
                    return this.alertCtrl.create({
                      cssClass: 'alert-css',
                      header: header,
                      backdropDismiss: false,
                      inputs: [{
                        name: 'nombre',
                        type: 'text',
                        placeholder: text,
                        value: value
                      }],
                      buttons: [{
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler() {
                          _this3.valid = false;
                        }
                      }, {
                        text: 'Guardar',
                        handler: function handler(data) {
                          data.nombre = data.nombre.trim();

                          if (data.nombre.length > 0) {
                            _this3.periodo = {
                              nombre: data.nombre,
                              id_usuario: 1
                            };

                            if (_this3.valid) {
                              _this3.db.updatePeriodo(_this3.prederPeriodo.id, _this3.periodo.nombre).then(function (_) {
                                _this3.valid = false;
                              });
                            } else {
                              _this3.valid = false;

                              _this3.guardarPeriodo();
                            }
                          } else {
                            _this3.alertSvc.presentToast('Debe de ingresar un titulo');
                          }
                        }
                      }]
                    });

                  case 6:
                    alert = _context3.sent;
                    _context3.next = 9;
                    return alert.present();

                  case 9:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "guardarPeriodo",
        value: function guardarPeriodo() {
          var _this4 = this;

          this.db.getDatabaseState().subscribe(function (boo) {
            if (boo) {
              _this4.db.agregarPeriodo(_this4.periodo.nombre, _this4.periodo.id_usuario);

              _this4.periodo = {
                nombre: '',
                id_usuario: 0
              };
            }
          });
        }
      }, {
        key: "cargarPeriodo",
        value: function cargarPeriodo(id) {
          var _this5 = this;

          this.db.getDatabaseState().subscribe(function (boo) {
            if (boo) {
              _this5.db.cargarPeriodoId(id).then(function (data) {
                _this5.prederPeriodo = data;
                _this5.valid = true;

                _this5.nuevoPeriodo();
              });
            }
          });
        }
      }, {
        key: "aggMateria",
        value: function aggMateria(id, nombre) {
          var navigationExtras = {
            state: {
              id: id,
              nombre: nombre
            }
          };
          this.navCtrl.navigateForward(['/agg-materia'], navigationExtras);
        }
      }, {
        key: "irCuaderno",
        value: function irCuaderno(id) {
          this.router.navigate(['/materia-id', id]);
        }
      }]);

      return MateriasPage;
    }();

    MateriasPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_6__["DatabaseService"]
      }, {
        type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_5__["AlertasService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
      }];
    };

    MateriasPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-materias',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./materias.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/materias/materias.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./materias.page.scss */
      "./src/app/pages/materias/materias.page.scss"))["default"]]
    })], MateriasPage);
    /***/
  },

  /***/
  "./src/app/services/alertas.service.ts":
  /*!*********************************************!*\
    !*** ./src/app/services/alertas.service.ts ***!
    \*********************************************/

  /*! exports provided: AlertasService */

  /***/
  function srcAppServicesAlertasServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AlertasService", function () {
      return AlertasService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./db.service */
    "./src/app/services/db.service.ts");

    var AlertasService = /*#__PURE__*/function () {
      function AlertasService(alertCtrl, dataSvc, db, toastCtrl) {
        _classCallCheck(this, AlertasService);

        this.alertCtrl = alertCtrl;
        this.dataSvc = dataSvc;
        this.db = db;
        this.toastCtrl = toastCtrl;
      }

      _createClass(AlertasService, [{
        key: "presentToast",
        value: function presentToast(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var toast;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.toastCtrl.create({
                      cssClass: "alert",
                      message: message,
                      duration: 2000
                    });

                  case 2:
                    toast = _context4.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }]);

      return AlertasService;
    }();

    AlertasService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
      }, {
        type: _db_service__WEBPACK_IMPORTED_MODULE_4__["DatabaseService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    AlertasService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], AlertasService);
    /***/
  }
}]);
//# sourceMappingURL=pages-materias-materias-module-es5.js.map