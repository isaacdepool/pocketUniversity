(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-cuaderno-id-cuaderno-id-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cuaderno-id/cuaderno-id.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cuaderno-id/cuaderno-id.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"danger\">\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/\"></ion-back-button>\n    </ion-buttons>\n\n    <ion-title><ion-label>{{modelCuaderno.nombreMateria || 'Notas'}}</ion-label></ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n  <ion-content>\n\n     <form #form=\"ngForm\" (ngSubmit)=\"guardar()\">\n      <ion-list>\n          \n        <ion-item> \n            \n            <ion-button\n            type=\"submit\"\n               expand=\"block\" \n               color=\"dark\"\n               shape=\"round\"\n               fill=\"clear\" \n               size=\"medium\">\n               <ion-label>Guardar</ion-label>\n           </ion-button>\n\n            <div slot=\"end\">\n              \n              <ion-button\n              color=\"dark\" \n              (click)=\"selectArchivo( $event )\" \n              fill=\"clear\" \n              size=\"medium\">\n              <ion-icon slot=\"icon-only\" \n              name=\"file-tray-full\"></ion-icon>\n            </ion-button>\n\n            <ion-button\n                color=\"dark\" \n                (click)=\"archivos( $event )\" \n                fill=\"clear\" \n                size=\"medium\">\n                <ion-icon slot=\"icon-only\" \n                name=\"archive\"></ion-icon>\n            </ion-button>\n            \n           <ion-button\n           color=\"dark\"\n           fill=\"clear\" \n           size=\"medium\"\n           (click)=\"eliminar()\">\n   \n             <ion-icon \n             slot=\"icon-only\"\n             name=\"trash\"></ion-icon>\n   \n           </ion-button>\n            </div>\n            \n        </ion-item>\n\n        <ion-item>\n            <ion-input \n            name=\"titulo\"\n            [(ngModel)]=\"modelCuaderno.titulo\"\n            autocapitalize=\"true\"\n            spellcheck\n            autofocus \n            type=\"text\"\n            placeholder=\"Titulo\">\n          </ion-input>\n        </ion-item>\n\n        <ion-item color=\"\">\n            <ion-textarea\n            auto-grow=\"true\"\n            autosize=\"true\"\n            name=\"contenico\"\n            [(ngModel)]=\"modelCuaderno.contenido\"\n            #text\n            placeholder=\"Notas\"\n            spellcheck\n            autocapitalize=\"true\">\n          </ion-textarea>\n        </ion-item>\n    </ion-list>\n     </form>\n\n\n  </ion-content>\n\n\n");

/***/ }),

/***/ "./src/app/pages/cuaderno-id/cuaderno-id-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/cuaderno-id/cuaderno-id-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: CuadernoIdPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CuadernoIdPageRoutingModule", function() { return CuadernoIdPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _cuaderno_id_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./cuaderno-id.page */ "./src/app/pages/cuaderno-id/cuaderno-id.page.ts");




const routes = [
    {
        path: '',
        component: _cuaderno_id_page__WEBPACK_IMPORTED_MODULE_3__["CuadernoIdPage"]
    }
];
let CuadernoIdPageRoutingModule = class CuadernoIdPageRoutingModule {
};
CuadernoIdPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CuadernoIdPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/cuaderno-id/cuaderno-id.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/cuaderno-id/cuaderno-id.module.ts ***!
  \*********************************************************/
/*! exports provided: CuadernoIdPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CuadernoIdPageModule", function() { return CuadernoIdPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _cuaderno_id_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./cuaderno-id-routing.module */ "./src/app/pages/cuaderno-id/cuaderno-id-routing.module.ts");
/* harmony import */ var _cuaderno_id_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./cuaderno-id.page */ "./src/app/pages/cuaderno-id/cuaderno-id.page.ts");







let CuadernoIdPageModule = class CuadernoIdPageModule {
};
CuadernoIdPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _cuaderno_id_routing_module__WEBPACK_IMPORTED_MODULE_5__["CuadernoIdPageRoutingModule"]
        ],
        declarations: [_cuaderno_id_page__WEBPACK_IMPORTED_MODULE_6__["CuadernoIdPage"]]
    })
], CuadernoIdPageModule);



/***/ }),

/***/ "./src/app/pages/cuaderno-id/cuaderno-id.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/cuaderno-id/cuaderno-id.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2N1YWRlcm5vLWlkL2N1YWRlcm5vLWlkLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/pages/cuaderno-id/cuaderno-id.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/cuaderno-id/cuaderno-id.page.ts ***!
  \*******************************************************/
/*! exports provided: CuadernoIdPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CuadernoIdPage", function() { return CuadernoIdPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/db.service */ "./src/app/services/db.service.ts");
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/alertas.service */ "./src/app/services/alertas.service.ts");
/* harmony import */ var src_app_services_archivos_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/archivos.service */ "./src/app/services/archivos.service.ts");
/* harmony import */ var src_app_components_popover_archivos_popover_archivos_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/popover-archivos/popover-archivos.component */ "./src/app/components/popover-archivos/popover-archivos.component.ts");








let CuadernoIdPage = class CuadernoIdPage {
    constructor(popoverCtrl, activatedRoute, db, alerta, navCtrl, alertCtrl, alertSvc, archivosSvc) {
        this.popoverCtrl = popoverCtrl;
        this.activatedRoute = activatedRoute;
        this.db = db;
        this.alerta = alerta;
        this.navCtrl = navCtrl;
        this.alertCtrl = alertCtrl;
        this.alertSvc = alertSvc;
        this.archivosSvc = archivosSvc;
        this.fechaHoy = new Date();
        this.dataArchi = {};
        this.valid = false;
        this.modelCuaderno = {
            nombreMateria: '',
            titulo: '',
            fecha_mod: this.fechaHoy.toISOString(),
            fecha_crea: '',
            contenido: '',
        };
        this.modelArchivo = {
            array: [],
            id_usuario: 1,
            id_cuaderno: 0
        };
        this.activatedRoute.params.subscribe(params => {
            this.idCuaderno = params['idC'];
            this.idMateria = params['idM'];
        });
    }
    ngOnInit() {
        this.db.getDatabaseState().subscribe(boo => {
            if (boo && this.idCuaderno > 0 && this.idMateria > 0) {
                // Cargar Cuaderno 
                this.db.cargarCuadernoId(this.idCuaderno).then(data => {
                    this.dataCuaderno = data;
                    this.valid = true;
                });
                // Cargar Materias
                this.db.cargarMateriaId(this.idMateria).then(data => {
                    this.dataMateria = data;
                }).then(_ => {
                    this.modelCuaderno = {
                        nombreMateria: this.dataMateria.nombre,
                        titulo: this.dataCuaderno.titulo,
                        fecha_crea: this.dataCuaderno.fecha_crea,
                        fecha_mod: this.fechaHoy.toISOString(),
                        contenido: this.dataCuaderno.contenido,
                    };
                });
                this.db.getArchivo().subscribe(data => {
                });
                this.db.cargarArchivosCuaderno(this.idCuaderno).then(data => {
                    this.modelArchivo.array = data;
                });
            }
        });
    }
    archivos(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.dataArchi = [{ nombre: 'Cargar Archivos' }];
            const popover = yield this.popoverCtrl.create({
                component: src_app_components_popover_archivos_popover_archivos_component__WEBPACK_IMPORTED_MODULE_7__["PopoverArchivosComponent"],
                cssClass: 'css_popover',
                event: event,
                mode: 'ios',
                componentProps: {
                    opt: this.dataArchi
                }
            });
            yield popover.present();
            const { data } = yield popover.onDidDismiss();
            if (data) {
                this.opt = data.item;
                this.cargarArchivo();
            }
        });
    }
    cargarArchivo() {
        if (this.opt === 'Cargar Archivos') {
            this.archivosSvc.cargar().then(url => {
                this.guardarArchivo(url).then(_ => {
                    this.alertSvc.presentToast('Archivo agregado con exito');
                })
                    .catch(_ => this.alertSvc.presentToast('No se cargo ningun archivo'));
            });
        }
    }
    guardarArchivo(url) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.archivosSvc.copyFile(url);
            let nombre = url.substr(url.lastIndexOf('/') + 1);
            let items = {
                nombre: nombre,
                url: url
            };
            this.modelArchivo.array.push(items);
        });
    }
    selectArchivo(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.modelArchivo.array.length > 0) {
                this.dataArchi = this.modelArchivo.array;
            }
            else
                this.dataArchi = [{ nombre: 'Sin Archivos' }];
            const popover = yield this.popoverCtrl.create({
                component: src_app_components_popover_archivos_popover_archivos_component__WEBPACK_IMPORTED_MODULE_7__["PopoverArchivosComponent"],
                cssClass: 'css_popover',
                event: event,
                mode: 'ios',
                translucent: false,
                componentProps: {
                    opt: this.dataArchi
                }
            });
            yield popover.present();
            const { data } = yield popover.onDidDismiss();
            if (data) {
                this.abrirArchivo(data.url);
            }
        });
    }
    abrirArchivo(data) {
        this.archivosSvc.open(data);
    }
    guardar() {
        this.modelCuaderno.contenido = this.modelCuaderno.contenido.trim();
        this.modelCuaderno.titulo = this.modelCuaderno.titulo.trim();
        if ((this.modelCuaderno.contenido.length == 0) && (this.modelCuaderno.titulo.length == 0)) {
            this.alerta.presentToast("Sin datos que guardar. No se ha creado la nota");
            this.navCtrl.back();
        }
        else if (!this.valid) {
            this.valid = !this.valid;
            this.db.agregarCuaderno(this.modelCuaderno.titulo, this.modelCuaderno.fecha_mod, this.modelCuaderno.fecha_mod, this.modelCuaderno.contenido, this.idMateria).then(data => {
                this.idCuaderno = data;
                if (this.modelArchivo.array.length > 0) {
                    for (let archi of this.modelArchivo.array) {
                        this.db.agregarArchivos(archi['url'], archi['nombre'], this.modelArchivo.id_usuario, this.idCuaderno);
                    }
                }
            });
            this.alerta.presentToast('Datos guardados con exito');
            this.navCtrl.back();
        }
        else {
            this.valid = !this.valid;
            this.db.updateCuaderno(this.idCuaderno, this.modelCuaderno.titulo, this.modelCuaderno.fecha_crea, this.modelCuaderno.fecha_mod, this.modelCuaderno.contenido, this.idMateria);
            if (this.modelArchivo.array.length > 0) {
                for (let archi of this.modelArchivo.array) {
                    this.db.agregarArchivos(archi['url'], archi['nombre'], this.modelArchivo.id_usuario, this.idCuaderno);
                }
            }
            this.alerta.presentToast('Datos guardados con exito');
            this.navCtrl.back();
        }
    }
    focus() {
        this.textarea.setFocus();
    }
    eliminar() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'alert-css',
                header: '¿Quieres eliminar esta nota?',
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                        }
                    },
                    {
                        text: 'Eliminar nota',
                        handler: (blah) => {
                            if (this.valid) {
                                this.db.eliminarCuaderno(this.idCuaderno).then(_ => {
                                    this.db.eliminarArchivoCuaderno(this.idCuaderno).then(_ => {
                                        this.alertSvc.presentToast("Nota eliminada con exito");
                                        this.navCtrl.back();
                                        this.valid = !this.valid;
                                    }).catch(err => console.log(err));
                                }).catch(err => err);
                            }
                            else {
                                this.alertSvc.presentToast("No se ha creado la nota");
                                this.navCtrl.back();
                            }
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
CuadernoIdPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_4__["DatabaseService"] },
    { type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_5__["AlertasService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_5__["AlertasService"] },
    { type: src_app_services_archivos_service__WEBPACK_IMPORTED_MODULE_6__["ArchivosService"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('text')
], CuadernoIdPage.prototype, "textarea", void 0);
CuadernoIdPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-cuaderno-id',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./cuaderno-id.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cuaderno-id/cuaderno-id.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./cuaderno-id.page.scss */ "./src/app/pages/cuaderno-id/cuaderno-id.page.scss")).default]
    })
], CuadernoIdPage);



/***/ }),

/***/ "./src/app/services/alertas.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/alertas.service.ts ***!
  \*********************************************/
/*! exports provided: AlertasService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertasService", function() { return AlertasService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./data.service */ "./src/app/services/data.service.ts");
/* harmony import */ var _db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./db.service */ "./src/app/services/db.service.ts");





let AlertasService = class AlertasService {
    constructor(alertCtrl, dataSvc, db, toastCtrl) {
        this.alertCtrl = alertCtrl;
        this.dataSvc = dataSvc;
        this.db = db;
        this.toastCtrl = toastCtrl;
    }
    presentToast(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                cssClass: "alert",
                message,
                duration: 2000,
            });
            toast.present();
        });
    }
};
AlertasService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"] },
    { type: _db_service__WEBPACK_IMPORTED_MODULE_4__["DatabaseService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
AlertasService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AlertasService);



/***/ }),

/***/ "./src/app/services/archivos.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/archivos.service.ts ***!
  \**********************************************/
/*! exports provided: ArchivosService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ArchivosService", function() { return ArchivosService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/file-path/ngx */ "./node_modules/@ionic-native/file-path/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/file-chooser/ngx */ "./node_modules/@ionic-native/file-chooser/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "./node_modules/@ionic-native/file-opener/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/File/ngx */ "./node_modules/@ionic-native/File/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");







const Media_folder_name = 'Archivos';
const Local_location_name = "file:///storage/emulated/0/Myapp/";
let ArchivosService = class ArchivosService {
    constructor(filePath, fileChooser, fileOpener, file, plt) {
        this.filePath = filePath;
        this.fileChooser = fileChooser;
        this.fileOpener = fileOpener;
        this.file = file;
        this.plt = plt;
        this.plt.ready().then(() => {
            // Raiz 
            let path = this.file.dataDirectory;
            this.file.checkDir(path, Media_folder_name)
                .then(() => {
            }, err => {
                this.file.createDir(path, Media_folder_name, false);
            });
            // LOCAL 
            let path2 = Local_location_name;
            this.file.checkDir(path2, Media_folder_name)
                .then(() => {
            }, err => {
                this.file.createDir(path2, Media_folder_name, false);
            });
        });
    }
    cargar() {
        return this.fileChooser.open().then(uri => {
            return this.filePath.resolveNativePath(uri)
                .catch(err => console.log(err));
        }).catch(err => console.log(err));
    }
    ;
    open(url) {
        this.fileOpener.showOpenWithDialog(url, '')
            .catch(err => console.log(err));
    }
    copyFile(fullPath) {
        let myPath = fullPath;
        let native;
        let local;
        if (fullPath.indexOf('file://') < 0) {
            myPath = 'file://' + fullPath;
        }
        const ext = myPath.split('.').pop();
        const d = Date.now();
        const newName = `${d}.${ext}`;
        const name = myPath.substr(myPath.lastIndexOf('/') + 1);
        const copyFrom = myPath.substr(0, myPath.lastIndexOf('/') + 1);
        const copyToLocal = Local_location_name + Media_folder_name;
        const copyToNative = this.file.dataDirectory + Media_folder_name;
        this.file.copyFile(copyFrom, name, copyToLocal, newName)
            .then(success => {
        }, err => {
        });
        this.file.copyFile(copyFrom, name, copyToNative, newName)
            .then(success => {
        }, err => {
        });
        return;
    }
};
ArchivosService.ctorParameters = () => [
    { type: _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_2__["FilePath"] },
    { type: _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_3__["FileChooser"] },
    { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_4__["FileOpener"] },
    { type: _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_5__["File"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["Platform"] }
];
ArchivosService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ArchivosService);



/***/ })

}]);
//# sourceMappingURL=pages-cuaderno-id-cuaderno-id-module-es2015.js.map