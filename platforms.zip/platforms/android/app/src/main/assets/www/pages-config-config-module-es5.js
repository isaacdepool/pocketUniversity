function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-config-config-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/config/config.page.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/config/config.page.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesConfigConfigPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<app-header titulo=\"Configuraciones\"></app-header>\n\n<ion-content>\n\n  <ion-list>\n    <ion-item>\n      <ion-icon slot=\"start\" name=\"moon\"></ion-icon>\n      <ion-label>Modo oscuro</ion-label>\n      <ion-toggle slot=\"end\"\n      [ngModel]=\"modoOscuro\"\n      (ionChange)=\"darkMode()\"></ion-toggle>\n    </ion-item>\n  </ion-list>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pages/config/config-routing.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/config/config-routing.module.ts ***!
    \*******************************************************/

  /*! exports provided: ConfigPageRoutingModule */

  /***/
  function srcAppPagesConfigConfigRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ConfigPageRoutingModule", function () {
      return ConfigPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _config_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./config.page */
    "./src/app/pages/config/config.page.ts");

    var routes = [{
      path: '',
      component: _config_page__WEBPACK_IMPORTED_MODULE_3__["ConfigPage"]
    }];

    var ConfigPageRoutingModule = function ConfigPageRoutingModule() {
      _classCallCheck(this, ConfigPageRoutingModule);
    };

    ConfigPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ConfigPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/config/config.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/pages/config/config.module.ts ***!
    \***********************************************/

  /*! exports provided: ConfigPageModule */

  /***/
  function srcAppPagesConfigConfigModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ConfigPageModule", function () {
      return ConfigPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _config_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./config-routing.module */
    "./src/app/pages/config/config-routing.module.ts");
    /* harmony import */


    var _config_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./config.page */
    "./src/app/pages/config/config.page.ts");
    /* harmony import */


    var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/components/components.module */
    "./src/app/components/components.module.ts");

    var ConfigPageModule = function ConfigPageModule() {
      _classCallCheck(this, ConfigPageModule);
    };

    ConfigPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _config_routing_module__WEBPACK_IMPORTED_MODULE_5__["ConfigPageRoutingModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]],
      declarations: [_config_page__WEBPACK_IMPORTED_MODULE_6__["ConfigPage"]]
    })], ConfigPageModule);
    /***/
  },

  /***/
  "./src/app/pages/config/config.page.scss":
  /*!***********************************************!*\
    !*** ./src/app/pages/config/config.page.scss ***!
    \***********************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesConfigConfigPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2NvbmZpZy9jb25maWcucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/pages/config/config.page.ts":
  /*!*********************************************!*\
    !*** ./src/app/pages/config/config.page.ts ***!
    \*********************************************/

  /*! exports provided: ConfigPage */

  /***/
  function srcAppPagesConfigConfigPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ConfigPage", function () {
      return ConfigPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/file-chooser/ngx */
    "./node_modules/@ionic-native/file-chooser/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/file-opener/ngx */
    "./node_modules/@ionic-native/file-opener/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/file-path/ngx */
    "./node_modules/@ionic-native/file-path/__ivy_ngcc__/ngx/index.js");

    var STORAGE_KEY = 'my_images';

    var ConfigPage = /*#__PURE__*/function () {
      function ConfigPage(fileChooser, fileOpener, filePath) {
        _classCallCheck(this, ConfigPage);

        this.fileChooser = fileChooser;
        this.fileOpener = fileOpener;
        this.filePath = filePath;
        this.modoOscuro = true;
        var prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
        this.modoOscuro = prefersDark.matches;
      }

      _createClass(ConfigPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "darkMode",
        value: function darkMode() {
          this.modoOscuro = !this.modoOscuro;
          document.body.classList.toggle('dark');
        }
      }]);

      return ConfigPage;
    }();

    ConfigPage.ctorParameters = function () {
      return [{
        type: _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_2__["FileChooser"]
      }, {
        type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_3__["FileOpener"]
      }, {
        type: _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_4__["FilePath"]
      }];
    };

    ConfigPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-config',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./config.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/config/config.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./config.page.scss */
      "./src/app/pages/config/config.page.scss"))["default"]]
    })], ConfigPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-config-config-module-es5.js.map