(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-agg-evento-agg-evento-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/agg-evento/agg-evento.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/agg-evento/agg-evento.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"danger\">\n\n    <ion-buttons slot=\"start\">\n\n     <ion-buttons slot=\"start\">\n       <ion-back-button defaultHref=\"/\"></ion-back-button>\n     </ion-buttons>\n\n    </ion-buttons>\n\n    <ion-title *ngIf=\"!boo\"> Agregar nuevo evento </ion-title>\n    <ion-title *ngIf=\"boo\"> Editar evento </ion-title>    \n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n\n  <form #form=\"ngForm\" (ngSubmit)=\"onSubmitTemplate()\">\n    \n    <!-- Nombre -->\n            <ion-item> \n              <ion-icon slot=\"start\" name=\"reader\"></ion-icon>\n        \n              <ion-label position=\"floating\">\n              Titulo</ion-label>\n              \n              <ion-input\n              type=\"text\"\n              name=\"nombre\"\n              [(ngModel)]=\"evento.nombre\"\n              minlength=\"1\"\n              maxlegth=\"15\"\n              required>\n              \n            </ion-input>\n            \n            \n          </ion-item>\n        \n  <!-- hora del evento -->\n    <ion-list>\n      \n      <ion-item lines=\"none\">\n        <ion-icon slot=\"start\" name=\"time\"></ion-icon>\n    \n        <ion-input type=\"text\"\n        disabled \n        >Dia</ion-input>\n    \n        <ion-datetime\n        required \n        name=\"dia\"\n        (ionChange)=\"dia( $event )\"\n        [(ngModel)]=\"evento.dia\"\n        displayFormat=\"DD MMMM YYYY\"   \n        placeholder=\"Dia/Mes/Año\"\n        [monthNames]=\"monthNames\"\n        cancelText = \"Cancelar\"\n        doneText= \"Aceptar\"\n        [min]=\"diaIngresado\"\n        max=\"2050-12-31\"\n        ></ion-datetime> \n        \n        \n        </ion-item>\n\n        <ion-item lines=\"none\">\n          <ion-icon slot=\"start\"></ion-icon>\n      \n          <ion-input type=\"text\"\n          disabled \n          >Inicio</ion-input>\n      \n          <ion-datetime\n          required \n          name=\"inicio\"\n          [(ngModel)]=\"evento.inicio\"\n          displayFormat=\"hh:mm a\"   \n          placeholder=\"00:00\"\n          cancelText = \"Cancelar\"\n          doneText= \"Aceptar\"\n          [min]=\"horaLocal\"\n          ></ion-datetime> \n          \n      \n          </ion-item>\n        \n        <ion-item>\n    \n          <ion-icon slot=\"start\"></ion-icon>\n    \n        <ion-input type=\"text\"\n        disabled \n        >Fin</ion-input> \n    \n        <ion-datetime \n        required \n        name=\"fin\"\n        [(ngModel)]=\"evento.fin\"\n        displayFormat=\"hh:mm a\"  \n        [min]=\"evento.inicio.toISOString\"\n        placeholder=\"00:00\"\n        cancelText = \"Cancelar\"\n        doneText= \"Aceptar\"\n        ></ion-datetime> \n    \n        </ion-item>\n        \n    </ion-list>\n        \n      <!-- Tipo de recordatorio -->\n    \n          \n          <ion-radio-group required\n          [(ngModel)]=\"evento.tipo\"\n          name=\"tipo\"\n          class=\"ion-padding\"\n          value=\"biff\">\n    \n            <ion-label disabled>\n              <ion-icon slot=\"start\" name=\"pricetag\"></ion-icon>\n                Tipo de recordatorio\n              </ion-label>\n            \n            <ion-item lines=\"none\">\n              <ion-icon slot=\"start\"></ion-icon>\n    \n              <ion-input type=\"text\" \n              disabled >Estudio</ion-input>\n    \n              <ion-radio slot=\"start\" value=\"library\"></ion-radio>\n            </ion-item>\n    \n            <ion-item >\n              <ion-icon slot=\"start\"></ion-icon>\n    \n              <ion-input\n              type=\"text\" \n              disabled>Evento</ion-input>\n    \n              <ion-radio slot=\"start\" value=\"notifications-circle\"></ion-radio>\n            </ion-item>\n            \n          </ion-radio-group>\n\n    <!-- Comentario -->\n        <ion-item>\n          <ion-icon slot=\"start\" name=\"pencil\"></ion-icon>\n    \n          <ion-label position=\"floating\">\n          Comentario</ion-label>\n          \n          <ion-input\n          type=\"text\"\n          name=\"comentario\"\n          [(ngModel)]=\"evento.comentario\"\n          maxlegth=\"100\">\n          \n        </ion-input>\n        \n        \n      </ion-item>\n\n        <ion-button class=\"ion-padding\"\n        type=\"submit\" \n        expand=\"block\"\n        [disabled]=\"form.invalid\">\n          Guardar\n        </ion-button>\n\n        \n\n  </form>\n  \n\n\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/agg-evento/agg-evento-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/pages/agg-evento/agg-evento-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: AggEventoPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AggEventoPageRoutingModule", function() { return AggEventoPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _agg_evento_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./agg-evento.page */ "./src/app/pages/agg-evento/agg-evento.page.ts");




const routes = [
    {
        path: '',
        component: _agg_evento_page__WEBPACK_IMPORTED_MODULE_3__["AggEventoPage"]
    }
];
let AggEventoPageRoutingModule = class AggEventoPageRoutingModule {
};
AggEventoPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AggEventoPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/agg-evento/agg-evento.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/agg-evento/agg-evento.module.ts ***!
  \*******************************************************/
/*! exports provided: AggEventoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AggEventoPageModule", function() { return AggEventoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _agg_evento_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./agg-evento-routing.module */ "./src/app/pages/agg-evento/agg-evento-routing.module.ts");
/* harmony import */ var _agg_evento_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./agg-evento.page */ "./src/app/pages/agg-evento/agg-evento.page.ts");
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/components.module */ "./src/app/components/components.module.ts");








let AggEventoPageModule = class AggEventoPageModule {
};
AggEventoPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _agg_evento_routing_module__WEBPACK_IMPORTED_MODULE_5__["AggEventoPageRoutingModule"],
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]
        ],
        declarations: [_agg_evento_page__WEBPACK_IMPORTED_MODULE_6__["AggEventoPage"]]
    })
], AggEventoPageModule);



/***/ }),

/***/ "./src/app/pages/agg-evento/agg-evento.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/pages/agg-evento/agg-evento.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FnZy1ldmVudG8vYWdnLWV2ZW50by5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/pages/agg-evento/agg-evento.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/agg-evento/agg-evento.page.ts ***!
  \*****************************************************/
/*! exports provided: AggEventoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AggEventoPage", function() { return AggEventoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/db.service */ "./src/app/services/db.service.ts");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/alertas.service */ "./src/app/services/alertas.service.ts");
/* harmony import */ var src_app_services_noti_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/noti.service */ "./src/app/services/noti.service.ts");








let AggEventoPage = class AggEventoPage {
    constructor(db, navCtrl, activateRouter, router, alert, notiSvc) {
        this.db = db;
        this.navCtrl = navCtrl;
        this.activateRouter = activateRouter;
        this.router = router;
        this.alert = alert;
        this.notiSvc = notiSvc;
        this.events = [];
        this.h = new Date();
        this.horaLocal = '01:00 am';
        this.diaActual = '';
        this.diaIngresado = moment__WEBPACK_IMPORTED_MODULE_3__(this.h.toISOString()).format('YYYY-MM-DD');
        this.boo = false;
        this.monthNames = [];
        this.monthShortNames = moment__WEBPACK_IMPORTED_MODULE_3__["months"]();
        //  eventoModal
        this.evento = {
            dia: '',
            inicio: '',
            fin: '',
            nombre: '',
            tipo: '',
            comentario: '',
            id_usuario: 1
        };
        this.activateRouter.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.boo = this.router.getCurrentNavigation().extras.state.boo;
                this.id = this.router.getCurrentNavigation().extras.state.id;
            }
            if (this.boo) {
                this.dataPreder();
            }
        });
    }
    ;
    ngOnInit() {
        this.db.getDatabaseState().subscribe(boo => {
            if (boo) {
                this.db.getEvento().subscribe(data => {
                    this.events = data;
                    this.momentDateConfig();
                });
            }
        });
    }
    // Validar evento
    onSubmitTemplate() {
        this.evento.nombre = this.evento.nombre.trim();
        if ((this.evento.fin < this.evento.inicio)) {
            this.alert.presentToast("Horas incorrectas. El inicio debe ser antes que el fin");
            this.limpiarEvento();
        }
        else if (this.evento.nombre === '' || this.evento.nombre.length < 1) {
            this.alert.presentToast("Por favor ingrese un titulo de minimo 1 caracteres");
            this.limpiarEvento();
        }
        else {
            this.ingresarEvento();
            this.notiSvc.simpleNoti();
            this.alert.presentToast("Datos guardados correctamente");
            this.navCtrl.back();
        }
    }
    momentDateConfig() {
        moment__WEBPACK_IMPORTED_MODULE_3__["locale"]('es');
        this.monthNames = moment__WEBPACK_IMPORTED_MODULE_3__["months"]();
        this.diaIngresado = moment__WEBPACK_IMPORTED_MODULE_3__(this.h.toISOString()).format('YYYY-MM-DD');
    }
    limpiarEvento() {
        this.evento.dia = '';
        this.evento.inicio = '';
        this.evento.fin = '';
    }
    // Ingresar evento
    ingresarEvento() {
        if (this.boo) {
            this.db.updateEvento(this.id, this.evento.nombre, this.evento.dia, this.evento.inicio, this.evento.fin, this.evento.tipo, this.evento.comentario)
                .then(_ => {
                this.evento = {
                    dia: '',
                    inicio: '',
                    fin: '',
                    nombre: '',
                    tipo: '',
                    comentario: '',
                    id_usuario: 1
                };
            }).catch(err => console.log(err));
        }
        else {
            this.db.agregarEvento(this.evento.nombre, this.evento.dia, this.evento.inicio, this.evento.fin, this.evento.tipo, this.evento.comentario, this.evento.id_usuario)
                .then(_ => {
                this.evento = {
                    dia: '',
                    inicio: '',
                    fin: '',
                    nombre: '',
                    tipo: '',
                    comentario: '',
                    id_usuario: 1
                };
            }).catch(err => console.log(err));
        }
    }
    // Datos predeterminados para editar
    dataPreder() {
        this.db.getDatabaseState().subscribe(boo => {
            if (boo) {
                this.db.cargarEventoId(this.id).then(data => {
                    this.eventoCargado = data;
                    this.evento = {
                        dia: this.eventoCargado.dia,
                        inicio: this.eventoCargado.inicio,
                        fin: this.eventoCargado.fin,
                        nombre: this.eventoCargado.nombre,
                        tipo: this.eventoCargado.tipo,
                        comentario: this.eventoCargado.comentario,
                        id_usuario: this.id,
                    };
                });
            }
        });
    }
    dia(event) {
        let dia = moment__WEBPACK_IMPORTED_MODULE_3__(event.detail.value).format("YYYY-MM-DD");
        if (dia === this.diaIngresado) {
            this.horaLocal = moment__WEBPACK_IMPORTED_MODULE_3__(this.h.toISOString()).format('hh:mm');
        }
        else {
            this.horaLocal = "01:00";
        }
    }
};
AggEventoPage.ctorParameters = () => [
    { type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_6__["AlertasService"] },
    { type: src_app_services_noti_service__WEBPACK_IMPORTED_MODULE_7__["NotiService"] }
];
AggEventoPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-agg-evento',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./agg-evento.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/agg-evento/agg-evento.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./agg-evento.page.scss */ "./src/app/pages/agg-evento/agg-evento.page.scss")).default]
    })
], AggEventoPage);



/***/ }),

/***/ "./src/app/services/alertas.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/alertas.service.ts ***!
  \*********************************************/
/*! exports provided: AlertasService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertasService", function() { return AlertasService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./data.service */ "./src/app/services/data.service.ts");
/* harmony import */ var _db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./db.service */ "./src/app/services/db.service.ts");





let AlertasService = class AlertasService {
    constructor(alertCtrl, dataSvc, db, toastCtrl) {
        this.alertCtrl = alertCtrl;
        this.dataSvc = dataSvc;
        this.db = db;
        this.toastCtrl = toastCtrl;
    }
    presentToast(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                cssClass: "alert",
                message,
                duration: 2000,
            });
            toast.present();
        });
    }
};
AlertasService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"] },
    { type: _db_service__WEBPACK_IMPORTED_MODULE_4__["DatabaseService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
AlertasService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AlertasService);



/***/ }),

/***/ "./src/app/services/noti.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/noti.service.ts ***!
  \******************************************/
/*! exports provided: NotiService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotiService", function() { return NotiService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/local-notifications/ngx */ "./node_modules/@ionic-native/local-notifications/__ivy_ngcc__/ngx/index.js");



let NotiService = class NotiService {
    constructor(noti) {
        this.noti = noti;
    }
    simpleNoti() {
        // Schedule a single notification
        this.noti.schedule({
            id: 1,
            text: 'Single ILocalNotification',
            sound: 'file://sound.mp3' || false,
            data: { secret: 'key' }
        });
    }
};
NotiService.ctorParameters = () => [
    { type: _ionic_native_local_notifications_ngx__WEBPACK_IMPORTED_MODULE_2__["LocalNotifications"] }
];
NotiService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], NotiService);



/***/ })

}]);
//# sourceMappingURL=pages-agg-evento-agg-evento-module-es2015.js.map