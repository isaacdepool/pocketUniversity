function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-cuaderno-id-cuaderno-id-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cuaderno-id/cuaderno-id.page.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cuaderno-id/cuaderno-id.page.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesCuadernoIdCuadernoIdPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"danger\">\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/\"></ion-back-button>\n    </ion-buttons>\n\n    <ion-title><ion-label>{{modelCuaderno.nombreMateria || 'Notas'}}</ion-label></ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n  <ion-content>\n\n     <form #form=\"ngForm\" (ngSubmit)=\"guardar()\">\n      <ion-list>\n          \n        <ion-item> \n            \n            <ion-button\n            type=\"submit\"\n               expand=\"block\" \n               color=\"dark\"\n               shape=\"round\"\n               fill=\"clear\" \n               size=\"medium\">\n               <ion-label>Guardar</ion-label>\n           </ion-button>\n\n            <div slot=\"end\">\n              \n              <ion-button\n              color=\"dark\" \n              (click)=\"selectArchivo( $event )\" \n              fill=\"clear\" \n              size=\"medium\">\n              <ion-icon slot=\"icon-only\" \n              name=\"file-tray-full\"></ion-icon>\n            </ion-button>\n\n            <ion-button\n                color=\"dark\" \n                (click)=\"archivos( $event )\" \n                fill=\"clear\" \n                size=\"medium\">\n                <ion-icon slot=\"icon-only\" \n                name=\"archive\"></ion-icon>\n            </ion-button>\n            \n           <ion-button\n           color=\"dark\"\n           fill=\"clear\" \n           size=\"medium\"\n           (click)=\"eliminar()\">\n   \n             <ion-icon \n             slot=\"icon-only\"\n             name=\"trash\"></ion-icon>\n   \n           </ion-button>\n            </div>\n            \n        </ion-item>\n\n        <ion-item>\n            <ion-input \n            name=\"titulo\"\n            [(ngModel)]=\"modelCuaderno.titulo\"\n            autocapitalize=\"true\"\n            spellcheck\n            autofocus \n            type=\"text\"\n            placeholder=\"Titulo\">\n          </ion-input>\n        </ion-item>\n\n        <ion-item color=\"\">\n            <ion-textarea\n            auto-grow=\"true\"\n            autosize=\"true\"\n            name=\"contenico\"\n            [(ngModel)]=\"modelCuaderno.contenido\"\n            #text\n            placeholder=\"Notas\"\n            spellcheck\n            autocapitalize=\"true\">\n          </ion-textarea>\n        </ion-item>\n    </ion-list>\n     </form>\n\n\n  </ion-content>\n\n\n";
    /***/
  },

  /***/
  "./src/app/pages/cuaderno-id/cuaderno-id-routing.module.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/pages/cuaderno-id/cuaderno-id-routing.module.ts ***!
    \*****************************************************************/

  /*! exports provided: CuadernoIdPageRoutingModule */

  /***/
  function srcAppPagesCuadernoIdCuadernoIdRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CuadernoIdPageRoutingModule", function () {
      return CuadernoIdPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _cuaderno_id_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./cuaderno-id.page */
    "./src/app/pages/cuaderno-id/cuaderno-id.page.ts");

    var routes = [{
      path: '',
      component: _cuaderno_id_page__WEBPACK_IMPORTED_MODULE_3__["CuadernoIdPage"]
    }];

    var CuadernoIdPageRoutingModule = function CuadernoIdPageRoutingModule() {
      _classCallCheck(this, CuadernoIdPageRoutingModule);
    };

    CuadernoIdPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CuadernoIdPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/cuaderno-id/cuaderno-id.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/cuaderno-id/cuaderno-id.module.ts ***!
    \*********************************************************/

  /*! exports provided: CuadernoIdPageModule */

  /***/
  function srcAppPagesCuadernoIdCuadernoIdModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CuadernoIdPageModule", function () {
      return CuadernoIdPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _cuaderno_id_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./cuaderno-id-routing.module */
    "./src/app/pages/cuaderno-id/cuaderno-id-routing.module.ts");
    /* harmony import */


    var _cuaderno_id_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./cuaderno-id.page */
    "./src/app/pages/cuaderno-id/cuaderno-id.page.ts");

    var CuadernoIdPageModule = function CuadernoIdPageModule() {
      _classCallCheck(this, CuadernoIdPageModule);
    };

    CuadernoIdPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _cuaderno_id_routing_module__WEBPACK_IMPORTED_MODULE_5__["CuadernoIdPageRoutingModule"]],
      declarations: [_cuaderno_id_page__WEBPACK_IMPORTED_MODULE_6__["CuadernoIdPage"]]
    })], CuadernoIdPageModule);
    /***/
  },

  /***/
  "./src/app/pages/cuaderno-id/cuaderno-id.page.scss":
  /*!*********************************************************!*\
    !*** ./src/app/pages/cuaderno-id/cuaderno-id.page.scss ***!
    \*********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesCuadernoIdCuadernoIdPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2N1YWRlcm5vLWlkL2N1YWRlcm5vLWlkLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/pages/cuaderno-id/cuaderno-id.page.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/cuaderno-id/cuaderno-id.page.ts ***!
    \*******************************************************/

  /*! exports provided: CuadernoIdPage */

  /***/
  function srcAppPagesCuadernoIdCuadernoIdPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CuadernoIdPage", function () {
      return CuadernoIdPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/services/db.service */
    "./src/app/services/db.service.ts");
    /* harmony import */


    var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/services/alertas.service */
    "./src/app/services/alertas.service.ts");
    /* harmony import */


    var src_app_services_archivos_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/services/archivos.service */
    "./src/app/services/archivos.service.ts");
    /* harmony import */


    var src_app_components_popover_archivos_popover_archivos_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/components/popover-archivos/popover-archivos.component */
    "./src/app/components/popover-archivos/popover-archivos.component.ts");

    var CuadernoIdPage = /*#__PURE__*/function () {
      function CuadernoIdPage(popoverCtrl, activatedRoute, db, alerta, navCtrl, alertCtrl, alertSvc, archivosSvc) {
        var _this = this;

        _classCallCheck(this, CuadernoIdPage);

        this.popoverCtrl = popoverCtrl;
        this.activatedRoute = activatedRoute;
        this.db = db;
        this.alerta = alerta;
        this.navCtrl = navCtrl;
        this.alertCtrl = alertCtrl;
        this.alertSvc = alertSvc;
        this.archivosSvc = archivosSvc;
        this.fechaHoy = new Date();
        this.dataArchi = {};
        this.valid = false;
        this.modelCuaderno = {
          nombreMateria: '',
          titulo: '',
          fecha_mod: this.fechaHoy.toISOString(),
          fecha_crea: '',
          contenido: ''
        };
        this.modelArchivo = {
          array: [],
          id_usuario: 1,
          id_cuaderno: 0
        };
        this.activatedRoute.params.subscribe(function (params) {
          _this.idCuaderno = params['idC'];
          _this.idMateria = params['idM'];
        });
      }

      _createClass(CuadernoIdPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this2 = this;

          this.db.getDatabaseState().subscribe(function (boo) {
            if (boo && _this2.idCuaderno > 0 && _this2.idMateria > 0) {
              // Cargar Cuaderno 
              _this2.db.cargarCuadernoId(_this2.idCuaderno).then(function (data) {
                _this2.dataCuaderno = data;
                _this2.valid = true;
              }); // Cargar Materias


              _this2.db.cargarMateriaId(_this2.idMateria).then(function (data) {
                _this2.dataMateria = data;
              }).then(function (_) {
                _this2.modelCuaderno = {
                  nombreMateria: _this2.dataMateria.nombre,
                  titulo: _this2.dataCuaderno.titulo,
                  fecha_crea: _this2.dataCuaderno.fecha_crea,
                  fecha_mod: _this2.fechaHoy.toISOString(),
                  contenido: _this2.dataCuaderno.contenido
                };
              });

              _this2.db.getArchivo().subscribe(function (data) {});

              _this2.db.cargarArchivosCuaderno(_this2.idCuaderno).then(function (data) {
                _this2.modelArchivo.array = data;
              });
            }
          });
        }
      }, {
        key: "archivos",
        value: function archivos(event) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var popover, _yield$popover$onDidD, data;

            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    this.dataArchi = [{
                      nombre: 'Cargar Archivos'
                    }];
                    _context.next = 3;
                    return this.popoverCtrl.create({
                      component: src_app_components_popover_archivos_popover_archivos_component__WEBPACK_IMPORTED_MODULE_7__["PopoverArchivosComponent"],
                      cssClass: 'css_popover',
                      event: event,
                      mode: 'ios',
                      componentProps: {
                        opt: this.dataArchi
                      }
                    });

                  case 3:
                    popover = _context.sent;
                    _context.next = 6;
                    return popover.present();

                  case 6:
                    _context.next = 8;
                    return popover.onDidDismiss();

                  case 8:
                    _yield$popover$onDidD = _context.sent;
                    data = _yield$popover$onDidD.data;

                    if (data) {
                      this.opt = data.item;
                      this.cargarArchivo();
                    }

                  case 11:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "cargarArchivo",
        value: function cargarArchivo() {
          var _this3 = this;

          if (this.opt === 'Cargar Archivos') {
            this.archivosSvc.cargar().then(function (url) {
              _this3.guardarArchivo(url).then(function (_) {
                _this3.alertSvc.presentToast('Archivo agregado con exito');
              })["catch"](function (_) {
                return _this3.alertSvc.presentToast('No se cargo ningun archivo');
              });
            });
          }
        }
      }, {
        key: "guardarArchivo",
        value: function guardarArchivo(url) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var nombre, items;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    this.archivosSvc.copyFile(url);
                    nombre = url.substr(url.lastIndexOf('/') + 1);
                    items = {
                      nombre: nombre,
                      url: url
                    };
                    this.modelArchivo.array.push(items);

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "selectArchivo",
        value: function selectArchivo(event) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var popover, _yield$popover$onDidD2, data;

            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    if (this.modelArchivo.array.length > 0) {
                      this.dataArchi = this.modelArchivo.array;
                    } else this.dataArchi = [{
                      nombre: 'Sin Archivos'
                    }];

                    _context3.next = 3;
                    return this.popoverCtrl.create({
                      component: src_app_components_popover_archivos_popover_archivos_component__WEBPACK_IMPORTED_MODULE_7__["PopoverArchivosComponent"],
                      cssClass: 'css_popover',
                      event: event,
                      mode: 'ios',
                      translucent: false,
                      componentProps: {
                        opt: this.dataArchi
                      }
                    });

                  case 3:
                    popover = _context3.sent;
                    _context3.next = 6;
                    return popover.present();

                  case 6:
                    _context3.next = 8;
                    return popover.onDidDismiss();

                  case 8:
                    _yield$popover$onDidD2 = _context3.sent;
                    data = _yield$popover$onDidD2.data;

                    if (data) {
                      this.abrirArchivo(data.url);
                    }

                  case 11:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "abrirArchivo",
        value: function abrirArchivo(data) {
          this.archivosSvc.open(data);
        }
      }, {
        key: "guardar",
        value: function guardar() {
          var _this4 = this;

          this.modelCuaderno.contenido = this.modelCuaderno.contenido.trim();
          this.modelCuaderno.titulo = this.modelCuaderno.titulo.trim();

          if (this.modelCuaderno.contenido.length == 0 && this.modelCuaderno.titulo.length == 0) {
            this.alerta.presentToast("Sin datos que guardar. No se ha creado la nota");
            this.navCtrl.back();
          } else if (!this.valid) {
            this.valid = !this.valid;
            this.db.agregarCuaderno(this.modelCuaderno.titulo, this.modelCuaderno.fecha_mod, this.modelCuaderno.fecha_mod, this.modelCuaderno.contenido, this.idMateria).then(function (data) {
              _this4.idCuaderno = data;

              if (_this4.modelArchivo.array.length > 0) {
                var _iterator = _createForOfIteratorHelper(_this4.modelArchivo.array),
                    _step;

                try {
                  for (_iterator.s(); !(_step = _iterator.n()).done;) {
                    var archi = _step.value;

                    _this4.db.agregarArchivos(archi['url'], archi['nombre'], _this4.modelArchivo.id_usuario, _this4.idCuaderno);
                  }
                } catch (err) {
                  _iterator.e(err);
                } finally {
                  _iterator.f();
                }
              }
            });
            this.alerta.presentToast('Datos guardados con exito');
            this.navCtrl.back();
          } else {
            this.valid = !this.valid;
            this.db.updateCuaderno(this.idCuaderno, this.modelCuaderno.titulo, this.modelCuaderno.fecha_crea, this.modelCuaderno.fecha_mod, this.modelCuaderno.contenido, this.idMateria);

            if (this.modelArchivo.array.length > 0) {
              var _iterator2 = _createForOfIteratorHelper(this.modelArchivo.array),
                  _step2;

              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  var archi = _step2.value;
                  this.db.agregarArchivos(archi['url'], archi['nombre'], this.modelArchivo.id_usuario, this.idCuaderno);
                }
              } catch (err) {
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }
            }

            this.alerta.presentToast('Datos guardados con exito');
            this.navCtrl.back();
          }
        }
      }, {
        key: "focus",
        value: function focus() {
          this.textarea.setFocus();
        }
      }, {
        key: "eliminar",
        value: function eliminar() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var _this5 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.alertCtrl.create({
                      cssClass: 'alert-css',
                      header: '¿Quieres eliminar esta nota?',
                      backdropDismiss: false,
                      buttons: [{
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler(blah) {}
                      }, {
                        text: 'Eliminar nota',
                        handler: function handler(blah) {
                          if (_this5.valid) {
                            _this5.db.eliminarCuaderno(_this5.idCuaderno).then(function (_) {
                              _this5.db.eliminarArchivoCuaderno(_this5.idCuaderno).then(function (_) {
                                _this5.alertSvc.presentToast("Nota eliminada con exito");

                                _this5.navCtrl.back();

                                _this5.valid = !_this5.valid;
                              })["catch"](function (err) {
                                return console.log(err);
                              });
                            })["catch"](function (err) {
                              return err;
                            });
                          } else {
                            _this5.alertSvc.presentToast("No se ha creado la nota");

                            _this5.navCtrl.back();
                          }
                        }
                      }]
                    });

                  case 2:
                    alert = _context4.sent;
                    _context4.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }]);

      return CuadernoIdPage;
    }();

    CuadernoIdPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_4__["DatabaseService"]
      }, {
        type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_5__["AlertasService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }, {
        type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_5__["AlertasService"]
      }, {
        type: src_app_services_archivos_service__WEBPACK_IMPORTED_MODULE_6__["ArchivosService"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('text')], CuadernoIdPage.prototype, "textarea", void 0);
    CuadernoIdPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-cuaderno-id',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./cuaderno-id.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cuaderno-id/cuaderno-id.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./cuaderno-id.page.scss */
      "./src/app/pages/cuaderno-id/cuaderno-id.page.scss"))["default"]]
    })], CuadernoIdPage);
    /***/
  },

  /***/
  "./src/app/services/alertas.service.ts":
  /*!*********************************************!*\
    !*** ./src/app/services/alertas.service.ts ***!
    \*********************************************/

  /*! exports provided: AlertasService */

  /***/
  function srcAppServicesAlertasServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AlertasService", function () {
      return AlertasService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./db.service */
    "./src/app/services/db.service.ts");

    var AlertasService = /*#__PURE__*/function () {
      function AlertasService(alertCtrl, dataSvc, db, toastCtrl) {
        _classCallCheck(this, AlertasService);

        this.alertCtrl = alertCtrl;
        this.dataSvc = dataSvc;
        this.db = db;
        this.toastCtrl = toastCtrl;
      }

      _createClass(AlertasService, [{
        key: "presentToast",
        value: function presentToast(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var toast;
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.toastCtrl.create({
                      cssClass: "alert",
                      message: message,
                      duration: 2000
                    });

                  case 2:
                    toast = _context5.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }]);

      return AlertasService;
    }();

    AlertasService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
      }, {
        type: _db_service__WEBPACK_IMPORTED_MODULE_4__["DatabaseService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    AlertasService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], AlertasService);
    /***/
  },

  /***/
  "./src/app/services/archivos.service.ts":
  /*!**********************************************!*\
    !*** ./src/app/services/archivos.service.ts ***!
    \**********************************************/

  /*! exports provided: ArchivosService */

  /***/
  function srcAppServicesArchivosServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ArchivosService", function () {
      return ArchivosService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/file-path/ngx */
    "./node_modules/@ionic-native/file-path/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/file-chooser/ngx */
    "./node_modules/@ionic-native/file-chooser/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/file-opener/ngx */
    "./node_modules/@ionic-native/file-opener/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic-native/File/ngx */
    "./node_modules/@ionic-native/File/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var Media_folder_name = 'Archivos';
    var Local_location_name = "file:///storage/emulated/0/Myapp/";

    var ArchivosService = /*#__PURE__*/function () {
      function ArchivosService(filePath, fileChooser, fileOpener, file, plt) {
        var _this6 = this;

        _classCallCheck(this, ArchivosService);

        this.filePath = filePath;
        this.fileChooser = fileChooser;
        this.fileOpener = fileOpener;
        this.file = file;
        this.plt = plt;
        this.plt.ready().then(function () {
          // Raiz 
          var path = _this6.file.dataDirectory;

          _this6.file.checkDir(path, Media_folder_name).then(function () {}, function (err) {
            _this6.file.createDir(path, Media_folder_name, false);
          }); // LOCAL 


          var path2 = Local_location_name;

          _this6.file.checkDir(path2, Media_folder_name).then(function () {}, function (err) {
            _this6.file.createDir(path2, Media_folder_name, false);
          });
        });
      }

      _createClass(ArchivosService, [{
        key: "cargar",
        value: function cargar() {
          var _this7 = this;

          return this.fileChooser.open().then(function (uri) {
            return _this7.filePath.resolveNativePath(uri)["catch"](function (err) {
              return console.log(err);
            });
          })["catch"](function (err) {
            return console.log(err);
          });
        }
      }, {
        key: "open",
        value: function open(url) {
          this.fileOpener.showOpenWithDialog(url, '')["catch"](function (err) {
            return console.log(err);
          });
        }
      }, {
        key: "copyFile",
        value: function copyFile(fullPath) {
          var myPath = fullPath;

          var _native;

          var local;

          if (fullPath.indexOf('file://') < 0) {
            myPath = 'file://' + fullPath;
          }

          var ext = myPath.split('.').pop();
          var d = Date.now();
          var newName = "".concat(d, ".").concat(ext);
          var name = myPath.substr(myPath.lastIndexOf('/') + 1);
          var copyFrom = myPath.substr(0, myPath.lastIndexOf('/') + 1);
          var copyToLocal = Local_location_name + Media_folder_name;
          var copyToNative = this.file.dataDirectory + Media_folder_name;
          this.file.copyFile(copyFrom, name, copyToLocal, newName).then(function (success) {}, function (err) {});
          this.file.copyFile(copyFrom, name, copyToNative, newName).then(function (success) {}, function (err) {});
          return;
        }
      }]);

      return ArchivosService;
    }();

    ArchivosService.ctorParameters = function () {
      return [{
        type: _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_2__["FilePath"]
      }, {
        type: _ionic_native_file_chooser_ngx__WEBPACK_IMPORTED_MODULE_3__["FileChooser"]
      }, {
        type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_4__["FileOpener"]
      }, {
        type: _ionic_native_File_ngx__WEBPACK_IMPORTED_MODULE_5__["File"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["Platform"]
      }];
    };

    ArchivosService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], ArchivosService);
    /***/
  }
}]);
//# sourceMappingURL=pages-cuaderno-id-cuaderno-id-module-es5.js.map