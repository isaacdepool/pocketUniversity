(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-galeria-galeria-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/galeria/galeria.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/galeria/galeria.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-header titulo=\"Galeria\"></app-header>\n\n<ion-content>\n\n  <ion-item lines=\"none\">\n\n    \n    <ion-buttons slot=\"end\">\n\n      <div class=\"buscar\">\n\n        \n        <ion-button \n        slot=\"end\" \n        fill=\"clear\" \n        shape=\"round\">\n        \n        <ion-input (ionChange)=\"buscar( $event )\" type=\"text\"></ion-input>\n        <ion-icon name=\"search\"></ion-icon>\n    \n        </ion-button>\n\n      </div>\n  \n      <ion-button (click)=\"opts( $event )\" \n      expand=\"block\" \n      fill=\"clear\" \n      shape=\"round\">\n        \n      <ion-icon name=\"ellipsis-vertical\"></ion-icon>\n  \n      </ion-button>\n\n    </ion-buttons>\n\n  </ion-item>\n  \n    <ion-row >\n\n      <ion-col size=\"6\"\n      class=\"padding\" >\n\n      <ion-card class=\"card-size\" \n      *ngIf=\"ver\"\n      (click)=\"verFavorito()\"> \n\n      <ng-container *ngFor=\"let imgFav of fotos; let i = index\">\n\n        <ion-img\n        *ngIf=\"imgFav.favorito == true\" [src]=\"img[i]\"></ion-img>\n\n    </ng-container>\n\n    <ion-img class=\"defaultImg\"\n          src=\"/assets/photos.svg\"></ion-img>\n    \n  </ion-card>\n        <ion-item lines=\"none\" class=\"ion-text-center\">\n  \n          <ion-label class=\"ion-text-capitalize\">Favoritos</ion-label>\n\n        </ion-item>\n        \n        \n      </ion-col>\n\n      <ng-container *ngFor=\"let car of carpeta | filtro: textoBuscar: 'nombre'\">\n      \n      <ion-col size=\"6\"\n      class=\"padding\" >\n\n      <ion-card class=\"card-size\" \n      *ngIf=\"ver\"\n      (click)=\"verCarpeta( car.id )\">\n\n      <ion-img\n              [src]=\"img[i]\"></ion-img>\n          \n          <ng-container *ngFor=\"let imgF of fotos; let i = index\">\n\n              <ion-img\n              *ngIf=\"imgF.id_carpeta == car.id\" [src]=\"img[i]\"></ion-img>\n\n          </ng-container>\n\n          <ion-img class=\"defaultImg\"\n          src=\"/assets/photos.svg\"></ion-img>\n        </ion-card>\n\n            <ion-skeleton-text *ngIf=\"!ver\"\n            color=\"medium\"\n            class=\"card-size\"\n            animated \n            style=\"width: 100%\"></ion-skeleton-text>\n  \n            <ion-item lines=\"none\" class=\"ion-text-center\">\n  \n              <ion-label class=\"ion-text-capitalize\">{{car.nombre}}</ion-label>\n  \n            </ion-item>\n            \n          </ion-col>\n        </ng-container>\n\n        </ion-row>\n\n</ion-content>\n  ");

/***/ }),

/***/ "./src/app/pages/galeria/galeria-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/galeria/galeria-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: GaleriaPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GaleriaPageRoutingModule", function() { return GaleriaPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _galeria_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./galeria.page */ "./src/app/pages/galeria/galeria.page.ts");




const routes = [
    {
        path: '',
        component: _galeria_page__WEBPACK_IMPORTED_MODULE_3__["GaleriaPage"]
    }
];
let GaleriaPageRoutingModule = class GaleriaPageRoutingModule {
};
GaleriaPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], GaleriaPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/galeria/galeria.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/galeria/galeria.module.ts ***!
  \*************************************************/
/*! exports provided: GaleriaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GaleriaPageModule", function() { return GaleriaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _galeria_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./galeria-routing.module */ "./src/app/pages/galeria/galeria-routing.module.ts");
/* harmony import */ var _galeria_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./galeria.page */ "./src/app/pages/galeria/galeria.page.ts");
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/components.module */ "./src/app/components/components.module.ts");








let GaleriaPageModule = class GaleriaPageModule {
};
GaleriaPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _galeria_routing_module__WEBPACK_IMPORTED_MODULE_5__["GaleriaPageRoutingModule"],
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]
        ],
        declarations: [_galeria_page__WEBPACK_IMPORTED_MODULE_6__["GaleriaPage"]]
    })
], GaleriaPageModule);



/***/ }),

/***/ "./src/app/pages/galeria/galeria.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/galeria/galeria.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".buscar {\n  border-radius: 50px;\n  border: solid;\n  color: var(--ion-color-medium);\n}\n\n.card-size {\n  height: 95%;\n  width: 95%;\n  border-radius: 15%;\n}\n\n.padding {\n  height: 200px;\n  margin-bottom: 10%;\n}\n\n.opts {\n  z-index: 1;\n  bottom: 0;\n  width: 100%;\n  opacity: 90%;\n}\n\n.opts2 {\n  z-index: 1;\n  top: 0;\n  width: 100%;\n  opacity: 90%;\n}\n\n.center {\n  margin: auto;\n}\n\n.defaultImg {\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZ2FsZXJpYS9DOlxcVXNlcnNcXGlzYWNcXERlc2t0b3BcXGlvbmljXFxwYW50YVZlcnNpb25FZHUvc3JjXFxhcHBcXHBhZ2VzXFxnYWxlcmlhXFxnYWxlcmlhLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvZ2FsZXJpYS9nYWxlcmlhLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0FDQUo7O0FER0E7RUFDSSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0FDQUo7O0FER0E7RUFDSSxhQUFBO0VBQ0Esa0JBQUE7QUNBSjs7QURHQTtFQUNJLFVBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNBSjs7QURHQTtFQUNJLFVBQUE7RUFDQSxNQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNBSjs7QURHQTtFQUVJLFlBQUE7QUNESjs7QURJQTtFQUNJLFlBQUE7QUNESiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2dhbGVyaWEvZ2FsZXJpYS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLmJ1c2NhcntcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbiAgICBib3JkZXI6IHNvbGlkO1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG59XHJcblxyXG4uY2FyZC1zaXple1xyXG4gICAgaGVpZ2h0OiA5NSU7XHJcbiAgICB3aWR0aDogOTUlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTUlO1xyXG59XHJcblxyXG4ucGFkZGluZ3tcclxuICAgIGhlaWdodDogMjAwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMCU7XHJcbn1cclxuXHJcbi5vcHRze1xyXG4gICAgei1pbmRleDogMTtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgb3BhY2l0eTogOTAlO1xyXG59XHJcblxyXG4ub3B0czJ7XHJcbiAgICB6LWluZGV4OiAxO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBvcGFjaXR5OiA5MCU7XHJcbn1cclxuXHJcbi5jZW50ZXJ7XHJcblxyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG59XHJcblxyXG4uZGVmYXVsdEltZ3tcclxuICAgIGhlaWdodDogMTAwJTtcclxufVxyXG4iLCIuYnVzY2FyIHtcbiAgYm9yZGVyLXJhZGl1czogNTBweDtcbiAgYm9yZGVyOiBzb2xpZDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xufVxuXG4uY2FyZC1zaXplIHtcbiAgaGVpZ2h0OiA5NSU7XG4gIHdpZHRoOiA5NSU7XG4gIGJvcmRlci1yYWRpdXM6IDE1JTtcbn1cblxuLnBhZGRpbmcge1xuICBoZWlnaHQ6IDIwMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMCU7XG59XG5cbi5vcHRzIHtcbiAgei1pbmRleDogMTtcbiAgYm90dG9tOiAwO1xuICB3aWR0aDogMTAwJTtcbiAgb3BhY2l0eTogOTAlO1xufVxuXG4ub3B0czIge1xuICB6LWluZGV4OiAxO1xuICB0b3A6IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBvcGFjaXR5OiA5MCU7XG59XG5cbi5jZW50ZXIge1xuICBtYXJnaW46IGF1dG87XG59XG5cbi5kZWZhdWx0SW1nIHtcbiAgaGVpZ2h0OiAxMDAlO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/galeria/galeria.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/galeria/galeria.page.ts ***!
  \***********************************************/
/*! exports provided: GaleriaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GaleriaPage", function() { return GaleriaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/db.service */ "./src/app/services/db.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_components_popover_options_popover_options_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/components/popover-options/popover-options.component */ "./src/app/components/popover-options/popover-options.component.ts");
/* harmony import */ var _carpeta_id_carpeta_id_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../carpeta-id/carpeta-id.page */ "./src/app/pages/carpeta-id/carpeta-id.page.ts");
/* harmony import */ var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/ionic-webview/ngx */ "./node_modules/@ionic-native/ionic-webview/__ivy_ngcc__/ngx/index.js");







let GaleriaPage = class GaleriaPage {
    constructor(db, popoverCtrl, webView, alertCtrl, modalCtrl, navCtrl) {
        this.db = db;
        this.popoverCtrl = popoverCtrl;
        this.webView = webView;
        this.alertCtrl = alertCtrl;
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.fotos = [];
        this.carpeta = [];
        this.textoBuscar = '';
        this.img = [];
        this.ver = false;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.cargar();
    }
    cargar() {
        this.db.getDatabaseState().subscribe(boo => {
            if (boo) {
                this.db.getFotos().subscribe(data => {
                    this.fotos = [];
                    this.img = [];
                    for (let [i, foto] of data.entries()) {
                        this.fotos.push(foto);
                        this.img[i] = this.webView.convertFileSrc(foto.url);
                    }
                    this.fotos = this.fotos.slice().reverse();
                    this.img = this.img.slice().reverse();
                });
                this.db.getCarpeta().subscribe(data => {
                    this.carpeta = data;
                });
            }
        });
        return setTimeout(() => {
            this.ver = true;
        }, 200);
    }
    verCarpeta(id_Carpeta, id_foto) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _carpeta_id_carpeta_id_page__WEBPACK_IMPORTED_MODULE_5__["CarpetaIdPage"],
                componentProps: {
                    carpetaId: id_Carpeta,
                    fotoId: id_foto
                }
            });
            yield modal.present();
            const { data } = yield modal.onDidDismiss();
            if (data) {
                if (data.editarMateria == true) {
                    let navigationExtras = { state: { id: data.idMateria, boo: true } };
                    this.navCtrl.navigateForward(['/agg-materia'], navigationExtras);
                }
            }
        });
    }
    verFavorito() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modalFav = yield this.modalCtrl.create({
                component: _carpeta_id_carpeta_id_page__WEBPACK_IMPORTED_MODULE_5__["CarpetaIdPage"],
                componentProps: {
                    fav: true
                }
            });
            yield modalFav.present();
        });
    }
    onClick() {
        this.db.getDatabaseState().subscribe(boo => {
            if (boo) {
                this.db.getFotos().subscribe(data => {
                });
            }
        });
    }
    buscar(event) {
        this.textoBuscar = event.detail.value;
    }
    opts(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const popover = yield this.popoverCtrl.create({
                component: src_app_components_popover_options_popover_options_component__WEBPACK_IMPORTED_MODULE_4__["PopoverOptionsComponent"],
                cssClass: 'css_popover',
                event: event,
                mode: 'ios'
            });
            yield popover.present();
            const { data } = yield popover.onDidDismiss();
            if (data) {
                this.opt = data.item;
                this.optsCarpeta();
                if (this.opt === "Crear carpeta") {
                }
            }
        });
    }
    optsCarpeta() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'Nueva carpeta',
                backdropDismiss: false,
                cssClass: 'alert-css',
                inputs: [
                    {
                        name: 'nombre',
                        type: 'text',
                        placeholder: 'Nombre de la carpeta'
                    },
                ],
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        handler: (blah) => {
                        }
                    },
                    {
                        text: 'Guardar',
                        handler: (data) => {
                            this.crearCarpeta(data.nombre);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    crearCarpeta(nombre) {
        this.db.agregarCarpeta(nombre, 1, 0).then(_ => {
        });
    }
};
GaleriaPage.ctorParameters = () => [
    { type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"] },
    { type: _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_6__["WebView"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] }
];
GaleriaPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-galeria',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./galeria.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/galeria/galeria.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./galeria.page.scss */ "./src/app/pages/galeria/galeria.page.scss")).default]
    })
], GaleriaPage);



/***/ })

}]);
//# sourceMappingURL=pages-galeria-galeria-module-es2015.js.map