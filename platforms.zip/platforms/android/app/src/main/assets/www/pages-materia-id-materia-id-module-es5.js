function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-materia-id-materia-id-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesInfoModalInfoModalPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"danger\">\n    \n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"salir()\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n\n    <ion-title >Detalles</ion-title>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-list *ngIf=\"tipo === 'imagenCarpeta'  && ver\"\n  class=\"ion-padding\">\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">Fecha</ion-label>\n      <ion-label>{{datosFotos[0].fecha | fecha}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Carpeta\n      </ion-label>\n      <ion-label>{{datosCarpeta[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\"> \n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Ruta\n      </ion-label>\n      <ion-label>Galeria/{{datosCarpeta[0].nombre}}/{{datosFotos[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\"\n      font-size=\"small\">Nombre\n      \n    </ion-label>\n      <ion-label>{{datosFotos[0].nombre}}</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list *ngIf=\"tipo === 'carpeta' && ver\">\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Nombre\n      </ion-label>\n      <ion-label>{{datosCarpeta[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Imagenes\n      </ion-label>\n      <ion-label>{{datosFotos.length}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Materia\n      </ion-label>\n      <ion-label *ngIf=\"datosCarpeta[0].id_materia > 0\">{{datosCarpeta[0].nombre}}</ion-label>\n      <ion-label *ngIf=\"datosCarpeta[0].id_materia == 0\">Carpeta independiente</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list *ngIf=\"tipo === 'materia' && ver\">\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Nombre\n      </ion-label>\n      <ion-label>{{datosMaterias[0].nombre}}</ion-label>\n    </ion-item>\n\n    <ion-item >\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Periodo academico\n      </ion-label>\n      <ion-label>{{datosPeriodo[0].nombre}}</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-title *ngIf=\"tipo === 'materia'\">Horario de clases</ion-title>\n\n  <ion-item *ngIf=\"datosEvento.length == 0 && tipo === 'materia'\">\n    <ion-label color=\"medium\"\n    position=\"fixed\">\n      Sin horario de clases\n    </ion-label>\n  </ion-item>\n\n  <ion-list *ngIf=\"tipo === 'materia' && ver && datosEvento.length > 0\">\n\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Dia\n      </ion-label>\n      <ion-label>{{datosEvento[0].dia | dia: datosEvento[0].dia}}</ion-label>\n    </ion-item>\n\n    <ion-item lines=\"none\">\n      <ion-label color=\"medium\"\n      position=\"fixed\">\n        Inicio\n      </ion-label>\n      <ion-label>{{datosEvento[0].inicio | hora}}</ion-label>\n    </ion-item>\n\n  <ion-item lines=\"none\">\n    <ion-label color=\"medium\"\n    position=\"fixed\">\n      Fin\n    </ion-label>\n    <ion-label>{{datosEvento[0].fin | hora}}</ion-label>\n  </ion-item>\n\n<ion-item >\n  <ion-label color=\"medium\"\n  position=\"fixed\">\n    Comentarios\n  </ion-label>\n  <ion-label>{{datosEvento[0].comentario || 'Sin comentarios'}}</ion-label>\n</ion-item>\n</ion-list>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/materia-id/materia-id.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/materia-id/materia-id.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMateriaIdMateriaIdPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"danger\">\n\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/\"></ion-back-button>\n    </ion-buttons>\n\n    <ng-container *ngFor=\"let mate of dataMateria\">\n \n      <ion-title>{{dataMateria[0].nombre}}</ion-title>\n      \n    </ng-container>\n\n\n    <ion-buttons slot=\"end\">\n\n      <ion-button (click)=\"edit()\" \n      fill=\"clear\" \n      shape=\"round\">\n\n        <ion-icon slot=\"icon-only\" name=\"pencil\"></ion-icon>\n\n      </ion-button>\n    </ion-buttons>\n\n\n    <ion-buttons slot=\"end\">\n\n      <ion-button (click)=\"info( $event )\" \n      fill=\"clear\" \n      shape=\"round\">\n\n        <ion-icon slot=\"icon-only\" name=\"alert-circle\"></ion-icon>\n\n      </ion-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n  <ion-content>\n \n    <div *ngFor=\"let cuader of dataCuaderno\">\n\n      <ion-card *ngIf=\"cuader.id_materia == materiaId\"\n      color=\"tertiary\">\n      <ion-card-header>\n        <ion-card-subtitle class=\"ion-text-capitalize\"> \n  \n          <div>\n            <ion-label>Creado: {{cuader.fecha_crea | fecha}}</ion-label>\n          </div>\n   \n          <div class=\"more\">\n            <ion-button fill=\"clear\"\n            (click)=\"more( $event, cuader.id )\">\n              <ion-icon color=\"dark\"\n              slot=\"icon-only\"\n              name=\"ellipsis-vertical\"></ion-icon>\n            </ion-button>\n    \n          </div>\n        </ion-card-subtitle>\n  \n        <ion-card-title \n        (click)=\"abrirNota( cuader.id )\">{{cuader.titulo || 'Sin titulo'}}</ion-card-title>\n      </ion-card-header>\n      <ion-card-content class=\"cut\" \n      (click)=\"abrirNota( cuader.id )\">\n        {{cuader.contenido || 'Sin contenido'}}\n      </ion-card-content>\n\n      <div class=\"end\">\n          <ion-label size=\"20\"\n          color=\"light\">Modificado: {{cuader.fecha_mod | fecha}}</ion-label>\n      </div>\n    </ion-card>\n    </div>\n\n\n        \n    <app-fab class=\"fixed\"\n    slot=\"fixed\"\n    [idMateria]=\"materiaId\"\n    [pageMateriaId]=\"true\"></app-fab>\n\n</ion-content>\n\n\n\n\n";
    /***/
  },

  /***/
  "./src/app/pages/info-modal/info-modal.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/pages/info-modal/info-modal.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesInfoModalInfoModalPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luZm8tbW9kYWwvaW5mby1tb2RhbC5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/pages/info-modal/info-modal.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/info-modal/info-modal.page.ts ***!
    \*****************************************************/

  /*! exports provided: InfoModalPage */

  /***/
  function srcAppPagesInfoModalInfoModalPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "InfoModalPage", function () {
      return InfoModalPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/services/db.service */
    "./src/app/services/db.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var InfoModalPage = /*#__PURE__*/function () {
      function InfoModalPage(db, modalCtrl) {
        _classCallCheck(this, InfoModalPage);

        this.db = db;
        this.modalCtrl = modalCtrl;
        this.ver = false;
        this.datosFotos = [];
        this.datosCarpeta = [];
        this.datosMaterias = [];
        this.datosEvento = [];
        this.datosPeriodo = [];
      }

      _createClass(InfoModalPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          console.log(this.id);
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          var _this = this;

          this.db.getDatabaseState().subscribe(function (boo) {
            if (boo) {
              if (_this.tipo === 'imagenCarpeta') {
                _this.cargarFotos();

                _this.cargarCarpeta();
              }

              if (_this.tipo === 'carpeta') {
                _this.cargarCarpetaId();

                _this.cargarFotos();
              }

              if (_this.tipo === 'materia') {
                _this.cargarMateriasId();
              }
            }
          });
        }
      }, {
        key: "salir",
        value: function salir() {
          this.modalCtrl.dismiss();
        }
      }, {
        key: "cargarFotos",
        value: function cargarFotos() {
          var _this2 = this;

          this.db.getFotos().subscribe(function (data) {
            var _iterator = _createForOfIteratorHelper(data),
                _step;

            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                var datos = _step.value;

                if (datos.id == _this2.id && _this2.tipo === 'imagenCarpeta') {
                  _this2.datosFotos.push(datos);

                  _this2.ver = true;
                } else if (datos.id_carpeta == _this2.id && _this2.tipo === 'carpeta') {
                  _this2.datosFotos.push(datos);
                }
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }
          });
        }
      }, {
        key: "cargarCarpeta",
        value: function cargarCarpeta() {
          var _this3 = this;

          this.db.getCarpeta().subscribe(function (data) {
            var _iterator2 = _createForOfIteratorHelper(data),
                _step2;

            try {
              for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                var datos = _step2.value;

                if (datos.id == _this3.datosFotos[0].id_carpeta) {
                  _this3.datosCarpeta.push(datos);
                }
              }
            } catch (err) {
              _iterator2.e(err);
            } finally {
              _iterator2.f();
            }

            _this3.ver = true;
          });
        }
      }, {
        key: "cargarCarpetaId",
        value: function cargarCarpetaId() {
          var _this4 = this;

          this.db.cargarCarpetaId(this.id).then(function (data) {
            _this4.datosCarpeta.push(data);

            console.log(data);
            _this4.ver = true;
          });
        }
      }, {
        key: "cargarMateriasId",
        value: function cargarMateriasId() {
          var _this5 = this;

          this.db.cargarMateriaId(this.id).then(function (data) {
            _this5.datosMaterias.push(data);

            _this5.ver = true;

            _this5.cargarEvento();

            _this5.cargarPeriodo();
          });
        }
      }, {
        key: "cargarEvento",
        value: function cargarEvento() {
          var _this6 = this;

          if (this.datosMaterias[0].id_evento > 0) {
            this.db.cargarEventoId(this.datosMaterias[0].id_evento).then(function (data) {
              if (data) {
                _this6.datosEvento.push(data);
              }
            });
          }
        }
      }, {
        key: "cargarPeriodo",
        value: function cargarPeriodo() {
          var _this7 = this;

          this.db.cargarPeriodoId(this.datosMaterias[0].id_periodo).then(function (data) {
            _this7.datosPeriodo.push(data);
          });
        }
      }]);

      return InfoModalPage;
    }();

    InfoModalPage.ctorParameters = function () {
      return [{
        type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_2__["DatabaseService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], InfoModalPage.prototype, "tipo", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], InfoModalPage.prototype, "id", void 0);
    InfoModalPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-info-modal',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./info-modal.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-modal/info-modal.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./info-modal.page.scss */
      "./src/app/pages/info-modal/info-modal.page.scss"))["default"]]
    })], InfoModalPage);
    /***/
  },

  /***/
  "./src/app/pages/materia-id/materia-id-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/materia-id/materia-id-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: MateriaIdPageRoutingModule */

  /***/
  function srcAppPagesMateriaIdMateriaIdRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MateriaIdPageRoutingModule", function () {
      return MateriaIdPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _materia_id_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./materia-id.page */
    "./src/app/pages/materia-id/materia-id.page.ts");

    var routes = [{
      path: '',
      component: _materia_id_page__WEBPACK_IMPORTED_MODULE_3__["MateriaIdPage"]
    }];

    var MateriaIdPageRoutingModule = function MateriaIdPageRoutingModule() {
      _classCallCheck(this, MateriaIdPageRoutingModule);
    };

    MateriaIdPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MateriaIdPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/materia-id/materia-id.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/materia-id/materia-id.module.ts ***!
    \*******************************************************/

  /*! exports provided: MateriaIdPageModule */

  /***/
  function srcAppPagesMateriaIdMateriaIdModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MateriaIdPageModule", function () {
      return MateriaIdPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _materia_id_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./materia-id-routing.module */
    "./src/app/pages/materia-id/materia-id-routing.module.ts");
    /* harmony import */


    var _materia_id_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./materia-id.page */
    "./src/app/pages/materia-id/materia-id.page.ts");
    /* harmony import */


    var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/components/components.module */
    "./src/app/components/components.module.ts");

    var MateriaIdPageModule = function MateriaIdPageModule() {
      _classCallCheck(this, MateriaIdPageModule);
    };

    MateriaIdPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _materia_id_routing_module__WEBPACK_IMPORTED_MODULE_5__["MateriaIdPageRoutingModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]],
      declarations: [_materia_id_page__WEBPACK_IMPORTED_MODULE_6__["MateriaIdPage"]]
    })], MateriaIdPageModule);
    /***/
  },

  /***/
  "./src/app/pages/materia-id/materia-id.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/pages/materia-id/materia-id.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMateriaIdMateriaIdPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".cut {\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.end {\n  font-size: small;\n  margin-left: 100px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvbWF0ZXJpYS1pZC9DOlxcVXNlcnNcXGlzYWNcXERlc2t0b3BcXGlvbmljXFxwYW50YVZlcnNpb25FZHUvc3JjXFxhcHBcXHBhZ2VzXFxtYXRlcmlhLWlkXFxtYXRlcmlhLWlkLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvbWF0ZXJpYS1pZC9tYXRlcmlhLWlkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQ0NKOztBREVBO0VBQ0ksZ0JBQUE7RUFDQSw2QkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbWF0ZXJpYS1pZC9tYXRlcmlhLWlkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jdXR7XHJcbiAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG59XHJcblxyXG4uZW5ke1xyXG4gICAgZm9udC1zaXplOiBzbWFsbDtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMDBweCAhaW1wb3J0YW50OyAgICBcclxufVxyXG5cclxuXHJcblxyXG4iLCIuY3V0IHtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG59XG5cbi5lbmQge1xuICBmb250LXNpemU6IHNtYWxsO1xuICBtYXJnaW4tbGVmdDogMTAwcHggIWltcG9ydGFudDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/materia-id/materia-id.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/materia-id/materia-id.page.ts ***!
    \*****************************************************/

  /*! exports provided: MateriaIdPage */

  /***/
  function srcAppPagesMateriaIdMateriaIdPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MateriaIdPage", function () {
      return MateriaIdPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_components_popover_popover_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/components/popover/popover.component */
    "./src/app/components/popover/popover.component.ts");
    /* harmony import */


    var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/services/db.service */
    "./src/app/services/db.service.ts");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);
    /* harmony import */


    var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/services/alertas.service */
    "./src/app/services/alertas.service.ts");
    /* harmony import */


    var _info_modal_info_modal_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../info-modal/info-modal.page */
    "./src/app/pages/info-modal/info-modal.page.ts");

    var MateriaIdPage = /*#__PURE__*/function () {
      function MateriaIdPage(activatedRoute, popoverCtrl, db, router, alertCtrl, alertSvc, navCtrl, modalCtrl) {
        var _this8 = this;

        _classCallCheck(this, MateriaIdPage);

        this.activatedRoute = activatedRoute;
        this.popoverCtrl = popoverCtrl;
        this.db = db;
        this.router = router;
        this.alertCtrl = alertCtrl;
        this.alertSvc = alertSvc;
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.dataCuaderno = [];
        this.dataPeriodo = [];
        this.dataEvento = [];
        this.dataMateria = [];
        this.dia = '';
        this.hora = '';
        this.fechaHoy = new Date();
        this.idMateria = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.activatedRoute.params.subscribe(function (params) {
          _this8.materiaId = params['id'];

          _this8.pgMoment();
        });
      }

      _createClass(MateriaIdPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this9 = this;

            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    this.db.getDatabaseState().subscribe(function (boo) {
                      if (boo) {
                        _this9.db.getCuaderno().subscribe(function (data) {
                          _this9.dataCuaderno = data.slice().reverse();
                        });

                        _this9.db.getPeriodo().subscribe(function (data) {
                          _this9.dataPeriodo = data;
                        });

                        _this9.db.cargarMateriaId(_this9.materiaId).then(function (data) {
                          _this9.dataMateria.push(data);
                        });

                        _this9.db.getEvento().subscribe(function (data) {
                          _this9.dataEvento = data;
                        });
                      }
                    });

                  case 1:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "edit",
        value: function edit() {
          var navigationExtras = {
            state: {
              id: this.materiaId,
              boo: true
            }
          };
          this.navCtrl.navigateForward(['/agg-materia'], navigationExtras);
        }
      }, {
        key: "more",
        value: function more(event, id) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var popover, _yield$popover$onDidD, data;

            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.popoverCtrl.create({
                      component: src_app_components_popover_popover_component__WEBPACK_IMPORTED_MODULE_4__["PopoverComponent"],
                      cssClass: 'css_popover',
                      event: event,
                      mode: 'ios'
                    });

                  case 2:
                    popover = _context2.sent;
                    _context2.next = 5;
                    return popover.present();

                  case 5:
                    _context2.next = 7;
                    return popover.onDidDismiss();

                  case 7:
                    _yield$popover$onDidD = _context2.sent;
                    data = _yield$popover$onDidD.data;

                    if (data) {
                      this.opt = data.item;
                      this.optCuaderno(id);
                    }

                  case 10:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "optCuaderno",
        value: function optCuaderno(id) {
          if (this.opt === 'editar') {
            this.abrirNota(id);
          } else if (this.opt === 'eliminar') {
            this.eliminar(id);
          }
        }
      }, {
        key: "abrirNota",
        value: function abrirNota(id) {
          this.router.navigate(['/cuaderno-id', id, this.materiaId]);
        }
      }, {
        key: "pgMoment",
        value: function pgMoment() {
          moment__WEBPACK_IMPORTED_MODULE_6__["locale"]('es');
          this.dia = moment__WEBPACK_IMPORTED_MODULE_6__().format("MMMM DD YYYY");
          this.hora = moment__WEBPACK_IMPORTED_MODULE_6__(this.dataCuaderno['fehca_mod']).format("HH:mm");
        }
      }, {
        key: "eliminar",
        value: function eliminar(id) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this10 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.alertCtrl.create({
                      cssClass: 'alert-css',
                      header: '¿Quieres eliminar esta nota?',
                      backdropDismiss: false,
                      buttons: [{
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler(blah) {}
                      }, {
                        text: 'Eliminar nota',
                        handler: function handler(blah) {
                          _this10.db.eliminarCuaderno(id);

                          _this10.alertSvc.presentToast("Nota eliminada con exito");
                        }
                      }]
                    });

                  case 2:
                    alert = _context3.sent;
                    _context3.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "info",
        value: function info() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var modal;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.modalCtrl.create({
                      component: _info_modal_info_modal_page__WEBPACK_IMPORTED_MODULE_8__["InfoModalPage"],
                      componentProps: {
                        tipo: 'materia',
                        id: this.materiaId
                      }
                    });

                  case 2:
                    modal = _context4.sent;
                    _context4.next = 5;
                    return modal.present();

                  case 5:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "eliminarMateria",
        value: function eliminarMateria() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var _this11 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.alertCtrl.create({
                      cssClass: 'alert-css',
                      header: '¿Quieres eliminar esta materia?',
                      message: 'Se eliminaran las notas y horarios',
                      backdropDismiss: false,
                      buttons: [{
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler(blah) {}
                      }, {
                        text: 'Eliminar materia',
                        handler: function handler(blah) {
                          _this11.db.eliminarMaterias(_this11.materiaId).then(function (_) {
                            _this11.db.eliminarCuadernoPeriodo(_this11.idMateria);

                            _this11.db.eliminarEvento(_this11.dataMateria[0].id_evento);
                          });

                          _this11.alertSvc.presentToast("Materia eliminada con exito");

                          _this11.navCtrl.back();
                        }
                      }]
                    });

                  case 2:
                    alert = _context5.sent;
                    _context5.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }]);

      return MateriaIdPage;
    }();

    MateriaIdPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"]
      }, {
        type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_5__["DatabaseService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }, {
        type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_7__["AlertasService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()], MateriaIdPage.prototype, "idMateria", void 0);
    MateriaIdPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-materia-id',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./materia-id.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/materia-id/materia-id.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./materia-id.page.scss */
      "./src/app/pages/materia-id/materia-id.page.scss"))["default"]]
    })], MateriaIdPage);
    /***/
  },

  /***/
  "./src/app/services/alertas.service.ts":
  /*!*********************************************!*\
    !*** ./src/app/services/alertas.service.ts ***!
    \*********************************************/

  /*! exports provided: AlertasService */

  /***/
  function srcAppServicesAlertasServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AlertasService", function () {
      return AlertasService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./db.service */
    "./src/app/services/db.service.ts");

    var AlertasService = /*#__PURE__*/function () {
      function AlertasService(alertCtrl, dataSvc, db, toastCtrl) {
        _classCallCheck(this, AlertasService);

        this.alertCtrl = alertCtrl;
        this.dataSvc = dataSvc;
        this.db = db;
        this.toastCtrl = toastCtrl;
      }

      _createClass(AlertasService, [{
        key: "presentToast",
        value: function presentToast(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var toast;
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    _context6.next = 2;
                    return this.toastCtrl.create({
                      cssClass: "alert",
                      message: message,
                      duration: 2000
                    });

                  case 2:
                    toast = _context6.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }]);

      return AlertasService;
    }();

    AlertasService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
      }, {
        type: _db_service__WEBPACK_IMPORTED_MODULE_4__["DatabaseService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }];
    };

    AlertasService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], AlertasService);
    /***/
  }
}]);
//# sourceMappingURL=pages-materia-id-materia-id-module-es5.js.map