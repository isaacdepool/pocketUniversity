(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-materias-materias-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/materias/materias.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/materias/materias.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-header titulo=\"Periodos academicos\"></app-header>\n\n<ion-content>\n  \n  <ion-list lines=\"none\">\n    <ion-item> \n      <h3>Periodo academico</h3>\n    </ion-item>\n  </ion-list>   \n\n  <ion-button (click)=\"nuevoPeriodo()\" \n  expand=\"block\" \n  fill=\"clear\" \n  shape=\"round\">\n  <ion-icon slot=\"start\" name=\"add\"></ion-icon>\n    Agregar nuevo periodo\n  </ion-button>\n\n  <ion-card *ngFor=\"let per of dataPeriodo, let idx = index\">\n\n    <ion-card-header color=\"tertiary\">\n      <ion-card-subtitle> \n\n        <ion-button fill=\"clear\"\n        (click)=\"onClick( idx )\">\n            <ion-icon color=\"dark\"\n            slot=\"icon-only\"\n            [name]=\"verTri != idx? 'caret-forward' : 'caret-down'\"></ion-icon>\n          </ion-button>\n\n        <label> {{per.nombre || \"1 trimertre\" }} </label>\n\n        <div class=\"more\">\n        \n          <ion-button fill=\"clear\"\n          (click)=\"opts($event, per.id)\">\n            <ion-icon color=\"dark\"\n            slot=\"icon-only\"\n            name=\"ellipsis-vertical\"></ion-icon>\n          </ion-button>\n  \n        </div>\n        \n      </ion-card-subtitle>\n    </ion-card-header>\n    <div *ngFor=\"let mate of dataMateria\">\n\n\n      <ion-item (click)=\"irCuaderno( mate.id )\"\n      *ngIf=\"mate.id_periodo === per.id\"\n      [hidden] =\"verTri != idx\"\n      color=\"dark\">\n      \n      <ion-label>\n        {{ mate.nombre }}\n      </ion-label>\n\n      <ion-icon slot=\"end\"\n       name=\"caret-forward\"></ion-icon>\n\n  </ion-item>\n  </div>\n\n  <ion-item  class=\"ion-text-center\"\n  [hidden] =\"verTri != idx\"\n  (click)=\"aggMateria(per.id, per.nombre)\"\n  color=\"dark\">\n\n    <ion-label color=\"primary\">\n      <ion-icon\n      name=\"add\"\n      slot=\"icon-only\"></ion-icon>\n      \n      Agregar materia\n    </ion-label>\n\n\n  </ion-item>\n\n\n\n</ion-card>\n  \n\n<app-fab slot=\"fixed\"\nclass=\"fixed\"\n[pageCuaderno]=\"true\"></app-fab>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/pages/materias/materias-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/materias/materias-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: MateriasPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MateriasPageRoutingModule", function() { return MateriasPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _materias_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./materias.page */ "./src/app/pages/materias/materias.page.ts");




const routes = [
    {
        path: '',
        component: _materias_page__WEBPACK_IMPORTED_MODULE_3__["MateriasPage"]
    }
];
let MateriasPageRoutingModule = class MateriasPageRoutingModule {
};
MateriasPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MateriasPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/materias/materias.module.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/materias/materias.module.ts ***!
  \***************************************************/
/*! exports provided: MateriasPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MateriasPageModule", function() { return MateriasPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _materias_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./materias-routing.module */ "./src/app/pages/materias/materias-routing.module.ts");
/* harmony import */ var _materias_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./materias.page */ "./src/app/pages/materias/materias.page.ts");
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/components.module */ "./src/app/components/components.module.ts");








let MateriasPageModule = class MateriasPageModule {
};
MateriasPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _materias_routing_module__WEBPACK_IMPORTED_MODULE_5__["MateriasPageRoutingModule"],
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]
        ],
        declarations: [_materias_page__WEBPACK_IMPORTED_MODULE_6__["MateriasPage"]]
    })
], MateriasPageModule);



/***/ }),

/***/ "./src/app/pages/materias/materias.page.scss":
/*!***************************************************!*\
  !*** ./src/app/pages/materias/materias.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL21hdGVyaWFzL21hdGVyaWFzLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/pages/materias/materias.page.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/materias/materias.page.ts ***!
  \*************************************************/
/*! exports provided: MateriasPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MateriasPage", function() { return MateriasPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_components_popover_popover_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/components/popover/popover.component */ "./src/app/components/popover/popover.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/alertas.service */ "./src/app/services/alertas.service.ts");
/* harmony import */ var src_app_services_db_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/db.service */ "./src/app/services/db.service.ts");







let MateriasPage = class MateriasPage {
    constructor(popoverCtrl, alertCtrl, navCtrl, db, alertSvc, router) {
        this.popoverCtrl = popoverCtrl;
        this.alertCtrl = alertCtrl;
        this.navCtrl = navCtrl;
        this.db = db;
        this.alertSvc = alertSvc;
        this.router = router;
        this.dataMateria = [];
        this.periodo = {
            nombre: '',
            id_usuario: 1,
        };
        this.valid = false;
    }
    ngOnInit() {
        this.db.getDatabaseState().subscribe(boo => {
            if (boo) {
                this.db.getPeriodo().subscribe(data => {
                    this.dataPeriodo = data;
                });
                this.db.getMaterias().subscribe(data => {
                    this.dataMateria = data;
                });
            }
        });
    }
    onClick(idx) {
        if (this.verTri === idx) {
            this.verTri = null;
        }
        else {
            this.verTri = idx;
        }
    }
    opts(event, id) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const popover = yield this.popoverCtrl.create({
                component: src_app_components_popover_popover_component__WEBPACK_IMPORTED_MODULE_3__["PopoverComponent"],
                cssClass: 'css_popover',
                event: event,
                mode: 'ios'
            });
            yield popover.present();
            const { data } = yield popover.onDidDismiss();
            if (data) {
                this.opt = data.item;
                this.optPeriodo(id);
            }
        });
    }
    optPeriodo(id) {
        if (this.opt === 'eliminar') {
            this.eliminarPeriodo(id);
        }
        else if (this.opt === 'editar') {
            this.cargarPeriodo(id);
        }
    }
    eliminarPeriodo(id) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                cssClass: 'alert-css',
                header: '¿Quieres eliminar este periodo?',
                message: 'Se eliminaran materias, notas y eventos...',
                backdropDismiss: false,
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                        }
                    },
                    {
                        text: 'Eliminar periodo',
                        handler: (blah) => {
                            this.db.eliminarPeriodo(id);
                            this.db.cargarMateriaPeriodo(id).then(data => {
                                for (let mate of data) {
                                    if (mate.id_evento > 0) {
                                        this.db.eliminarEvento(mate.id_evento);
                                    }
                                    this.db.eliminarCuadernoPeriodo(mate.id);
                                }
                                this.db.eliminarMateriasPeriodo(id);
                            });
                            this.alertSvc.presentToast("Periodo eliminado con exito");
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    nuevoPeriodo() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let text = 'titulo';
            let value = '';
            let header = 'Agregar Periodo';
            if (this.valid) {
                text = this.prederPeriodo.nombre;
                value = this.prederPeriodo.nombre;
                header = 'Editar periodo';
            }
            const alert = yield this.alertCtrl.create({
                cssClass: 'alert-css',
                header: header,
                backdropDismiss: false,
                inputs: [
                    {
                        name: 'nombre',
                        type: 'text',
                        placeholder: text,
                        value: value
                    }
                ],
                buttons: [
                    {
                        text: 'Cancelar',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => {
                            this.valid = false;
                        }
                    }, {
                        text: 'Guardar',
                        handler: (data) => {
                            data.nombre = data.nombre.trim();
                            if (data.nombre.length > 0) {
                                this.periodo = {
                                    nombre: data.nombre,
                                    id_usuario: 1
                                };
                                if (this.valid) {
                                    this.db.updatePeriodo(this.prederPeriodo.id, this.periodo.nombre)
                                        .then(_ => {
                                        this.valid = false;
                                    });
                                }
                                else {
                                    this.valid = false;
                                    this.guardarPeriodo();
                                }
                            }
                            else {
                                this.alertSvc.presentToast('Debe de ingresar un titulo');
                            }
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    guardarPeriodo() {
        this.db.getDatabaseState().subscribe(boo => {
            if (boo) {
                this.db.agregarPeriodo(this.periodo.nombre, this.periodo.id_usuario);
                this.periodo = {
                    nombre: '',
                    id_usuario: 0
                };
            }
        });
    }
    cargarPeriodo(id) {
        this.db.getDatabaseState().subscribe(boo => {
            if (boo) {
                this.db.cargarPeriodoId(id).then(data => {
                    this.prederPeriodo = data;
                    this.valid = true;
                    this.nuevoPeriodo();
                });
            }
        });
    }
    aggMateria(id, nombre) {
        let navigationExtras = { state: { id: id, nombre: nombre } };
        this.navCtrl.navigateForward(['/agg-materia'], navigationExtras);
    }
    irCuaderno(id) {
        this.router.navigate(['/materia-id', id]);
    }
};
MateriasPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: src_app_services_db_service__WEBPACK_IMPORTED_MODULE_6__["DatabaseService"] },
    { type: src_app_services_alertas_service__WEBPACK_IMPORTED_MODULE_5__["AlertasService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
MateriasPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-materias',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./materias.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/materias/materias.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./materias.page.scss */ "./src/app/pages/materias/materias.page.scss")).default]
    })
], MateriasPage);



/***/ }),

/***/ "./src/app/services/alertas.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/alertas.service.ts ***!
  \*********************************************/
/*! exports provided: AlertasService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertasService", function() { return AlertasService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./data.service */ "./src/app/services/data.service.ts");
/* harmony import */ var _db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./db.service */ "./src/app/services/db.service.ts");





let AlertasService = class AlertasService {
    constructor(alertCtrl, dataSvc, db, toastCtrl) {
        this.alertCtrl = alertCtrl;
        this.dataSvc = dataSvc;
        this.db = db;
        this.toastCtrl = toastCtrl;
    }
    presentToast(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                cssClass: "alert",
                message,
                duration: 2000,
            });
            toast.present();
        });
    }
};
AlertasService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"] },
    { type: _db_service__WEBPACK_IMPORTED_MODULE_4__["DatabaseService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
AlertasService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AlertasService);



/***/ })

}]);
//# sourceMappingURL=pages-materias-materias-module-es2015.js.map